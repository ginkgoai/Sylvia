# 🎬 Deriva Estelar - Gerador de Vídeos

## ✨ Você está pronto para gerar os vídeos!

### 📋 O que você tem:

✅ **Áudio completo** (10.5 minutos)
- Arquivo: `ep1_coragem_expandido.mp3`
- Vozes: Brian (Jett) e George (Spike)
- Tema: Coragem

✅ **Roteiro expandido**
- Arquivo: `roteiro_ep1_coragem_expandido.md`
- 74 falas com pausas contemplativas

✅ **Script para gerar vídeos**
- Arquivo: `gerar_videos_comfyui_api.py`
- Gera 4 vídeos automaticamente via API ComfyUI

---

## 🚀 Como usar (3 passos simples):

### PASSO 1: Certifique-se que ComfyUI está ABERTO
- Abra o ComfyUI no seu Windows
- Deixe rodando em background
- Não precisa fazer nada nele!

### PASSO 2: Clique duplo em "EXECUTAR_GERACAO.bat"
- Encontre o arquivo `EXECUTAR_GERACAO.bat`
- Clique duplo nele
- Uma janela preta vai abrir

### PASSO 3: Aguarde a geração
- O script vai gerar 4 vídeos
- Tempo estimado: 10-20 minutos (depende da GPU)
- Quando terminar, os vídeos estarão em: `C:\Users\User\Downloads\Deriva_Videos\`

---

## 📊 Os 4 vídeos que serão gerados:

1. **Nebulosa Cósmica** (3-5 seg)
   - Espaço profundo com nebulosa colorida
   
2. **Estação Espacial** (3-5 seg)
   - Nave/estação drifting no espaço
   
3. **Ondas de Energia** (3-5 seg)
   - Partículas de luz cósmica
   
4. **Jornada Estelar** (3-5 seg)
   - Viagem através das estrelas

---

## ⚠️ Se algo der errado:

### Erro: "Não consegui conectar ao ComfyUI"
- ✅ Solução: Abra o ComfyUI e deixe rodando
- ✅ Verifique se está em: http://127.0.0.1:8000

### Erro: "Python não encontrado"
- ✅ Solução: Instale Python de https://www.python.org
- ✅ Marque "Add Python to PATH" durante instalação

### Erro: "Timeout"
- ✅ Solução: Sua GPU pode estar lenta
- ✅ Tente novamente ou aumente o timeout no script

---

## 🎬 Próximos passos (após gerar os vídeos):

### 1. Abra o CapCut
- Crie um novo projeto
- Importe os 4 vídeos gerados

### 2. Sincronize com o áudio
- Importe: `ep1_coragem_expandido.mp3`
- Sincronize com os vídeos
- Adicione jazz ambient em background (opcional)

### 3. Crie a thumbnail
- Abra o Canva Pro
- Crie uma thumbnail atrativa
- Use cores cósmicas (azul, roxo, preto)

### 4. Publique no YouTube
- Faça upload do vídeo
- Adicione descrição com o roteiro
- Publique!

---

## 📁 Arquivos inclusos:

```
Deriva_Estelar_EP1/
├── gerar_videos_comfyui_api.py      ← Script principal
├── EXECUTAR_GERACAO.bat              ← Clique duplo para rodar
├── ep1_coragem_expandido.mp3         ← Áudio (10.5 min)
├── roteiro_ep1_coragem_expandido.md  ← Roteiro
└── LEIA_PRIMEIRO.md                  ← Este arquivo
```

---

## 💡 Dicas:

✨ **Para melhor resultado:**
- Use CapCut Pro (versão paga) para mais efeitos
- Adicione transições suaves entre os vídeos
- Use jazz ambient como background music
- Deixe silêncios estratégicos para contemplação

✨ **Para próximos episódios:**
- Reutilize este mesmo workflow
- Mude apenas os prompts dos vídeos
- Mantenha a estrutura de 4 vídeos curtos que repetem

---

## 🎯 Objetivo final:

Um episódio de **15-20 minutos** com:
- ✅ Diálogo profundo sobre Coragem
- ✅ Visuais cósmicos hipnotizantes
- ✅ Jazz ambient contemplativo
- ✅ Pronto para publicar no YouTube

---

## ❓ Dúvidas?

Se algo não funcionar:
1. Verifique se ComfyUI está aberto
2. Tente executar o script novamente
3. Se persistir, me avisa!

---

**Boa sorte com Deriva Estelar! 🚀✨**

Criado com ❤️ para Gabriel Schuan - Ginkgo AI Systems
