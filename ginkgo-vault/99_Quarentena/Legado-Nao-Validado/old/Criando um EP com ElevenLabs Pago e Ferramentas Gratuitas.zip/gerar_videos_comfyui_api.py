#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🎬 Gerador de Vídeos - Deriva Estelar
Conecta ao ComfyUI via API e gera 4 vídeos automaticamente
Para Windows - Execute com: python gerar_videos_comfyui_api.py
"""

import requests
import json
import time
import os
import sys
from pathlib import Path

# Configuração
COMFYUI_URL = "http://127.0.0.1:8000"
OUTPUT_DIR = Path.home() / "Downloads" / "Deriva_Videos"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

print("\n" + "="*70)
print("🎬 GERADOR DE VÍDEOS - DERIVA ESTELAR")
print("="*70)
print(f"📍 ComfyUI: {COMFYUI_URL}")
print(f"📁 Saída: {OUTPUT_DIR}\n")

# Prompts para os 4 vídeos
VIDEOS = [
    {
        "name": "Nebulosa Cósmica",
        "filename": "01_nebulosa",
        "prompt": "deep space, colorful nebula, cosmic dust, stars, cinematic, 4k, slow moving camera, universe, ethereal, beautiful, purple and blue colors, space background",
        "negative": "text, watermark, logo, blurry, low quality, distorted, people, faces"
    },
    {
        "name": "Estação Espacial",
        "filename": "02_estacao",
        "prompt": "abandoned space station, drifting in space, stars background, cinematic lighting, sci-fi, futuristic, slow pan, mysterious, metallic structure, industrial design",
        "negative": "text, watermark, people, blurry, low quality, distorted, faces"
    },
    {
        "name": "Ondas de Energia",
        "filename": "03_ondas",
        "prompt": "cosmic energy waves, light particles, space, universe, abstract, ethereal, glowing, cinematic, slow motion, blue and purple energy, particles flowing",
        "negative": "text, watermark, logo, blurry, distorted, low quality, people, faces"
    },
    {
        "name": "Jornada Estelar",
        "filename": "04_jornada",
        "prompt": "traveling through stars, cosmic journey, nebula clouds, space dust, beautiful universe, cinematic, slow movement, hyperspace, warp effect, motion blur",
        "negative": "text, watermark, people, blurry, low quality, distorted, faces"
    }
]

def test_connection():
    """Testa conexão com ComfyUI"""
    try:
        response = requests.get(f"{COMFYUI_URL}/system_stats", timeout=5)
        if response.status_code == 200:
            print("✅ Conexão com ComfyUI estabelecida!")
            return True
    except Exception as e:
        print(f"❌ ERRO: Não consegui conectar ao ComfyUI!")
        print(f"   URL: {COMFYUI_URL}")
        print(f"   Erro: {e}")
        print(f"\n⚠️  SOLUÇÃO:")
        print(f"   1. Certifique-se que ComfyUI está ABERTO")
        print(f"   2. Verifique se está rodando em http://127.0.0.1:8000")
        print(f"   3. Tente novamente\n")
        return False

def create_workflow(prompt, negative_prompt):
    """Cria workflow para Stability AI"""
    workflow = {
        "1": {
            "inputs": {
                "prompt": prompt,
                "negative_prompt": negative_prompt,
                "width": 512,
                "height": 512,
                "num_inference_steps": 20,
                "guidance_scale": 7.5,
                "num_images": 1
            },
            "class_type": "StabilityAI_Sampler"
        },
        "2": {
            "inputs": {
                "images": ["1", 0]
            },
            "class_type": "PreviewImage"
        }
    }
    return workflow

def submit_workflow(workflow):
    """Submete workflow para execução"""
    try:
        response = requests.post(
            f"{COMFYUI_URL}/api/prompt",
            json={"prompt": workflow},
            timeout=30
        )
        if response.status_code == 200:
            data = response.json()
            return data.get("prompt_id")
    except Exception as e:
        print(f"   ⚠️  Erro ao submeter: {e}")
    return None

def wait_for_completion(prompt_id, timeout=600):
    """Aguarda conclusão"""
    start_time = time.time()
    dots = 0
    while time.time() - start_time < timeout:
        try:
            response = requests.get(
                f"{COMFYUI_URL}/api/history/{prompt_id}",
                timeout=10
            )
            if response.status_code == 200:
                history = response.json()
                if prompt_id in history:
                    return True
        except:
            pass
        
        dots = (dots + 1) % 4
        print(f"   ⏳ Processando" + "." * dots + " " * (3 - dots), end="\r")
        time.sleep(2)
    
    return False

def generate_video(video_config):
    """Gera um vídeo"""
    name = video_config["name"]
    prompt = video_config["prompt"]
    negative = video_config["negative"]
    
    print(f"\n🎬 {name}")
    print(f"   Prompt: {prompt[:50]}...")
    
    workflow = create_workflow(prompt, negative)
    prompt_id = submit_workflow(workflow)
    
    if not prompt_id:
        print(f"   ❌ Falha ao submeter")
        return False
    
    if wait_for_completion(prompt_id):
        print(f"   ✅ Gerado com sucesso!")
        return True
    else:
        print(f"   ❌ Timeout")
        return False

def main():
    """Função principal"""
    
    if not test_connection():
        input("\n⏸️  Pressione ENTER para sair...")
        return
    
    print("\n" + "="*70)
    print("🚀 INICIANDO GERAÇÃO DE 4 VÍDEOS")
    print("="*70)
    
    success_count = 0
    
    for i, video in enumerate(VIDEOS, 1):
        print(f"\n[{i}/4] ", end="")
        if generate_video(video):
            success_count += 1
        time.sleep(1)
    
    print("\n" + "="*70)
    print(f"✅ RESUMO: {success_count}/{len(VIDEOS)} vídeos gerados!")
    print("="*70)
    print(f"\n📁 Vídeos salvos em:")
    print(f"   {OUTPUT_DIR}")
    print(f"\n🎬 PRÓXIMOS PASSOS:")
    print(f"   1. Abra o CapCut")
    print(f"   2. Importe os 4 vídeos gerados")
    print(f"   3. Sincronize com o áudio: ep1_coragem_expandido.mp3")
    print(f"   4. Crie a thumbnail no Canva")
    print(f"   5. Publique no YouTube!")
    print(f"\n✨ Boa sorte com Deriva Estelar!\n")
    
    input("⏸️  Pressione ENTER para sair...")

if __name__ == "__main__":
    main()
