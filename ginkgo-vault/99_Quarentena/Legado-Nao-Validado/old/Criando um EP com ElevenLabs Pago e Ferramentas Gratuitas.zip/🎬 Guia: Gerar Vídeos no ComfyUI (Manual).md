# 🎬 Guia: Gerar Vídeos no ComfyUI (Manual)

## Resumo
Você vai criar **4 vídeos de espaço** diretamente no ComfyUI, sem usar Python.

---

## Passo 1: Preparar o ComfyUI

1. **Abra o ComfyUI** (já está aberto)
2. Verifique que está em: `http://127.0.0.1:8000`
3. Você deve ver a interface com o Graph Editor

---

## Passo 2: Criar o Primeiro Vídeo (Nebulosa)

### 2.1 Adicionar Nós

No ComfyUI, você vai adicionar nós (blocos) que formam um workflow.

**Clique em "Add Node" ou use o menu** e adicione estes nós na ordem:

1. **Load Checkpoint**
   - Clique em "Loaders" → "Load Checkpoint"
   - Selecione: `sd_xl_base_1.0.safetensors`

2. **CLIP Text Encode (Prompt)**
   - Clique em "conditioning" → "CLIP Text Encode (Prompt)"
   - Cole este texto no campo "text":
     ```
     deep space, colorful nebula, cosmic dust, stars, cinematic, 4k, slow moving camera, universe, ethereal, beautiful
     ```

3. **CLIP Text Encode (Negative)**
   - Clique em "conditioning" → "CLIP Text Encode (Prompt)" novamente
   - Cole este texto no campo "text":
     ```
     text, watermark, logo, blurry, low quality, distorted
     ```

4. **Empty Latent Video**
   - Clique em "latent" → "Empty Latent Video"
   - Deixe os valores padrão (512x512, 24 frames)

5. **KSampler**
   - Clique em "sampling" → "KSampler"
   - Conecte:
     - "model" do Checkpoint → "model" do KSampler
     - "CLIP" do Checkpoint → "clip" do KSampler
     - Positive (CLIP Text Encode 1) → "positive" do KSampler
     - Negative (CLIP Text Encode 2) → "negative" do KSampler
     - "Empty Latent Video" → "latent_image" do KSampler

6. **VAE Decode**
   - Clique em "latent" → "VAE Decode"
   - Conecte "samples" do KSampler → "samples" do VAE Decode
   - Conecte "VAE" do Checkpoint → "vae" do VAE Decode

7. **Save Image**
   - Clique em "image" → "Save Image"
   - Conecte "IMAGE" do VAE Decode → "images" do Save Image
   - No campo "filename_prefix", escreva: `deriva_nebula`

### 2.2 Executar

1. Clique no botão azul **"Queue Prompt"** (ou "Run")
2. Aguarde o processamento (pode levar 5-10 minutos)
3. Quando terminar, você verá a imagem salva

---

## Passo 3: Criar o Segundo Vídeo (Estação Espacial)

**Repita o Passo 2, mas mude:**

- **Prompt (CLIP Text Encode 1):**
  ```
  abandoned space station, drifting in space, stars background, cinematic lighting, sci-fi, futuristic, slow pan, mysterious
  ```

- **Negative (CLIP Text Encode 2):**
  ```
  text, watermark, people, blurry, low quality
  ```

- **Filename:** `deriva_station`

---

## Passo 4: Criar o Terceiro Vídeo (Ondas de Luz)

**Repita o Passo 2, mas mude:**

- **Prompt (CLIP Text Encode 1):**
  ```
  cosmic energy waves, light particles, space, universe, abstract, ethereal, glowing, cinematic, slow motion
  ```

- **Negative (CLIP Text Encode 2):**
  ```
  text, watermark, logo, blurry, distorted, low quality
  ```

- **Filename:** `deriva_waves`

---

## Passo 5: Criar o Quarto Vídeo (Jornada Estelar)

**Repita o Passo 2, mas mude:**

- **Prompt (CLIP Text Encode 1):**
  ```
  traveling through stars, cosmic journey, nebula clouds, space dust, beautiful universe, cinematic, slow movement
  ```

- **Negative (CLIP Text Encode 2):**
  ```
  text, watermark, people, blurry, low quality, distorted
  ```

- **Filename:** `deriva_journey`

---

## Passo 6: Encontrar os Vídeos Gerados

Os vídeos serão salvos em:
```
C:\Users\User\AppData\Local\Programs\ComfyUI\output\
```

Você deve ter 4 arquivos:
- `deriva_nebula_00001.png` (ou `.mp4`)
- `deriva_station_00001.png` (ou `.mp4`)
- `deriva_waves_00001.png` (ou `.mp4`)
- `deriva_journey_00001.png` (ou `.mp4`)

---

## Passo 7: Montar no CapCut

Agora que você tem os vídeos, siga o guia anterior para montar no CapCut:

1. Abra o **CapCut**
2. Crie um novo projeto (1920x1080)
3. Importe o áudio: `ep1_coragem_expandido.mp3`
4. Importe os 4 vídeos
5. Arraste para a timeline e repita para preencher 10.5 minutos
6. Adicione transições entre os vídeos
7. Exporte como MP4 1080p

---

## 🐛 Solução de Problemas

### ❌ "Modelo não encontrado"
- O ComfyUI vai tentar baixar automaticamente
- Verifique se tem internet e espaço em disco (10+ GB)

### ❌ "Erro de memória"
- Reduza o tamanho dos vídeos (de 512x512 para 384x384)
- Reduza os passos (de 20 para 15)

### ❌ "Vídeo muito lento/rápido"
- Ajuste no CapCut a velocidade ou duração

---

## 💡 Dica: Importar Workflow

Se quiser economizar tempo, você pode importar o workflow JSON:

1. Clique em "Load" no ComfyUI
2. Selecione o arquivo `workflow_deriva_videos.json`
3. Clique em "Load"
4. O workflow vai aparecer pronto para usar

Depois é só mudar os prompts e clicar em "Run"!

---

**Bom trabalho! 🚀**
