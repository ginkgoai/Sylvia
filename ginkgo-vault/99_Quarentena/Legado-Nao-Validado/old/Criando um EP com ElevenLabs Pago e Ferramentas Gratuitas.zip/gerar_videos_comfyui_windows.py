#!/usr/bin/env python3
"""
Script para gerar vídeos de espaço/universo usando ComfyUI API
Otimizado para RTX 4060 (6GB VRAM)
Versão Windows - Execute com: python gerar_videos_comfyui_windows.py
"""

import requests
import json
import time
import os
import sys
from pathlib import Path

# Configuração
COMFYUI_URL = "http://127.0.0.1:8000"
OUTPUT_DIR = Path("C:/Users/User/OneDrive/Área de Trabalho/G-Tech/Administração Interna/ASSETS/deriva_videos")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Prompts para gerar vídeos de espaço
VIDEO_PROMPTS = [
    {
        "name": "deep_space_nebula",
        "prompt": "deep space, colorful nebula, cosmic dust, stars, cinematic, 4k, slow moving camera, universe, ethereal, beautiful",
        "negative": "text, watermark, logo, blurry, low quality, distorted"
    },
    {
        "name": "space_station_drift",
        "prompt": "abandoned space station, drifting in space, stars background, cinematic lighting, sci-fi, futuristic, slow pan, mysterious",
        "negative": "text, watermark, people, blurry, low quality"
    },
    {
        "name": "cosmic_light_waves",
        "prompt": "cosmic energy waves, light particles, space, universe, abstract, ethereal, glowing, cinematic, slow motion",
        "negative": "text, watermark, logo, blurry, distorted, low quality"
    },
    {
        "name": "stellar_journey",
        "prompt": "traveling through stars, cosmic journey, nebula clouds, space dust, beautiful universe, cinematic, slow movement",
        "negative": "text, watermark, people, blurry, low quality, distorted"
    }
]

def test_connection():
    """Testar conexão com ComfyUI"""
    try:
        response = requests.get(f"{COMFYUI_URL}/system_stats")
        if response.status_code == 200:
            print("✅ Conexão com ComfyUI estabelecida!")
            print(f"   URL: {COMFYUI_URL}")
            return True
        else:
            print(f"❌ Erro na conexão: Status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Erro ao conectar: {e}")
        print(f"   Verifique se ComfyUI está rodando em {COMFYUI_URL}")
        return False

def create_video_workflow(prompt_text, negative_text, seed=42):
    """
    Criar um workflow para gerar vídeo
    Otimizado para RTX 4060
    """
    workflow = {
        "1": {
            "inputs": {
                "ckpt_name": "sd_xl_base_1.0.safetensors"
            },
            "class_type": "CheckpointLoaderSimple",
            "_meta": {
                "title": "Load Checkpoint"
            }
        },
        "2": {
            "inputs": {
                "text": prompt_text
            },
            "class_type": "CLIPTextEncode (Prompt)",
            "_meta": {
                "title": "CLIP Text Encode (Prompt)"
            }
        },
        "3": {
            "inputs": {
                "text": negative_text
            },
            "class_type": "CLIPTextEncode (Prompt)",
            "_meta": {
                "title": "CLIP Text Encode (Negative)"
            }
        },
        "4": {
            "inputs": {
                "width": 512,
                "height": 512,
                "length": 24,
                "batch_size": 1
            },
            "class_type": "EmptyLatentVideo",
            "_meta": {
                "title": "Empty Latent Video"
            }
        },
        "5": {
            "inputs": {
                "seed": seed,
                "steps": 20,
                "cfg": 7.5,
                "sampler_name": "euler",
                "scheduler": "normal",
                "denoise": 1,
                "model": ["1", 0],
                "positive": ["2", 0],
                "negative": ["3", 0],
                "latent_image": ["4", 0]
            },
            "class_type": "KSampler",
            "_meta": {
                "title": "KSampler"
            }
        },
        "6": {
            "inputs": {
                "samples": ["5", 0],
                "vae": ["1", 2]
            },
            "class_type": "VAEDecode",
            "_meta": {
                "title": "VAE Decode"
            }
        },
        "7": {
            "inputs": {
                "images": ["6", 0],
                "format": "video/mp4",
                "quality": 95,
                "optimize": True
            },
            "class_type": "VHS_VideoCombine",
            "_meta": {
                "title": "Video Combine"
            }
        },
        "8": {
            "inputs": {
                "filename_prefix": "deriva_video",
                "images": ["6", 0]
            },
            "class_type": "SaveImage",
            "_meta": {
                "title": "Save Image"
            }
        }
    }
    return workflow

def queue_prompt(workflow):
    """Enviar workflow para fila do ComfyUI"""
    try:
        p = {"prompt": workflow}
        data = json.dumps(p).encode('utf-8')
        req = requests.post(f"{COMFYUI_URL}/prompt", data=data)
        
        if req.status_code == 200:
            result = req.json()
            prompt_id = result.get("prompt_id")
            print(f"   ✓ Workflow enviado (ID: {prompt_id})")
            return prompt_id
        else:
            print(f"   ✗ Erro ao enviar workflow: {req.status_code}")
            print(f"   Resposta: {req.text}")
            return None
    except Exception as e:
        print(f"   ✗ Erro: {e}")
        return None

def wait_for_completion(prompt_id, timeout=600):
    """Aguardar conclusão do processamento"""
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        try:
            response = requests.get(f"{COMFYUI_URL}/history/{prompt_id}")
            
            if response.status_code == 200:
                history = response.json()
                
                if prompt_id in history:
                    result = history[prompt_id]
                    
                    if "outputs" in result:
                        print(f"   ✓ Processamento concluído!")
                        return True
                    
                    if "error" in result:
                        print(f"   ✗ Erro no processamento: {result['error']}")
                        return False
            
            print("   ⏳ Processando... (aguarde)")
            time.sleep(5)
            
        except Exception as e:
            print(f"   ✗ Erro ao verificar status: {e}")
            time.sleep(5)
    
    print(f"   ✗ Timeout após {timeout}s")
    return False

def generate_videos():
    """Gerar todos os vídeos"""
    print("\n" + "="*60)
    print("🎬 GERADOR DE VÍDEOS - DERIVA ESTELAR")
    print("="*60 + "\n")
    
    # Testar conexão
    if not test_connection():
        print("\n❌ Não foi possível conectar ao ComfyUI!")
        print("   Certifique-se de que ComfyUI está rodando em http://127.0.0.1:8000")
        print("\n⏸️  Pressione ENTER para sair...")
        input()
        return False
    
    print(f"\n📁 Vídeos serão salvos em: {OUTPUT_DIR}\n")
    
    # Gerar cada vídeo
    for i, video_config in enumerate(VIDEO_PROMPTS, 1):
        print(f"\n[{i}/{len(VIDEO_PROMPTS)}] Gerando: {video_config['name']}")
        print(f"   Prompt: {video_config['prompt'][:60]}...")
        
        # Criar workflow
        workflow = create_video_workflow(
            video_config['prompt'],
            video_config['negative'],
            seed=42 + i
        )
        
        # Enviar para processamento
        prompt_id = queue_prompt(workflow)
        
        if prompt_id:
            # Aguardar conclusão
            if wait_for_completion(prompt_id):
                print(f"   ✅ Vídeo '{video_config['name']}' gerado com sucesso!")
            else:
                print(f"   ⚠️  Vídeo '{video_config['name']}' pode não ter sido gerado corretamente")
        else:
            print(f"   ❌ Falha ao gerar vídeo '{video_config['name']}'")
        
        # Aguardar entre gerações para não sobrecarregar
        if i < len(VIDEO_PROMPTS):
            print("   ⏳ Aguardando antes do próximo vídeo...")
            time.sleep(3)
    
    print("\n" + "="*60)
    print("✅ PROCESSO CONCLUÍDO!")
    print("="*60)
    print(f"\n📁 Verifique os vídeos em: {OUTPUT_DIR}")
    print("\n💡 Próximos passos:")
    print("   1. Abra o CapCut")
    print("   2. Importe os vídeos gerados")
    print("   3. Importe o áudio (será enviado para você)")
    print("   4. Sincronize os vídeos para repetir durante todo o áudio")
    print("   5. Adicione efeitos de transição suave entre os vídeos")
    print("   6. Exporte como MP4 1080p")
    print("\n⏸️  Pressione ENTER para sair...")
    input()

if __name__ == "__main__":
    generate_videos()
