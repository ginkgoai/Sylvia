@echo off
REM Script para gerar vídeos do Deriva Estelar via ComfyUI API
REM Clique duplo para executar

echo.
echo ========================================
echo  GERADOR DE VIDEOS - DERIVA ESTELAR
echo ========================================
echo.

REM Verifica se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo ERRO: Python nao encontrado!
    echo.
    echo Solucao:
    echo 1. Instale Python de https://www.python.org
    echo 2. Marque "Add Python to PATH" durante a instalacao
    echo 3. Reinicie este script
    echo.
    pause
    exit /b 1
)

REM Verifica se requests está instalado
python -c "import requests" >nul 2>&1
if errorlevel 1 (
    echo Instalando bibliotecas necessarias...
    pip install requests -q
)

REM Executa o script
echo Iniciando gerador de videos...
echo.
python "%~dp0gerar_videos_comfyui_api.py"

pause
