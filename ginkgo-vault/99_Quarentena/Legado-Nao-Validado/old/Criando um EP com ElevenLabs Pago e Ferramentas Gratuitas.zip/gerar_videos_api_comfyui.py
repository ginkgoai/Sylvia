#!/usr/bin/env python3
"""
Script para gerar vídeos de espaço via API ComfyUI
Conecta ao ComfyUI em http://127.0.0.1:8000 e gera 4 vídeos para o episódio "Deriva Estelar"
"""

import requests
import json
import time
import os
from pathlib import Path

# Configuração
COMFYUI_URL = "http://127.0.0.1:8000"
OUTPUT_DIR = Path.home() / "Downloads" / "deriva_videos"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

print(f"🎬 Gerador de Vídeos - Deriva Estelar")
print(f"📍 ComfyUI URL: {COMFYUI_URL}")
print(f"📁 Pasta de saída: {OUTPUT_DIR}\n")

# Prompts para os 4 vídeos
VIDEOS = [
    {
        "name": "nebulosa",
        "prompt": "deep space, colorful nebula, cosmic dust, stars, cinematic, 4k, slow moving camera, universe, ethereal, beautiful, purple and blue colors",
        "negative": "text, watermark, logo, blurry, low quality, distorted, people"
    },
    {
        "name": "estacao",
        "prompt": "abandoned space station, drifting in space, stars background, cinematic lighting, sci-fi, futuristic, slow pan, mysterious, metallic structure",
        "negative": "text, watermark, people, blurry, low quality, distorted"
    },
    {
        "name": "ondas",
        "prompt": "cosmic energy waves, light particles, space, universe, abstract, ethereal, glowing, cinematic, slow motion, blue and purple energy",
        "negative": "text, watermark, logo, blurry, distorted, low quality, people"
    },
    {
        "name": "jornada",
        "prompt": "traveling through stars, cosmic journey, nebula clouds, space dust, beautiful universe, cinematic, slow movement, hyperspace, warp effect",
        "negative": "text, watermark, people, blurry, low quality, distorted"
    }
]

def test_connection():
    """Testa conexão com ComfyUI"""
    try:
        response = requests.get(f"{COMFYUI_URL}/system_stats", timeout=5)
        if response.status_code == 200:
            print("✅ Conexão com ComfyUI estabelecida!\n")
            return True
    except Exception as e:
        print(f"❌ Erro ao conectar com ComfyUI: {e}")
        print(f"   Certifique-se que ComfyUI está rodando em {COMFYUI_URL}\n")
        return False

def create_workflow(prompt, negative_prompt):
    """
    Cria um workflow para gerar imagem/vídeo com Stability AI
    """
    workflow = {
        "1": {
            "inputs": {
                "prompt": prompt,
                "negative_prompt": negative_prompt,
                "width": 512,
                "height": 512,
                "num_inference_steps": 20,
                "guidance_scale": 7.5,
                "num_images": 1
            },
            "class_type": "StabilityAI_Sampler"
        },
        "2": {
            "inputs": {
                "images": ["1", 0]
            },
            "class_type": "PreviewImage"
        }
    }
    return workflow

def submit_workflow(workflow):
    """Submete workflow para execução"""
    try:
        response = requests.post(
            f"{COMFYUI_URL}/api/prompt",
            json={"prompt": workflow},
            timeout=30
        )
        if response.status_code == 200:
            data = response.json()
            return data.get("prompt_id")
        else:
            print(f"   ⚠️  Erro ao submeter workflow: {response.status_code}")
            return None
    except Exception as e:
        print(f"   ⚠️  Erro na requisição: {e}")
        return None

def wait_for_completion(prompt_id, timeout=600):
    """Aguarda conclusão da execução"""
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            response = requests.get(
                f"{COMFYUI_URL}/api/history/{prompt_id}",
                timeout=10
            )
            if response.status_code == 200:
                history = response.json()
                if prompt_id in history:
                    return True
        except Exception as e:
            print(f"   ⚠️  Erro ao verificar status: {e}")
        
        time.sleep(2)
    
    return False

def generate_video(video_config):
    """Gera um vídeo com as configurações fornecidas"""
    name = video_config["name"]
    prompt = video_config["prompt"]
    negative = video_config["negative"]
    
    print(f"🎬 Gerando vídeo: {name.upper()}")
    print(f"   Prompt: {prompt[:60]}...")
    
    # Criar workflow
    workflow = create_workflow(prompt, negative)
    
    # Submeter para execução
    prompt_id = submit_workflow(workflow)
    if not prompt_id:
        print(f"   ❌ Falha ao submeter workflow\n")
        return False
    
    print(f"   ⏳ Processando (ID: {prompt_id[:8]}...)...")
    
    # Aguardar conclusão
    if wait_for_completion(prompt_id):
        print(f"   ✅ Vídeo '{name}' gerado com sucesso!\n")
        return True
    else:
        print(f"   ❌ Timeout ao gerar vídeo\n")
        return False

def main():
    """Função principal"""
    
    # Testar conexão
    if not test_connection():
        return
    
    print("=" * 60)
    print("🚀 Iniciando geração de 4 vídeos para Deriva Estelar")
    print("=" * 60 + "\n")
    
    success_count = 0
    
    for i, video in enumerate(VIDEOS, 1):
        print(f"[{i}/4] ", end="")
        if generate_video(video):
            success_count += 1
        time.sleep(2)  # Pausa entre gerações
    
    print("=" * 60)
    print(f"✅ Resumo: {success_count}/{len(VIDEOS)} vídeos gerados com sucesso!")
    print(f"📁 Vídeos salvos em: {OUTPUT_DIR}")
    print("=" * 60)
    print("\n🎬 Próximo passo: Abra o CapCut e monte o episódio!")
    print("   1. Importe os 4 vídeos")
    print("   2. Sincronize com o áudio 'ep1_coragem_expandido.mp3'")
    print("   3. Publique no YouTube!\n")

if __name__ == "__main__":
    main()
