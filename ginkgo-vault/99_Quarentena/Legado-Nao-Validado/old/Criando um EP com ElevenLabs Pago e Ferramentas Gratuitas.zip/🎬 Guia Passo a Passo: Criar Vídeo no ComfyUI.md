# 🎬 Guia Passo a Passo: Criar Vídeo no ComfyUI

## VÍDEO 1: NEBULOSA CÓSMICA

---

### PASSO 1: Adicionar o Primeiro Nó (Load Checkpoint)

1. **Clique com botão direito** na área vazia cinza (meio da tela do Graph)
2. Um menu vai aparecer
3. Procure por: **"Load Checkpoint"** (ou procure em "loaders")
4. Clique nele
5. Um bloco azul/roxo vai aparecer com o título "Load Checkpoint"

**Resultado esperado:** Você vê um bloco com a opção de selecionar um modelo

---

### PASSO 2: Configurar o Checkpoint

1. No bloco "Load Checkpoint", procure por um dropdown que diz "ckpt_name"
2. Clique no dropdown
3. Procure por: **"sd_xl_base_1.0.safetensors"**
4. Clique nele para selecionar

**Resultado esperado:** O modelo está selecionado

---

### PASSO 3: Adicionar o Segundo Nó (CLIP Text Encode - Prompt Positivo)

1. **Clique com botão direito** em uma área vazia perto do primeiro bloco
2. Procure por: **"CLIP Text Encode (Prompt)"** (ou em "conditioning")
3. Clique nele
4. Um novo bloco vai aparecer

**Resultado esperado:** Você tem 2 blocos agora

---

### PASSO 4: Adicionar o Texto do Prompt Positivo

1. No novo bloco "CLIP Text Encode (Prompt)", procure por um campo de texto grande
2. **Clique dentro do campo de texto**
3. **Apague o texto que está lá** (se houver)
4. **Cole este texto:**
   ```
   deep space, colorful nebula, cosmic dust, stars, cinematic, 4k, slow moving camera, universe, ethereal, beautiful
   ```
5. **Pressione Enter ou clique fora do campo**

**Resultado esperado:** O texto está no campo

---

### PASSO 5: Adicionar o Terceiro Nó (CLIP Text Encode - Prompt Negativo)

1. **Clique com botão direito** em uma área vazia
2. Procure por: **"CLIP Text Encode (Prompt)"** novamente
3. Clique nele
4. Um terceiro bloco vai aparecer

**Resultado esperado:** Você tem 3 blocos agora

---

### PASSO 6: Adicionar o Texto do Prompt Negativo

1. No terceiro bloco, procure pelo campo de texto
2. **Clique dentro do campo de texto**
3. **Apague o texto que está lá**
4. **Cole este texto:**
   ```
   text, watermark, logo, blurry, low quality, distorted
   ```
5. **Pressione Enter ou clique fora do campo**

**Resultado esperado:** O texto negativo está no campo

---

### PASSO 7: Adicionar o Quarto Nó (Empty Latent Video)

1. **Clique com botão direito** em uma área vazia
2. Procure por: **"Empty Latent Video"** (ou em "latent")
3. Clique nele
4. Um quarto bloco vai aparecer

**Resultado esperado:** Você tem 4 blocos agora

---

### PASSO 8: Configurar Empty Latent Video

1. No bloco "Empty Latent Video", procure pelos campos:
   - **width**: deixe como 512
   - **height**: deixe como 512
   - **length**: deixe como 24
   - **batch_size**: deixe como 1

**Resultado esperado:** Os valores estão configurados (deixe os padrões)

---

### PASSO 9: Adicionar o Quinto Nó (KSampler)

1. **Clique com botão direito** em uma área vazia
2. Procure por: **"KSampler"** (ou em "sampling")
3. Clique nele
4. Um quinto bloco vai aparecer

**Resultado esperado:** Você tem 5 blocos agora

---

### PASSO 10: Conectar os Nós (Parte 1)

Agora você vai conectar os blocos com linhas. Procure pelos "plugs" (círculos) nas laterais dos blocos.

**Conexão 1: Checkpoint → KSampler**
1. No bloco "Load Checkpoint", procure pelo plug chamado **"MODEL"** (lado direito)
2. **Clique e arraste** esse plug até o plug **"model"** do bloco KSampler
3. Uma linha vai aparecer conectando os dois

**Resultado esperado:** Uma linha conecta Checkpoint ao KSampler

---

### PASSO 11: Conectar os Nós (Parte 2)

**Conexão 2: Checkpoint CLIP → KSampler**
1. No bloco "Load Checkpoint", procure pelo plug **"CLIP"** (lado direito)
2. **Clique e arraste** até o plug **"clip"** do KSampler
3. Uma linha vai aparecer

**Resultado esperado:** Outra linha conecta Checkpoint ao KSampler

---

### PASSO 12: Conectar os Nós (Parte 3)

**Conexão 3: Prompt Positivo → KSampler**
1. No segundo bloco (CLIP Text Encode com o prompt positivo), procure pelo plug **"CONDITIONING"** (lado direito)
2. **Clique e arraste** até o plug **"positive"** do KSampler
3. Uma linha vai aparecer

**Resultado esperado:** Linha conecta o prompt positivo ao KSampler

---

### PASSO 13: Conectar os Nós (Parte 4)

**Conexão 4: Prompt Negativo → KSampler**
1. No terceiro bloco (CLIP Text Encode com o prompt negativo), procure pelo plug **"CONDITIONING"** (lado direito)
2. **Clique e arraste** até o plug **"negative"** do KSampler
3. Uma linha vai aparecer

**Resultado esperado:** Linha conecta o prompt negativo ao KSampler

---

### PASSO 14: Conectar os Nós (Parte 5)

**Conexão 5: Empty Latent Video → KSampler**
1. No bloco "Empty Latent Video", procure pelo plug **"LATENT"** (lado direito)
2. **Clique e arraste** até o plug **"latent_image"** do KSampler
3. Uma linha vai aparecer

**Resultado esperado:** Linha conecta Empty Latent Video ao KSampler

---

### PASSO 15: Adicionar o Sexto Nó (VAE Decode)

1. **Clique com botão direito** em uma área vazia
2. Procure por: **"VAE Decode"** (ou em "latent")
3. Clique nele
4. Um sexto bloco vai aparecer

**Resultado esperado:** Você tem 6 blocos agora

---

### PASSO 16: Conectar VAE Decode

**Conexão 6: KSampler → VAE Decode**
1. No bloco KSampler, procure pelo plug **"LATENT"** (lado direito)
2. **Clique e arraste** até o plug **"samples"** do VAE Decode
3. Uma linha vai aparecer

**Resultado esperado:** Linha conecta KSampler ao VAE Decode

---

### PASSO 17: Conectar VAE do Checkpoint

**Conexão 7: Checkpoint VAE → VAE Decode**
1. No bloco "Load Checkpoint", procure pelo plug **"VAE"** (lado direito)
2. **Clique e arraste** até o plug **"vae"** do VAE Decode
3. Uma linha vai aparecer

**Resultado esperado:** Linha conecta Checkpoint ao VAE Decode

---

### PASSO 18: Adicionar o Sétimo Nó (Save Image)

1. **Clique com botão direito** em uma área vazia
2. Procure por: **"Save Image"** (ou em "image")
3. Clique nele
4. Um sétimo bloco vai aparecer

**Resultado esperado:** Você tem 7 blocos agora

---

### PASSO 19: Conectar Save Image

**Conexão 8: VAE Decode → Save Image**
1. No bloco VAE Decode, procure pelo plug **"IMAGE"** (lado direito)
2. **Clique e arraste** até o plug **"images"** do Save Image
3. Uma linha vai aparecer

**Resultado esperado:** Linha conecta VAE Decode ao Save Image

---

### PASSO 20: Configurar o Nome do Arquivo

1. No bloco "Save Image", procure pelo campo **"filename_prefix"**
2. **Clique dentro do campo**
3. **Apague o texto que está lá**
4. **Escreva:** `deriva_nebula`
5. **Pressione Enter**

**Resultado esperado:** O nome do arquivo está configurado

---

### PASSO 21: Executar o Workflow

1. **Clique no botão azul "Run"** (canto superior direito)
2. Uma barra de progresso vai aparecer
3. Aguarde o processamento (pode levar 5-10 minutos)
4. Quando terminar, você verá uma imagem/vídeo no bloco "Save Image"

**Resultado esperado:** O vídeo foi gerado!

---

### PASSO 22: Encontrar o Arquivo Gerado

1. Abra o File Explorer
2. Navegue até: `C:\Users\User\AppData\Local\Programs\ComfyUI\output\`
3. Procure por um arquivo chamado: `deriva_nebula_00001.png` ou similar
4. **Copie este arquivo para uma pasta de trabalho** (ex: Desktop)

**Resultado esperado:** Você tem o primeiro vídeo salvo!

---

## VÍDEOS 2, 3 e 4

Para criar os próximos 3 vídeos, **repita TODOS os passos acima**, mas mude:

### VÍDEO 2: ESTAÇÃO ESPACIAL

**Passo 4 (Prompt Positivo):**
```
abandoned space station, drifting in space, stars background, cinematic lighting, sci-fi, futuristic, slow pan, mysterious
```

**Passo 6 (Prompt Negativo):**
```
text, watermark, people, blurry, low quality
```

**Passo 20 (Filename):**
```
deriva_station
```

---

### VÍDEO 3: ONDAS DE LUZ CÓSMICA

**Passo 4 (Prompt Positivo):**
```
cosmic energy waves, light particles, space, universe, abstract, ethereal, glowing, cinematic, slow motion
```

**Passo 6 (Prompt Negativo):**
```
text, watermark, logo, blurry, distorted, low quality
```

**Passo 20 (Filename):**
```
deriva_waves
```

---

### VÍDEO 4: JORNADA ESTELAR

**Passo 4 (Prompt Positivo):**
```
traveling through stars, cosmic journey, nebula clouds, space dust, beautiful universe, cinematic, slow movement
```

**Passo 6 (Prompt Negativo):**
```
text, watermark, people, blurry, low quality, distorted
```

**Passo 20 (Filename):**
```
deriva_journey
```

---

## ✅ Checklist Final

Após criar os 4 vídeos, você deve ter:
- ✅ `deriva_nebula_00001.png` (ou .mp4)
- ✅ `deriva_station_00001.png` (ou .mp4)
- ✅ `deriva_waves_00001.png` (ou .mp4)
- ✅ `deriva_journey_00001.png` (ou .mp4)

Todos em: `C:\Users\User\AppData\Local\Programs\ComfyUI\output\`

---

## 🎬 Próximo Passo: CapCut

Quando tiver os 4 vídeos, abra o **CapCut** e siga o guia anterior para montar o episódio!

---

**Dúvidas em algum passo? Me avisa qual número e eu explico melhor! 🚀**
