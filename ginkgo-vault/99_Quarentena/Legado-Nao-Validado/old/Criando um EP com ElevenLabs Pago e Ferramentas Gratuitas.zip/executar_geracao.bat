@echo off
REM Script para gerar vídeos da série Deriva Estelar
REM Clique duplo para executar

echo.
echo ============================================================
echo 🎬 GERADOR DE VÍDEOS - DERIVA ESTELAR
echo ============================================================
echo.

REM Verificar se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ ERRO: Python não está instalado ou não está no PATH
    echo.
    echo Solução:
    echo 1. Instale Python de https://www.python.org
    echo 2. Marque a opção "Add Python to PATH" durante a instalação
    echo 3. Reinicie o computador
    echo.
    pause
    exit /b 1
)

REM Verificar se requests está instalado
python -c "import requests" >nul 2>&1
if errorlevel 1 (
    echo ⏳ Instalando dependências (requests)...
    python -m pip install requests --quiet
)

REM Executar o script
echo ⏳ Iniciando geração de vídeos...
echo.
python gerar_videos_comfyui_windows.py

pause
