# 🎬 GUIA: Gerar Vídeos para Deriva Estelar

## Resumo do Projeto

Você está criando o **Episódio 1: "ANTES DO FIM"** do podcast visual **Deriva Estelar**.

**Status Atual:**
- ✅ Roteiro criado (74 falas, tema: Coragem)
- ✅ Áudio gerado com ElevenLabs (10.5 minutos, 2 vozes)
- ⏳ Vídeos em geração (próximo passo)
- ⏳ Montagem no CapCut (após vídeos)
- ⏳ Upload no YouTube (final)

---

## Passo 1: Preparar os Arquivos

1. **Crie uma pasta** em um local fácil de acessar:
   ```
   C:\Users\User\Deriva_Estelar_EP1
   ```

2. **Coloque os arquivos nesta pasta:**
   - `gerar_videos_comfyui_windows.py`
   - `executar_geracao.bat`
   - `roteiro_ep1_coragem_expandido.md`
   - `ep1_coragem_expandido.mp3`

---

## Passo 2: Verificar Pré-requisitos

Antes de gerar os vídeos, certifique-se de:

### ✅ Python Instalado
```bash
# Abra o PowerShell e execute:
python --version
```
Deve mostrar: `Python 3.13.5` (ou similar)

Se não estiver instalado:
1. Vá para https://www.python.org/downloads/
2. Baixe Python 3.10+
3. **IMPORTANTE:** Marque "Add Python to PATH" durante a instalação
4. Reinicie o computador

### ✅ ComfyUI Rodando
- Abra o ComfyUI (clique no atalho ou execute `ComfyUI.exe`)
- Deixe rodando na porta `http://127.0.0.1:8000`
- Você deve ver a interface web do ComfyUI

### ✅ Espaço em Disco
- Precisa de pelo menos **10 GB livres**
- Os modelos de IA serão baixados automaticamente

---

## Passo 3: Gerar os Vídeos

### Opção A: Clique Duplo (Mais Fácil) ⭐

1. Abra a pasta `C:\Users\User\Deriva_Estelar_EP1`
2. **Clique duplo** em `executar_geracao.bat`
3. Uma janela preta (terminal) vai abrir
4. O script vai:
   - ✅ Conectar ao ComfyUI
   - ✅ Baixar modelos (se necessário)
   - ✅ Gerar 4 vídeos de espaço
   - ✅ Salvar em `ASSETS/deriva_videos/`

**Tempo estimado:** 10-20 minutos (depende da GPU)

### Opção B: Terminal (Mais Controle)

1. Abra o PowerShell
2. Navegue até a pasta:
   ```powershell
   cd C:\Users\User\Deriva_Estelar_EP1
   ```
3. Execute:
   ```powershell
   python gerar_videos_comfyui_windows.py
   ```

---

## Passo 4: Verificar os Vídeos Gerados

Após a geração, os vídeos estarão em:
```
C:\Users\User\OneDrive\Área de Trabalho\G-Tech\Administração Interna\ASSETS\deriva_videos\
```

Você deve ter 4 vídeos:
- `deep_space_nebula.mp4` - Nebulosa cósmica
- `space_station_drift.mp4` - Estação espacial à deriva
- `cosmic_light_waves.mp4` - Ondas de luz cósmica
- `stellar_journey.mp4` - Jornada estelar

---

## Passo 5: Montar no CapCut

### 5.1 Criar Novo Projeto
1. Abra o **CapCut**
2. Clique em **"Novo Projeto"**
3. Selecione **"Vertical"** ou **"Horizontal"** (recomendo Horizontal para YouTube)
4. Resolução: **1920x1080** (Full HD)

### 5.2 Importar Áudio
1. Clique em **"Áudio"** (lado esquerdo)
2. Clique em **"Importar Áudio"**
3. Selecione: `ep1_coragem_expandido.mp3`
4. Arraste para a timeline

### 5.3 Importar Vídeos
1. Clique em **"Vídeo"** (lado esquerdo)
2. Clique em **"Importar Vídeo"**
3. Selecione os 4 vídeos gerados
4. Arraste para a timeline (acima do áudio)

### 5.4 Sincronizar Vídeos
1. **Duração total:** 10.5 minutos de áudio
2. **Estratégia:** Repetir os 4 vídeos em loop
   - Cada vídeo tem ~3-5 segundos
   - Copie e cole os vídeos para preencher os 10.5 minutos
   - Crie um padrão: Video1 → Video2 → Video3 → Video4 → Repetir

### 5.5 Adicionar Transições
1. Entre cada vídeo, adicione uma **transição suave**
   - Recomendo: **Fade** ou **Dissolve**
   - Duração: 0.3-0.5 segundos

### 5.6 Ajustar Efeitos (Opcional)
- Adicione um **filtro suave** (ex: "Cinematic" ou "Warm")
- Aumente o **brilho** ligeiramente se necessário
- Adicione **vignette** para efeito mais imersivo

### 5.7 Exportar Vídeo Final
1. Clique em **"Exportar"**
2. Selecione:
   - **Resolução:** 1920x1080 (1080p)
   - **Taxa de quadros:** 30 FPS
   - **Bitrate:** 8-12 Mbps (qualidade alta)
   - **Formato:** MP4
3. Clique em **"Exportar"**
4. Aguarde (~5-10 minutos)

---

## Passo 6: Upload no YouTube

1. Acesse **YouTube Studio**
2. Clique em **"Criar"** → **"Enviar vídeo"**
3. Selecione o vídeo exportado
4. Preencha:
   - **Título:** `Deriva Estelar - Ep. 1: Antes do Fim`
   - **Descrição:** 
     ```
     Episódio 1 da série Deriva Estelar
     Tema: Coragem
     
     Um diálogo contemplativo sobre coragem, medo e estar vivo.
     Ideal para ouvir enquanto trabalha, estuda ou medita.
     
     Narração: ElevenLabs
     Música: Ambient
     Duração: 10.5 minutos
     ```
   - **Visibilidade:** Público/Não listado/Privado (sua escolha)
   - **Thumbnail:** Use uma imagem do Canva (vamos criar depois)

5. Clique em **"Publicar"**

---

## 🐛 Solução de Problemas

### ❌ "Erro ao conectar ao ComfyUI"
**Solução:**
- Verifique se ComfyUI está aberto
- Verifique se está rodando em `http://127.0.0.1:8000`
- Tente reiniciar o ComfyUI

### ❌ "Erro: Modelo não encontrado"
**Solução:**
- O script vai baixar automaticamente
- Verifique se tem espaço em disco (10+ GB)
- Verifique conexão com internet

### ❌ "Python não encontrado"
**Solução:**
- Reinstale Python com "Add to PATH" marcado
- Reinicie o computador
- Tente novamente

### ❌ "Vídeo muito lento/rápido"
**Solução:**
- No CapCut, ajuste a **velocidade** do vídeo
- Ou ajuste a **duração** das transições

---

## 📊 Próximas Fases

Após completar este episódio, você terá:

1. ✅ **Roteiro** (reutilizável)
2. ✅ **Áudio** com vozes IA (reutilizável)
3. ✅ **Vídeos** de espaço (reutilizável)
4. ✅ **Pipeline** documentado (para automatizar próximos episódios)

**Para os próximos episódios:**
- Crie um novo roteiro (tema diferente)
- Gere novo áudio com ElevenLabs
- Reutilize os mesmos vídeos ou gere novos
- Monte no CapCut
- Publique no YouTube

---

## 📞 Suporte

Se encontrar problemas:
1. Verifique a seção "Solução de Problemas"
2. Verifique se todos os pré-requisitos estão OK
3. Tente novamente

---

**Bom trabalho! 🚀**

Qualquer dúvida, é só chamar!
