# TÍTULO: ANTES DO FIM

[Personagem A]: Voz masculina, grave, cansada, mas calma.
[Personagem B]: Voz masculina, um pouco mais leve, reflexiva.

(Silêncio longo, som de estática suave, um zumbido distante de motor de nave)

[Personagem A]: Você me disse uma coisa, muito tempo atrás.

(Pausa de 3 segundos)

[Personagem A]: Disse que já tinha morrido uma vez.

(Pausa de 4 segundos)

[Personagem B]: Eu disse isso?

[Personagem A]: Disse. Estávamos perto daquela estação abandonada. A luz amarela batendo no painel. Você olhou pro vazio e disse isso. Como se fosse um fato qualquer. Como se dissesse que ia chover.

(Pausa de 5 segundos)

[Personagem B]: É estranho o que a gente lembra.

[Personagem A]: Por que você não deixa isso pra trás?

(Pausa de 3 segundos)

[Personagem B]: Deixar o quê?

[Personagem A]: O passado. Essa ideia de que você já acabou.

(Silêncio longo, 6 segundos)

[Personagem B]: Tinha uma pessoa.

(Pausa de 2 segundos)

[Personagem B]: A primeira pessoa que eu conheci que... parecia realmente estar viva.

(Pausa de 4 segundos)

[Personagem B]: Pelo menos, foi o que eu achei na época.

[Personagem A]: E o que isso tem a ver com morrer?

(Pausa de 5 segundos)

[Personagem B]: Ela era uma parte de mim que eu achei que tinha perdido. Ou talvez a outra metade que eu sempre procurei, não sei. As palavras não importam muito agora.

(Pausa de 3 segundos)

[Personagem B]: Quando eu era mais novo, eu não tinha medo de nada.

(Pausa de 2 segundos)

[Personagem B]: Nenhum medo de morrer. Não tinha nem porquê ter. Eu achava que se acontecesse, tudo bem. Deixa pra lá. Não importava a hora, não importava o lugar. Era só um interruptor desligando.

(Pausa de 5 segundos)

[Personagem A]: E o que mudou?

(Pausa de 4 segundos)

[Personagem B]: Eu conheci ela. E tudo mudou.

(Pausa de 3 segundos)

[Personagem B]: Eu comecei a sentir que queria viver. De qualquer maneira. A qualquer custo.

(Pausa de 4 segundos)

[Personagem B]: Pela primeira vez, a ideia de não existir mais começou a me assustar.

(Silêncio longo, 7 segundos)

[Personagem B]: Ela não saía da minha cabeça. Eu nunca tinha me sentido daquele jeito. Era quase... paralisante. O medo de perder o amanhã.

(Pausa de 5 segundos)

[Personagem A]: O medo faz a gente perceber que está aqui.

(Pausa de 4 segundos)

[Personagem B]: Dizem que quando estão prestes a acabar, as pessoas só pensam no passado.

(Pausa de 3 segundos)

[Personagem B]: Como se procurassem uma prova. Uma prova de que realmente estiveram vivas. De que não foi só um sonho longo.

(Silêncio longo, 8 segundos)

[Personagem A]: E onde ela está agora?

(Pausa de 6 segundos)

[Personagem B]: Ela...

(Pausa de 4 segundos)

[Personagem B]: Sumiu por aí.

(Silêncio longo, 10 segundos. O zumbido do motor continua, constante, indiferente.)

[Personagem A]: O espaço é grande demais pra quem procura alguma coisa.

(Pausa de 5 segundos)

[Personagem B]: E pequeno demais pra quem quer esquecer.

(Silêncio longo, 15 segundos. Apenas o som ambiente.)

[Personagem A]: Você acha que a coragem é não ter medo?

(Pausa de 4 segundos)

[Personagem B]: Não.

(Pausa de 3 segundos)

[Personagem B]: A coragem é ter algo a perder. E continuar mesmo assim.

(Pausa de 5 segundos)

[Personagem A]: Então você ainda está vivo.

(Pausa de 6 segundos)

[Personagem B]: Talvez.

(Silêncio longo, 12 segundos)

[Personagem B]: Talvez a gente só descubra no final.

(O som do motor diminui lentamente até sumir. Fim do episódio.)
