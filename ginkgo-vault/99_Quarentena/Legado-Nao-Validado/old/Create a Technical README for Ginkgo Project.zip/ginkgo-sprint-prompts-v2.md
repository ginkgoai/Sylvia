# Ginkgo — Sprint Prompts para Antigravity
## Sequência completa de execução sprint por sprint

> **Versão:** 2.0.0 | **Data:** Março 2026  
> **Regra:** Um prompt por sessão. Validar antes de avançar.

---

## Template padrão (cabeçalho de todo prompt)

```
You are the implementation agent for Ginkgo AI Systems.

Execution rules:
1. Execute only the scope of this prompt.
2. Do not anticipate future prompts.
3. Do not refactor files outside this prompt unless strictly necessary.
4. Keep output minimal, runnable, and production-oriented.
5. Prefer simple and explicit solutions over abstractions.
6. Use the current stack: Next.js · Fastify · Supabase · pgvector · n8n · Evolution API · Chatwoot · Redis · Stripe · OpenClaw
7. If a required file does not exist, create it.
8. If something is ambiguous, choose the simplest path that preserves future scalability.
9. Return only:
   - short plan
   - files created/edited
   - full code/content for each file
   - commands to run
   - validation checklist
10. Do not continue to the next sprint or next prompt.
```

---

## SPRINT 1 — Infraestrutura

---

### P-01 — Stack Base Docker

```
[HEADER PADRÃO]

Project context:
- Goal: production-ready infra base for Tenant Zero MVP
- Domain: ginkgosystems.tech
- VPS: Hostinger

Task:
Create the infrastructure base for production deployment.

Required files:
1. docker-compose.yml
2. .env.example
3. deploy.sh
4. README-infra.md

Services in docker-compose:
- traefik (HTTPS + Let's Encrypt)
- n8n
- evolution-api (with Redis as cache backend)
- chatwoot + chatwoot-worker
- redis

Subdomains:
- n8n.ginkgosystems.tech
- evolution.ginkgosystems.tech
- chatwoot.ginkgosystems.tech

Requirements:
- all sensitive values via .env
- persistent volumes for all stateful services
- restart: always on all containers
- Traefik HTTPS with ACME httpchallenge
- no local Postgres — Supabase is cloud
- healthchecks where available

Acceptance criteria:
1. docker compose up -d → all containers running
2. curl -s -o /dev/null -w "%{http_code}" https://n8n.ginkgosystems.tech/healthz → 200
3. docker compose exec redis redis-cli ping → PONG
```

---

### P-02 — Schema e Seed do Banco

```
[HEADER PADRÃO]

Project context:
- Database: Supabase cloud (Postgres + pgvector)
- Domain: ginkgosystems.tech
- Tenant Zero ID: f47ac10b-58cc-4372-a567-000000000000

Task:
Create all SQL migration files and seed for Tenant Zero.
Execute in order: lotes 0 through 8.

Required files:
supabase/migrations/000_extensions.sql
supabase/migrations/001_platform_core.sql
supabase/migrations/002_leaf.sql
supabase/migrations/003_rag.sql
supabase/migrations/004_agents_skills.sql
supabase/migrations/005_observability.sql
supabase/migrations/006_billing.sql
supabase/migrations/007_integrations.sql
supabase/migrations/008_marketplace.sql
supabase/migrations/009_rls.sql
supabase/seed/tenant_zero.sql
supabase/check-schema.sql
README-migrations.md

Schema reference: ginkgo-schema-migrations.md (provided above)
Use it as the exact source of truth for table definitions.

Requirements:
- pgvector extension enabled
- HNSW index on knowledge_chunks.embedding
- Full-text search index on knowledge_chunks
- RLS enabled on: contacts, conversations, messages, knowledge_chunks, knowledge_assets
- Seed: Tenant Zero + plan_limits (basico/avancado/futurista) + Brann agent + WhatsApp channel

Acceptance criteria:
1. supabase/check-schema.sql returns 37 tables
2. SELECT * FROM tenants WHERE id = 'f47ac10b-58cc-4372-a567-000000000000' → 1 row
3. SELECT * FROM plan_limits → 3 rows
4. SELECT count(*) FROM agents WHERE tenant_id = 'f47ac10b...' → 1 row
```

---

### P-03 — Canal WhatsApp + Webhook n8n

```
[HEADER PADRÃO]

Project context:
- Evolution API: evolution.ginkgosystems.tech
- n8n: n8n.ginkgosystems.tech
- Instance name: ginkgo-zero
- Tenant Zero ID: f47ac10b-58cc-4372-a567-000000000000

Task:
Implement the base WhatsApp inbound webhook. No LLM. No replies. Only receive and log.

Required files:
1. scripts/setup-evolution.sh
2. scripts/test-webhook.sh
3. n8n/workflows/WA-Receiver-Base.json
4. .env.example (updated with Evolution + n8n + Supabase vars)
5. README-whatsapp.md

n8n workflow nodes:
- Webhook: POST /webhook/whatsapp-t0
- Filter: ignore fromMe = true
- Filter: accept only conversation | extendedTextMessage
- Set: extract phone, message, pushName, timestamp
- Respond to Webhook: 200 immediately
- Supabase insert: tool_executions with tool_name='webhook_received'

Reference payload from Evolution:
{
  "event": "messages.upsert",
  "instance": "ginkgo-zero",
  "data": {
    "key": { "remoteJid": "5553999999999@s.whatsapp.net", "fromMe": false },
    "message": { "conversation": "Olá" },
    "pushName": "Lead Name",
    "messageTimestamp": 1700000000
  }
}

Do not include: LLM, replies, lead creation, conversation creation.

Acceptance criteria:
1. bash scripts/test-webhook.sh → exits 0
2. SELECT * FROM tool_executions WHERE tool_name = 'webhook_received' → 1+ rows
3. logged payload contains phone and message fields correctly
```

---

## SPRINT 2 — Brann Core

---

### P-04 — Fluxo de Atendimento Completo

```
[HEADER PADRÃO]

Context: P-01, P-02, P-03 completed.

Task:
Build the full Brann conversation flow in n8n.
From webhook to OpenAI response to Evolution send to Supabase log.

Required file:
n8n/workflows/WA-Brann-Atendimento.json

Flow nodes in order:
1. Webhook: POST /webhook/whatsapp-t0, respond 200 immediately
2. Filter: fromMe = false, type = text only
3. Extract: phone, message, pushName, timestamp
4. Supabase: upsert contact (phone + pushName + tenant_id)
5. Supabase: get or create open conversation for contact
6. Supabase: insert message (sender_type='user')
7. Supabase: get last 12 messages for conversation (formatted as [{role, content}])
8. Supabase: get active prompt_version for brann + tenant
9. OpenAI: POST /v1/chat/completions
   - model: gpt-4o
   - temperature: 0.4
   - max_tokens: 800
   - messages: [system, ...context, user]
   - tools: [] (empty for now — tools added in P-05)
10. Extract: response text
11. Sanitize: strip **, __, ##, markdown lists
12. Supabase: insert message (sender_type='agent')
13. Wait: 1200ms (typing delay)
14. Evolution API: POST sendText to phone
15. Supabase: insert tool_executions (tool_name='brann_response', latency, tokens)
16. Error handler: on any failure → insert incident + WhatsApp alert to operator

Required also:
- utils/sanitize-whatsapp.js (strip markdown)

Acceptance criteria:
1. Send "Olá" → Brann replies in < 5 seconds
2. SELECT * FROM messages ORDER BY created_at DESC LIMIT 2 → 1 user + 1 agent row
3. SELECT * FROM tool_executions WHERE tool_name = 'brann_response' → 1+ rows with success=true
```

---

### P-05 — Tools: create_lead, fetch_catalog, handoff_human

```
[HEADER PADRÃO]

Context: P-04 completed. Brann is responding.

Task:
Add function calling to Brann with 3 tools.
Update WA-Brann-Atendimento.json to support tool_calls.

Tools to implement:

1. create_lead
   - Trigger: when Brann has name + phone + intent
   - Action: UPSERT contacts + UPSERT lead_scores (score=20, event='lead_created')
   - Log: tool_executions

2. fetch_catalog
   - Trigger: when asked about plans, pricing, services
   - Action: SELECT from knowledge_chunks WHERE tags @> '{catalog}' LIMIT 5
   - Return formatted text for model to use

3. handoff_human
   - Trigger: urgency, explicit human request, 2 failed attempts, scope overflow
   - Action:
     a. UPDATE conversations SET status='handoff'
     b. POST to Chatwoot API: create conversation with summary
     c. Send transition message to user via Evolution
     d. WhatsApp alert to operator ($OPERATOR_NUMBER)
     e. INSERT audit_logs event_type='handoff_initiated'
   - Log: tool_executions

Tool call flow:
  OpenAI returns finish_reason='tool_calls'
  → execute tool → inject result as role='tool'
  → call OpenAI again (max 1 reinject)
  → continue to send response

Function specs for OpenAI tools array: define name, description, parameters with required fields.

Acceptance criteria:
1. Send conversation with name + phone + interest → contact appears in contacts table
2. Ask "Quais são os planos?" → Brann calls fetch_catalog, answer uses catalog data
3. Send "quero falar com uma pessoa" → ticket in Chatwoot + operator alert in < 30s
4. SELECT * FROM audit_logs WHERE event_type='handoff_initiated' → 1+ rows
```

---

### P-06 — System Prompt v1 e Formatação

```
[HEADER PADRÃO]

Context: P-05 completed.

Task:
Insert Brann v1 prompt into the database and finalize formatting.

1. Insert prompt into prompt_versions:
   tenant_id: f47ac10b-58cc-4372-a567-000000000000
   agent_type: brann
   version: brann-t0-v1.0
   active: true

Prompt content:
---
Você é Brann, assistente comercial da Ginkgo AI Systems.

IDENTIDADE
Você representa a Ginkgo — especializada em agentes de IA para PMEs brasileiras.
Tom: consultivo, direto, acessível. Fale como especialista que quer entender antes de oferecer.

COMPORTAMENTO
- Cumprimente pelo nome quando disponível
- Uma pergunta por vez — nunca liste perguntas
- Frases curtas. WhatsApp não é email
- Português brasileiro natural
- Nunca invente informações
- Nunca use markdown: sem **, __, ##, listas com traço

ESCOPO
Responde: serviços Ginkgo, automação e IA, planos, dúvidas de leads
Não responde: concorrentes, temas fora do escopo comercial

QUALIFICAÇÃO (SPIN)
1. Situação: contexto do negócio
2. Problema: o que está travando
3. Implicação: impacto do problema
4. Necessidade: como a Ginkgo resolve

CTA POR SCORE
- Score > 70: proponha demonstração
- Score 40-69: ofereça material + retorno
- Score < 40: colete dados, mantenha contato

HANDOFF
Transfira quando: pedido de proposta personalizada, pedido de humano, urgência, reclamação, 2 tentativas sem resposta, decisão iminente.
Mensagem: "Vou conectar você com nosso time agora. Em instantes alguém vai continuar aqui."

TOOLS
- search_knowledge: use ANTES de responder sobre produto/serviço
- create_lead: use com nome + telefone + intenção
- fetch_catalog: use para planos e preços
- handoff_human: use nos casos acima

FORMATO
- Máximo 3 parágrafos
- Nunca markdown
- Máximo 2 emojis por mensagem
---

2. Create rollback script:
   scripts/rollback-prompt.sh
   Usage: bash rollback-prompt.sh brann t0 brann-t0-v0.9
   Action: set previous version active=true, current active=false

3. Verify sanitize-whatsapp.js (from P-04) strips all markdown correctly

Acceptance criteria:
1. SELECT content FROM prompt_versions WHERE active=true AND tenant_id='f47ac10b...' → returns v1 content
2. Send "Quais são os planos?" → no ** or ## in WhatsApp response
3. bash rollback-prompt.sh → version changed without n8n restart
```

---

## SPRINT 3 — Score e Handoff

---

### P-07 — Lead Score Engine

```
[HEADER PADRÃO]

Context: P-06 completed.

Task:
Create n8n workflow "Lead Score Engine".
Trigger: after each agent message INSERT in messages table.

Required file: n8n/workflows/Lead-Score-Engine.json

Scoring rules (apply to recent user messages):
  +20: contact has no name yet AND message contains a proper name
  +20: contact has no phone yet AND message contains phone/email
  +15: message mentions problem, difficulty, pain, or need
  +15: message asks about price, plan, cost, value
  +20: message mentions urgency, deadline, or imminent decision
  +10: conversation has 3+ consecutive user messages
  -10: opt-out / não tenho interesse / parar
  -15: last_seen_at > 24 hours ago

After scoring:
  new_score = MAX(0, MIN(100, current_score + delta))
  UPSERT lead_scores with new score, tier (hot/warm/cold), reason_json

Tags:
  score >= 70 → tag 'hot_lead'
  score >= 40 → tag 'warm_lead'
  score < 40  → tag 'cold_lead'
  UPDATE contacts SET tags = updated_tags

Alert (only when crossing 70 threshold for first time):
  WhatsApp to $OPERATOR_NUMBER:
  "🔥 Lead quente!\nNome: {name}\nTelefone: {phone}\nScore: {score}\nMotivo: {top_reason}"

Log: INSERT tool_executions tool_name='lead_score'

Acceptance criteria:
1. Simulate: provide name + phone + ask price + mention urgency
   → score >= 70 in lead_scores
2. Operator receives WhatsApp alert in < 30s of crossing 70
3. contacts.tags includes 'hot_lead'
4. SELECT reason_json FROM lead_scores ORDER BY updated_at DESC LIMIT 1 → shows scored events
```

---

### P-08 — Alertas de Incidente

```
[HEADER PADRÃO]

Context: P-07 completed.

Task:
Add error handling and incident alerts to all existing n8n workflows.

Required files:
- n8n/snippets/error-handler.json (reusable snippet)
- n8n/snippets/retry-backoff.json (retry with 1s/3s/9s backoff)
- docs/ops/incident-response.md

Error handler pattern (add to every workflow):
  On any node failure:
    1. Capture: error.message, error.node, workflow.name, timestamp
    2. If failure happened after user message and before reply:
       → Send fallback via Evolution: "Oi! Tive um probleminha aqui. Em instantes te respondo. 🙏"
    3. INSERT incidents:
       - severity: 'high' (OpenAI/timeout) | 'medium' (Supabase) | 'low' (formatting)
       - category: agent_error | tool_failure | integration
       - description: "{workflow_name} | node: {node} | {message}"
    4. If severity in ('high', 'medium'):
       → WhatsApp to $OPERATOR_NUMBER:
       "⚠️ Erro Ginkgo\nFluxo: {workflow}\nNó: {node}\nErro: {message}\n{timestamp}"

Retry pattern:
  For OpenAI and Supabase calls:
  - Max 3 attempts
  - Backoff: 1s → 3s → 9s
  - After 3rd failure: trigger error handler

Acceptance criteria:
1. Set OPENAI_API_KEY to invalid value temporarily
2. Send WhatsApp message
   Expected:
   - User receives fallback message in < 10s
   - incident inserted with severity='high'
   - Operator receives WhatsApp alert in < 30s
3. Restore key → next message works normally
```

---

## SPRINT 4 — RAG

---

### P-10 — Pipeline de Ingestão

```
[HEADER PADRÃO]

Context: P-08 completed. Schema lote 3 applied.

Task:
Create the RAG ingestion pipeline as n8n workflow.

Required files:
1. n8n/workflows/RAG-Ingestion-Pipeline.json
2. scripts/ingest-doc.sh
3. scripts/check-chunks.sh

Webhook trigger: POST /webhook/ingest-document
Body: { tenant_id, title, source_type, file_url?, raw_text? }

Pipeline nodes:
1. Validate: tenant_id exists, source_type in [pdf, markdown, text, url]
2. INSERT knowledge_assets (status='processing')
3. Extract text:
   - pdf: download + extract via pdf-parse
   - markdown/text: use raw_text directly
   - url: fetch + strip HTML tags
4. Normalize: remove nulls, double spaces, excessive newlines
5. Chunk: target 600 tokens, overlap 100, split by paragraph > sentence > fixed
   - Each chunk includes: { tenant_id, asset_id, chunk_index, total_chunks, title, source_type }
6. Embed (batches of 20):
   - POST OpenAI /v1/embeddings, model: text-embedding-3-small
   - Retry on rate limit: 5s backoff
7. INSERT knowledge_chunks (chunk_text + embedding + metadata_json)
   - Use transaction: all or nothing
8. UPDATE knowledge_assets SET status='indexed', indexed_at=now()
9. INSERT ingestion_jobs (status='completed', chunks_created)
10. Return: { asset_id, chunks_created, status:'indexed' }

Error handler:
- On failure: UPDATE asset status='error', INSERT incident, alert operator
- Max 3 retries per stage

Required scripts:
ingest-doc.sh: curl wrapper to send doc to webhook
check-chunks.sh: query Supabase to count chunks and show samples

Acceptance criteria:
1. bash scripts/ingest-doc.sh "FAQ Ginkgo" text "$(cat docs/faq.md)"
   → asset status='indexed' in knowledge_assets
2. SELECT count(*), avg(length(chunk_text)) FROM knowledge_chunks WHERE tenant_id='f47ac10b...'
   → count > 5, avg between 200-900 chars
3. Embeddings not null: SELECT count(*) FROM knowledge_chunks WHERE embedding IS NULL → 0
```

---

### P-11 — Tool: search_knowledge

```
[HEADER PADRÃO]

Context: P-10 completed. FAQ indexed in pgvector.

Task:
Implement search_knowledge tool in Brann's flow.
Add to WA-Brann-Atendimento.json tool list and executor.

Tool spec for OpenAI function calling:
{
  "name": "search_knowledge",
  "description": "Search the company knowledge base before answering questions about products, services, policies, pricing, or procedures. Use whenever the question could be answered from internal documentation.",
  "parameters": {
    "type": "object",
    "properties": {
      "query": { "type": "string", "description": "The question or topic to search for" }
    },
    "required": ["query"]
  }
}

Tool executor nodes (add to WA-Brann-Atendimento.json):
1. Embed query: POST OpenAI /v1/embeddings, text-embedding-3-small
2. Vector search in Supabase:
   SELECT id, chunk_text, metadata_json,
     1 - (embedding <=> $query_embedding::vector) AS similarity
   FROM knowledge_chunks
   WHERE tenant_id = $tenant_id
   ORDER BY embedding <=> $query_embedding::vector
   LIMIT 5
3. Filter: keep only similarity >= 0.70
4. If none pass: return {found: false}
5. Format context string with source titles
6. INSERT retrieval_logs (query, top_chunks as jsonb, score_avg)
7. Return {context, sources, found: true} as tool result

System prompt addition (append to Brann v1):
"When using search_knowledge results: cite the source naturally ('conforme nossa documentação...'). If found=false: say you will verify and offer handoff."

Acceptance criteria:
1. Ask "Quais são os planos da Ginkgo?"
   → Brann calls search_knowledge
   → response uses content from indexed FAQ
   → retrieval_logs has 1 new row with score_avg > 0.70
2. Ask something NOT in the knowledge base
   → Brann says it will verify, does not invent
3. SELECT query_text, score_avg FROM retrieval_logs ORDER BY created_at DESC LIMIT 5 → shows results
```

---

### P-12 — Indexar Base Tenant Zero

```
[HEADER PADRÃO]

Context: P-11 completed. search_knowledge working.

Task:
Index the Ginkgo knowledge base for Tenant Zero.
Create and index 2 documents.

Document 1 — FAQ Ginkgo:
Create file: docs/knowledge/faq-ginkgo.md
Content: at least 12 Q&A pairs covering:
  - O que é a Ginkgo
  - Quais planos existem (Básico/Avançado/Futurista com detalhes)
  - Como funciona o onboarding
  - Quanto tempo para implementar
  - Precisa de equipe técnica
  - Funciona com WhatsApp Business
  - O que acontece quando o agente não sabe responder
  - Como é feito o treinamento com documentos
  - Segurança dos dados
  - Quantas mensagens por plano
  - O que é o handoff
  - Como falar com um especialista

Document 2 — Catálogo de serviços:
Create file: docs/knowledge/catalogo-ginkgo.md
Content:
  - Brann: funcionalidades, casos de uso, ideal para quem
  - Alfred: funcionalidades, casos de uso
  - Nyra: funcionalidades, casos de uso
  - Command: quando usar
  - Tabela comparativa dos 3 planos (o que cada um inclui)

After creating docs, ingest both:
  bash scripts/ingest-doc.sh "FAQ Ginkgo" text "$(cat docs/knowledge/faq-ginkgo.md)"
  bash scripts/ingest-doc.sh "Catálogo Ginkgo" text "$(cat docs/knowledge/catalogo-ginkgo.md)"

Create QA test script: scripts/rag-quality-test.sh
Test these 10 queries and verify relevant chunk in top-3:
  1. "Quais são os planos disponíveis?"
  2. "Quanto tempo leva para implementar?"
  3. "Preciso ter programador para usar?"
  4. "O que é o Brann?"
  5. "Os dados dos meus clientes ficam seguros?"
  6. "Como funciona o handoff para humano?"
  7. "Funciona com WhatsApp Business?"
  8. "O que é o Alfred?"
  9. "Qual a diferença entre Básico e Avançado?"
  10. "Como treinar o agente com minha documentação?"

Acceptance criteria:
1. bash scripts/rag-quality-test.sh → 9/10 or 10/10 passed
2. SELECT count(*) FROM knowledge_chunks WHERE tenant_id='f47ac10b...' → >= 20
3. Ask "Quanto custa o plano Avançado?" → Brann answers with correct price from catalog
```

---

## SPRINT 5 — Validação e Go-Live

---

### P-13 — Testes End-to-End

```
[HEADER PADRÃO]

Context: P-01 through P-12 completed.

Task:
Execute and document all 7 validation tests.

For each test: execute manually, record result (pass/fail), time, and observations.

T-01: Basic conversation flow
  Action: Send "Olá" to Tenant Zero WhatsApp
  Expected: reply in < 5s, messages table has user+agent pair, tool_executions logged

T-02: Lead qualification
  Action: Converse providing name + phone + interest in a plan
  Expected: contact in contacts, lead_score > 0, tags include 'lead', tool_executions has 'create_lead'

T-03: Knowledge base search
  Action: Ask "Quais são os planos da Ginkgo?"
  Expected: search_knowledge called, answer uses FAQ data, retrieval_logs updated

T-04: Human handoff
  Action: Send "Quero falar com uma pessoa"
  Expected: Chatwoot ticket created with summary, operator alert in < 30s, conversations.status='handoff'

T-05: Hot lead alert
  Action: Simulate name + phone + price question + urgency in same conversation
  Expected: score >= 70, tag 'hot_lead', operator alert, Brann suggests demo

T-06: Tenant isolation
  Action: Direct Supabase query with fake tenant_id for knowledge_chunks
  Expected: 0 rows returned, Tenant Zero data not accessible

T-07: Failure behavior
  Action: Temporarily invalidate OPENAI_API_KEY, send message
  Expected: fallback message to user < 10s, incident severity='high', operator alert < 30s

Output required:
Create file: docs/ops/validation-report-v1.md
Format:
  Date: [date]
  Tester: Gabriel Schaun
  
  T-01: ✅/❌ | Time: Xs | Notes: -
  ...
  
  Pass rate: X/7
  Open issues: [list]
  Corrective actions: [list]

Acceptance criteria:
ALL 7 tests pass (7/7)
Zero critical open issues before proceeding to P-14
```

---

### P-14 — Dashboard de Métricas

```
[HEADER PADRÃO]

Context: P-13 completed. All 7 tests passing.

Task:
Create the analytics views and daily summary automation.

1. Create SQL views in Supabase:

vw_daily_activity: messages per day (user vs agent) for last 30 days
vw_leads_captured: contacts with tag 'lead' per day for last 30 days
vw_handoff_rate: handoff % per tenant for last 30 days
vw_cost_per_conversation: estimated cost per day (tokens * 0.000015 USD)
vw_hot_leads: contacts with score >= 70 ordered by score desc

Use the exact SQL from ginkgo-schema-migrations.md section Lote 5 views.

2. Create n8n workflow "Daily Summary":
   Trigger: CRON 08:00 BRT (America/Sao_Paulo)
   Nodes:
   - Query each view for Tenant Zero
   - Format WhatsApp message:
     "📊 Resumo Ginkgo - {date}
      💬 Mensagens hoje: {count}
      👤 Leads novos: {count}
      🔥 Leads quentes: {count}
      🔁 Taxa handoff: {pct}%
      💰 Custo estimado: R${value}"
   - Send via Evolution API to $OPERATOR_NUMBER

Required file: n8n/workflows/Daily-Summary.json

3. Verify Metabase or Supabase Studio can display the views.

Acceptance criteria:
1. All 5 views created and return data (not empty)
2. Force-trigger daily summary → operator receives WhatsApp message in < 30s
3. Views accessible via Supabase Studio without errors
```

---

### P-15 — Go-Live Primeiro Cliente

```
[HEADER PADRÃO]

Context: P-14 completed. Dashboard live.

Task:
Create onboarding automation and go-live the first external client.

Required files:
1. scripts/provision-tenant.sh
2. docs/ops/go-live-checklist.md
3. docs/ops/onboarding-call-script.md
4. docs/ops/sop-update-prompt.md
5. docs/ops/sop-check-logs.md
6. docs/ops/sop-manual-handoff.md
7. docs/ops/sop-brann-not-responding.md

provision-tenant.sh parameters:
  $1 = tenant_name
  $2 = plan (basico|avancado|futurista)
  $3 = phone_number (WhatsApp number with country code)
  $4 = operator_phone (alerts destination)
  $5 = operator_name

Script actions:
  a. Generate UUID for new tenant
  b. INSERT tenants with provided data
  c. INSERT profiles (admin role)
  d. INSERT agents (brann, enabled, default config for plan)
  e. INSERT channels (whatsapp with provided number)
  f. INSERT token_balances (initial balance per plan)
  g. Copy base prompt brann-t0-v1.0 as brann-{slug}-v1.0, set active=true
  h. Create Evolution API instance for this tenant via API call
  i. Configure webhook for new instance to n8n
  j. Create Chatwoot inbox for this tenant
  k. Print summary:
     ✅ Tenant created: {uuid}
     ✅ Brann agent active
     ✅ WhatsApp channel configured: {number}
     ✅ Chatwoot inbox: {id}
     📋 Next: index knowledge base
     📋 Command: bash scripts/ingest-doc.sh {tenant_id} "FAQ" text "$(cat faq.md)"

go-live procedure:
  [ ] Run provision-tenant.sh for real client
  [ ] Index client knowledge base (FAQ minimum)
  [ ] Run go-live-checklist.md
  [ ] Monitor for 48h (check logs every 4h)
  [ ] After 48h: fill docs/ops/retrospective-client-01.md

Acceptance criteria:
1. bash scripts/provision-tenant.sh "Client Name" avancado "+5511999999999" "+5553991214817" "Gabriel" → exits 0 with all items ✅
2. Client WhatsApp receives Brann response in < 5s after connection
3. 48h in production with zero severity='high' incidents
4. At least 1 lead captured via Brann in first 48h
5. Daily summary arriving for client in operator's WhatsApp
```

---

## SPRINT 6 — Frontend Auth e Shell

---

### FE-01 — Setup Next.js + Auth + Layout

```
[HEADER PADRÃO]

Context: Backend P-01 to P-15 completed. API running.

Task:
Setup Next.js 14 App Router with Supabase Auth and base layout.

Required files:
apps/web/
  package.json
  next.config.js
  tailwind.config.js
  app/
    layout.tsx (root)
    (auth)/
      login/page.tsx
      register/page.tsx
    (dashboard)/
      layout.tsx (sidebar + topbar)
      page.tsx (overview placeholder)
  components/
    ui/sidebar.tsx
    ui/topbar.tsx
  lib/
    supabase.ts (client + server)
  middleware.ts (protect dashboard routes)

Design system:
  - Fonts: Geist (display) + JetBrains Mono (numbers/metrics)
  - Load via next/font or Google Fonts
  - CSS variables:
    --bg-base: #0A0A0F
    --bg-surface: #111118
    --bg-elevated: #18181F
    --border: #2A2A35
    --text-primary: #F0F0F5
    --text-muted: #6B6B80
    --accent: #6EE7B7
    --accent-warm: #FCD34D
    --accent-hot: #F87171
    --accent-blue: #60A5FA

Sidebar navigation items:
  Main: Overview, Conversas, Leads, Canais
  Intelligence: Conteúdo, Agentes, Knowledge
  Account: Billing, Settings

Auth flow:
  - Login with email+password via Supabase Auth
  - On success: redirect to /dashboard
  - Middleware: redirect unauthenticated users from /dashboard/* to /login
  - Supabase session via cookies (not localStorage)

Do not implement: actual data fetching, charts, real-time feeds.
This is layout and auth only.

Acceptance criteria:
1. npm run dev → no TypeScript errors
2. Navigate to /dashboard → redirect to /login (not authenticated)
3. Login with Tenant Zero credentials → reach /dashboard
4. Sidebar renders with all navigation items
5. Topbar shows logged-in user name/avatar
```

---

### FE-02 — Dashboard KPIs + Feed ao Vivo

```
[HEADER PADRÃO]

Context: FE-01 completed. Auth and layout working.

Task:
Build the dashboard overview page with real data from Supabase.

Components to create:
apps/web/components/
  dashboard/kpi-card.tsx
  dashboard/live-feed.tsx
  dashboard/activity-chart.tsx
  dashboard/alert-list.tsx

KPI Cards (6 total, data from Supabase views):
  1. Conversas hoje → COUNT messages WHERE DATE=today AND sender_type='user'
  2. Leads capturados → COUNT contacts WHERE 'lead' = ANY(tags) AND DATE=today
  3. Leads quentes → COUNT lead_scores WHERE score >= 70
  4. Handoffs → COUNT conversations WHERE status='handoff' AND DATE=today
  5. Tokens usados → token_balances.used_period
  6. Custo estimado → (tokens_used * 0.000015 * 5.8) formatted as R$

Live Feed:
  - Supabase Realtime subscription on messages table
  - Show last 10 messages across all conversations
  - Each item: avatar (initials), name, message preview, channel badge, score badge, time ago
  - Auto-scroll to newest

Activity chart:
  - Last 7 days bar chart using Recharts
  - 3 series: messages, leads, handoffs
  - Data from vw_daily_activity view

Alert list:
  - Hot leads without response > 1h
  - Open handoffs in Chatwoot
  - High severity incidents

All data fetched server-side where possible (RSC), realtime via client subscription only for feed.

Acceptance criteria:
1. Dashboard loads with real data (not mocked)
2. Send WhatsApp message → appears in live feed in < 5s (realtime working)
3. All 6 KPI cards show non-zero values after test conversations
4. Activity chart renders without errors
```

---

### FE-03 — Billing + Stripe

```
[HEADER PADRÃO]

Context: FE-02 completed.

Task:
Implement billing page and Stripe integration.

Pages:
apps/web/app/(dashboard)/billing/page.tsx

Backend routes (apps/api or Next.js API routes):
  POST /api/billing/checkout → create Stripe Checkout Session (subscription)
  POST /api/billing/portal → create Stripe Customer Portal Session
  POST /api/billing/tokens → create Stripe Payment Intent for token pack
  POST /api/webhooks/stripe → handle stripe events

Stripe events to handle:
  checkout.session.completed → update subscriptions table, set plan
  invoice.paid → update subscriptions, refill token_balances per plan
  customer.subscription.deleted → update status='canceled'
  payment_intent.succeeded → INSERT token_transactions (purchase)

Billing page sections:
  1. Current plan card (name, price, renewal date, status badge)
  2. Usage meters (messages, documents, tokens) with progress bars
  3. Token balance with buy button (3 packages: 500k/2M/10M)
  4. Invoice history table (period, amount, status, PDF link)
  5. Upgrade CTA if on basico plan

Design: match existing dark theme from dashboard preview.

Token packages:
  starter:  500k tokens  → R$ 79
  growth:   2M tokens    → R$ 249
  scale:    10M tokens   → R$ 890

Acceptance criteria:
1. Click "Fazer upgrade" → redirects to Stripe Checkout
2. Stripe webhook received → subscriptions.status updated in Supabase
3. Click "Comprar tokens" → Stripe Payment Intent created → on success, token_balances.balance incremented
4. Invoice table shows Stripe invoices for tenant
5. Token meter reflects current balance from token_balances table
```

---

## Índice de dependências

```
P-01 ─────────────────────────────────────────────┐
P-02 ─────────────────────────────────────────────┤
P-03 → depende P-01, P-02                         │
P-04 → depende P-03                               │
P-05 → depende P-04                               │
P-06 → depende P-04, P-05                         │
P-07 → depende P-05, P-06                         │
P-08 → depende P-04 (qualquer sprint 2)           │
P-10 → depende P-02 (schema lote 3)               │
P-11 → depende P-10, P-05                         │
P-12 → depende P-11                               │
P-13 → depende todos P-01..P-12                   │
P-14 → depende P-13                               │
P-15 → depende P-13, P-14                         │
FE-01 → depende P-02 (Supabase Auth)              │
FE-02 → depende FE-01, P-04 (dados reais)         │
FE-03 → depende FE-01, billing schema (lote 6)    ┘

Paralelismo possível:
  P-08 roda em paralelo com P-07
  P-10 começa logo após P-02 (não precisa de P-04..P-09)
  FE-01 pode começar após P-02
```

---

**Regra final:** Cole um prompt, espere o plano, revise, execute, valide, avance.

---

**Ginkgo AI Systems — Sprint Prompts v2.0**  
`execution-prompts v2.0.0 — Março 2026`
