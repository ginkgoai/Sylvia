-- =============================================================================
-- GINKGO AI SYSTEMS — DATABASE SCHEMA v1.0
-- Parte 2: RAG Core (Fase 3) + Entidades Canônicas (base de todos os módulos)
--
-- Depende de: ginkgo-schema-v1.sql (Fases 1+2)
-- Engine: Supabase Postgres 15+ com pgvector
-- =============================================================================


-- =============================================================================
-- ██████╗  █████╗  ██████╗
-- ██╔══██╗██╔══██╗██╔════╝
-- ██████╔╝███████║██║  ███╗
-- ██╔══██╗██╔══██║██║   ██║
-- ██║  ██║██║  ██║╚██████╔╝
-- ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝
-- RAG CORE — Memória Empresarial
-- =============================================================================


-- =============================================================================
-- R1. KNOWLEDGE SOURCES
-- Fontes de dados configuradas por tenant (Drive, pasta local, integração, etc.)
-- Uma source pode ter muitos assets.
-- =============================================================================

CREATE TABLE rag.knowledge_sources (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    description     TEXT,
    source_type     TEXT NOT NULL,             -- 'google_drive_folder' | 'upload' | 'integration' | 'url' | 'manual'
    integration_id  UUID REFERENCES integrations.accounts (id) ON DELETE SET NULL,
    config          JSONB NOT NULL DEFAULT '{}', -- ex: {folder_id: "...", recursive: true}
    sync_enabled    BOOLEAN NOT NULL DEFAULT true,
    sync_cron       TEXT,                      -- ex: '0 */6 * * *' (a cada 6h)
    last_synced_at  TIMESTAMPTZ,
    asset_count     INTEGER NOT NULL DEFAULT 0, -- denormalizado, atualizado por trigger
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ksources_tenant   ON rag.knowledge_sources (tenant_id);
CREATE INDEX idx_ksources_type     ON rag.knowledge_sources (source_type);
CREATE INDEX idx_ksources_active   ON rag.knowledge_sources (is_active);

SELECT ginkgo.create_updated_at_trigger('rag', 'knowledge_sources');

ALTER TABLE rag.knowledge_sources ENABLE ROW LEVEL SECURITY;

CREATE POLICY ksources_tenant ON rag.knowledge_sources
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- R2. KNOWLEDGE ASSETS
-- Um asset = um arquivo/documento/url indexado.
-- =============================================================================

CREATE TABLE rag.knowledge_assets (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    source_id       UUID REFERENCES rag.knowledge_sources (id) ON DELETE SET NULL,
    asset_type      rag.asset_type NOT NULL,
    title           TEXT NOT NULL,
    description     TEXT,
    -- Origem do arquivo
    storage_path    TEXT,                      -- path no Supabase Storage: tenant_id/docs/uuid.pdf
    external_url    TEXT,                      -- se veio de URL ou integração
    external_id     TEXT,                      -- ID do arquivo na fonte externa (ex: Drive file_id)
    mime_type       TEXT,
    file_size_bytes BIGINT,
    -- Pipeline
    status          rag.asset_status NOT NULL DEFAULT 'uploaded',
    error_message   TEXT,
    chunk_count     INTEGER NOT NULL DEFAULT 0,  -- denormalizado
    -- Extração
    extracted_text  TEXT,                      -- texto bruto extraído (OCR/STT/parse)
    extracted_at    TIMESTAMPTZ,
    -- Metadados para retrieval
    language        TEXT NOT NULL DEFAULT 'pt',
    tags            TEXT[] NOT NULL DEFAULT '{}',
    access_roles    ginkgo.member_role[] NOT NULL DEFAULT '{owner,admin,operator,viewer}',
    metadata        JSONB NOT NULL DEFAULT '{}',
    -- Hash para deduplicação
    content_hash    TEXT,                      -- SHA-256 do conteúdo bruto
    -- Temporalidade
    valid_from      TIMESTAMPTZ,
    valid_until     TIMESTAMPTZ,               -- NULL = sem expiração
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_kassets_tenant      ON rag.knowledge_assets (tenant_id);
CREATE INDEX idx_kassets_source      ON rag.knowledge_assets (source_id);
CREATE INDEX idx_kassets_status      ON rag.knowledge_assets (status);
CREATE INDEX idx_kassets_type        ON rag.knowledge_assets (asset_type);
CREATE INDEX idx_kassets_hash        ON rag.knowledge_assets (content_hash);
CREATE INDEX idx_kassets_tags        ON rag.knowledge_assets USING GIN (tags);
-- Full-text search no título
CREATE INDEX idx_kassets_title_fts   ON rag.knowledge_assets USING GIN (to_tsvector('portuguese', title));

SELECT ginkgo.create_updated_at_trigger('rag', 'knowledge_assets');

ALTER TABLE rag.knowledge_assets ENABLE ROW LEVEL SECURITY;

CREATE POLICY kassets_tenant ON rag.knowledge_assets
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- R3. KNOWLEDGE CHUNKS
-- Fragmentos de texto gerados pelo chunking pipeline.
-- Cada chunk tem seu embedding associado em knowledge_embeddings.
-- =============================================================================

CREATE TABLE rag.knowledge_chunks (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    asset_id        UUID NOT NULL REFERENCES rag.knowledge_assets (id) ON DELETE CASCADE,
    chunk_index     INTEGER NOT NULL,          -- posição do chunk no documento (0-based)
    content         TEXT NOT NULL,             -- texto do chunk
    content_length  INTEGER NOT NULL GENERATED ALWAYS AS (length(content)) STORED,
    -- Metadados de posição para citations
    page_number     INTEGER,
    section_title   TEXT,
    start_char      INTEGER,
    end_char        INTEGER,
    -- Metadados herdados do asset para filtros eficientes no retrieval
    asset_type      rag.asset_type NOT NULL,
    language        TEXT NOT NULL DEFAULT 'pt',
    tags            TEXT[] NOT NULL DEFAULT '{}',
    access_roles    ginkgo.member_role[] NOT NULL DEFAULT '{owner,admin,operator,viewer}',
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_chunks_tenant    ON rag.knowledge_chunks (tenant_id);
CREATE INDEX idx_chunks_asset     ON rag.knowledge_chunks (asset_id);
CREATE INDEX idx_chunks_tags      ON rag.knowledge_chunks USING GIN (tags);
-- Full-text search híbrido (complementa retrieval vetorial)
CREATE INDEX idx_chunks_fts       ON rag.knowledge_chunks
    USING GIN (to_tsvector('portuguese', content));

ALTER TABLE rag.knowledge_chunks ENABLE ROW LEVEL SECURITY;

CREATE POLICY chunks_tenant ON rag.knowledge_chunks
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );

-- Trigger: decrementa chunk_count em knowledge_assets ao deletar chunk
CREATE OR REPLACE FUNCTION rag.sync_chunk_count()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE rag.knowledge_assets SET chunk_count = chunk_count + 1 WHERE id = NEW.asset_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE rag.knowledge_assets SET chunk_count = chunk_count - 1 WHERE id = OLD.asset_id;
    END IF;
    RETURN NULL;
END;
$$;

CREATE TRIGGER trg_sync_chunk_count
    AFTER INSERT OR DELETE ON rag.knowledge_chunks
    FOR EACH ROW EXECUTE FUNCTION rag.sync_chunk_count();


-- =============================================================================
-- R4. KNOWLEDGE EMBEDDINGS
-- Um embedding por chunk. Separado de chunks para:
--   1. Poder re-embedar sem recriar chunks
--   2. Suportar múltiplos modelos de embedding por chunk (futuro)
--   3. Manter a tabela de chunks limpa para FTS
-- =============================================================================

CREATE TABLE rag.knowledge_embeddings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    chunk_id        UUID NOT NULL REFERENCES rag.knowledge_chunks (id) ON DELETE CASCADE,
    -- Vector: 1536 dims para text-embedding-3-small (OpenAI)
    -- Ajustar para 3072 se usar text-embedding-3-large
    -- Ajustar para 768 se usar modelos locais (Ollama)
    embedding       VECTOR(1536) NOT NULL,
    model           TEXT NOT NULL DEFAULT 'text-embedding-3-small',
    model_version   TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (chunk_id, model)
);

-- HNSW index: melhor performance de retrieval para pgvector
-- ef_construction=128 e m=16 são bons defaults para começar
CREATE INDEX idx_embeddings_hnsw ON rag.knowledge_embeddings
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 128);

CREATE INDEX idx_embeddings_chunk  ON rag.knowledge_embeddings (chunk_id);
CREATE INDEX idx_embeddings_tenant ON rag.knowledge_embeddings (tenant_id);

-- RLS: leitura apenas para membros do tenant (retrieval via service_role nos agents)
ALTER TABLE rag.knowledge_embeddings ENABLE ROW LEVEL SECURITY;

CREATE POLICY embeddings_tenant ON rag.knowledge_embeddings
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- R5. KNOWLEDGE SUMMARIES
-- Resumos gerados automaticamente pelo summaries worker.
-- Usados como contexto macro antes do retrieval granular.
-- =============================================================================

CREATE TABLE rag.knowledge_summaries (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    scope           TEXT NOT NULL,             -- 'asset' | 'source' | 'tenant' | 'topic'
    scope_id        UUID,                      -- asset_id | source_id | NULL (para tenant)
    title           TEXT NOT NULL,
    summary         TEXT NOT NULL,
    key_entities    TEXT[] NOT NULL DEFAULT '{}', -- entidades extraídas (nomes, produtos, etc.)
    topics          TEXT[] NOT NULL DEFAULT '{}',
    model           TEXT NOT NULL DEFAULT 'gpt-4o-mini',
    token_count     INTEGER,
    generated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    valid_until     TIMESTAMPTZ,               -- NULL = revalidar no próximo cycle
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, scope, scope_id)
);

CREATE INDEX idx_summaries_tenant ON rag.knowledge_summaries (tenant_id);
CREATE INDEX idx_summaries_scope  ON rag.knowledge_summaries (scope, scope_id);

SELECT ginkgo.create_updated_at_trigger('rag', 'knowledge_summaries');

ALTER TABLE rag.knowledge_summaries ENABLE ROW LEVEL SECURITY;

CREATE POLICY summaries_tenant ON rag.knowledge_summaries
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- R6. RETRIEVAL LOGS
-- Log de todas as buscas RAG feitas pelos agentes.
-- Alimenta feedback loops, análise de cobertura e observabilidade.
-- Particionado por mês para não explodir.
-- =============================================================================

CREATE TABLE rag.retrieval_logs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    agent_instance  UUID REFERENCES agents.instances (id) ON DELETE SET NULL,
    query           TEXT NOT NULL,
    query_embedding VECTOR(1536),              -- embedding da query (para análise de clusters)
    strategy        TEXT NOT NULL DEFAULT 'hybrid', -- 'vector' | 'fts' | 'hybrid'
    results_count   INTEGER NOT NULL DEFAULT 0,
    latency_ms      INTEGER,
    -- Top chunks retornados (snapshot para análise sem precisar re-buscar)
    top_chunk_ids   UUID[],
    top_scores      NUMERIC[],
    -- Feedback (preenchido pelo agente após usar o resultado)
    was_useful      BOOLEAN,
    feedback_note   TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
)
PARTITION BY RANGE (created_at);

CREATE TABLE rag.retrieval_logs_2025_q1
    PARTITION OF rag.retrieval_logs
    FOR VALUES FROM ('2025-01-01') TO ('2025-04-01');

CREATE TABLE rag.retrieval_logs_2025_q2
    PARTITION OF rag.retrieval_logs
    FOR VALUES FROM ('2025-04-01') TO ('2025-07-01');

CREATE TABLE rag.retrieval_logs_2025_q3
    PARTITION OF rag.retrieval_logs
    FOR VALUES FROM ('2025-07-01') TO ('2025-10-01');

CREATE TABLE rag.retrieval_logs_2025_q4
    PARTITION OF rag.retrieval_logs
    FOR VALUES FROM ('2025-10-01') TO ('2026-01-01');

CREATE TABLE rag.retrieval_logs_2026
    PARTITION OF rag.retrieval_logs
    FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');

CREATE INDEX idx_rlogs_tenant ON rag.retrieval_logs (tenant_id, created_at DESC);
CREATE INDEX idx_rlogs_agent  ON rag.retrieval_logs (agent_instance, created_at DESC);

-- Sem RLS — acesso via service_role; leitura admin via view abaixo
ALTER TABLE rag.retrieval_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY retrieval_logs_admin ON rag.retrieval_logs
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m.role IN ('owner', 'admin')
        )
    );


-- =============================================================================
-- R7. INGESTION JOBS
-- Jobs do pipeline de ingestão criados pelo ingestion worker.
-- Um job por asset, rastreando cada etapa do pipeline.
-- =============================================================================

CREATE TABLE rag.ingestion_jobs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    asset_id        UUID NOT NULL REFERENCES rag.knowledge_assets (id) ON DELETE CASCADE,
    -- Etapas do pipeline
    step            TEXT NOT NULL,             -- 'extract' | 'chunk' | 'embed' | 'summarize'
    status          TEXT NOT NULL DEFAULT 'queued',
    attempts        INTEGER NOT NULL DEFAULT 0,
    max_attempts    INTEGER NOT NULL DEFAULT 3,
    -- Métricas da etapa
    input_size      INTEGER,                   -- bytes ou chars de entrada
    output_size     INTEGER,                   -- bytes ou chars de saída
    duration_ms     INTEGER,
    tokens_used     INTEGER,
    error_message   TEXT,
    error_detail    JSONB,
    started_at      TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ingest_tenant ON rag.ingestion_jobs (tenant_id);
CREATE INDEX idx_ingest_asset  ON rag.ingestion_jobs (asset_id);
CREATE INDEX idx_ingest_status ON rag.ingestion_jobs (status, created_at ASC);

SELECT ginkgo.create_updated_at_trigger('rag', 'ingestion_jobs');


-- =============================================================================
-- R8. RAG FUNCTION — Retrieval Híbrido
-- Chamada pelos agentes via Supabase RPC.
-- Combina vector search (cosine) + full-text search + filtros de tenant/role.
-- =============================================================================

CREATE OR REPLACE FUNCTION rag.search(
    p_tenant_id     UUID,
    p_query_embed   VECTOR(1536),
    p_query_text    TEXT,
    p_limit         INTEGER DEFAULT 8,
    p_asset_types   rag.asset_type[] DEFAULT NULL,   -- filtro de tipo (NULL = todos)
    p_tags          TEXT[] DEFAULT NULL,              -- filtro de tags (NULL = todos)
    p_min_score     NUMERIC DEFAULT 0.65
)
RETURNS TABLE (
    chunk_id        UUID,
    asset_id        UUID,
    asset_title     TEXT,
    content         TEXT,
    page_number     INTEGER,
    section_title   TEXT,
    vector_score    NUMERIC,
    fts_score       NUMERIC,
    combined_score  NUMERIC,
    tags            TEXT[],
    metadata        JSONB
)
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    RETURN QUERY
    WITH vector_results AS (
        SELECT
            c.id                                    AS chunk_id,
            c.asset_id,
            c.content,
            c.page_number,
            c.section_title,
            c.tags,
            c.metadata,
            (1 - (e.embedding <=> p_query_embed))   AS vscore
        FROM rag.knowledge_embeddings e
        JOIN rag.knowledge_chunks c ON c.id = e.chunk_id
        JOIN rag.knowledge_assets a ON a.id = c.asset_id
        WHERE
            e.tenant_id = p_tenant_id
            AND a.status = 'indexed'
            AND (p_asset_types IS NULL OR a.asset_type = ANY(p_asset_types))
            AND (p_tags IS NULL OR c.tags && p_tags)
        ORDER BY e.embedding <=> p_query_embed
        LIMIT p_limit * 3   -- busca 3x mais para re-rankar depois
    ),
    fts_results AS (
        SELECT
            c.id                                    AS chunk_id,
            ts_rank(
                to_tsvector('portuguese', c.content),
                plainto_tsquery('portuguese', p_query_text)
            )                                       AS fscore
        FROM rag.knowledge_chunks c
        WHERE
            c.tenant_id = p_tenant_id
            AND to_tsvector('portuguese', c.content) @@
                plainto_tsquery('portuguese', p_query_text)
        LIMIT p_limit * 3
    ),
    combined AS (
        SELECT
            v.chunk_id,
            v.asset_id,
            v.content,
            v.page_number,
            v.section_title,
            v.tags,
            v.metadata,
            v.vscore                                AS vector_score,
            COALESCE(f.fscore, 0)                   AS fts_score,
            -- Peso: 70% vetor + 30% FTS
            (v.vscore * 0.7 + COALESCE(f.fscore, 0) * 0.3) AS combined_score
        FROM vector_results v
        LEFT JOIN fts_results f ON f.chunk_id = v.chunk_id
        WHERE v.vscore >= p_min_score
    )
    SELECT
        c.chunk_id,
        c.asset_id,
        a.title                                     AS asset_title,
        c.content,
        c.page_number,
        c.section_title,
        c.vector_score::NUMERIC,
        c.fts_score::NUMERIC,
        c.combined_score::NUMERIC,
        c.tags,
        c.metadata
    FROM combined c
    JOIN rag.knowledge_assets a ON a.id = c.asset_id
    ORDER BY c.combined_score DESC
    LIMIT p_limit;
END;
$$;


-- =============================================================================
-- R9. VIEW — Cobertura do RAG por tenant (alimenta o dashboard)
-- =============================================================================

CREATE VIEW rag.knowledge_coverage AS
SELECT
    a.tenant_id,
    a.asset_type,
    COUNT(*)                            AS asset_count,
    SUM(a.chunk_count)                  AS total_chunks,
    SUM(a.file_size_bytes)              AS total_bytes,
    COUNT(*) FILTER (WHERE a.status = 'indexed')    AS indexed_count,
    COUNT(*) FILTER (WHERE a.status = 'failed')     AS failed_count,
    COUNT(*) FILTER (WHERE a.status = 'stale')      AS stale_count,
    MAX(a.updated_at)                   AS last_update
FROM rag.knowledge_assets a
GROUP BY a.tenant_id, a.asset_type;


-- =============================================================================
-- ███████╗███╗   ██╗████████╗██╗██████╗  █████╗ ██████╗ ███████╗███████╗
-- ██╔════╝████╗  ██║╚══██╔══╝██║██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔════╝
-- █████╗  ██╔██╗ ██║   ██║   ██║██║  ██║███████║██║  ██║█████╗  ███████╗
-- ██╔══╝  ██║╚██╗██║   ██║   ██║██║  ██║██╔══██║██║  ██║██╔══╝  ╚════██║
-- ███████╗██║ ╚████║   ██║   ██║██████╔╝██║  ██║██████╔╝███████╗███████║
-- ╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝
-- ENTIDADES CANÔNICAS
-- Schema: ginkgo (namespace compartilhado, tenant_id em tudo)
-- Estas tabelas são o modelo interno unificado. Cada integração alimenta
-- essas entidades via integration_mappings. Os agentes nunca leem APIs
-- externas cru — leem SEMPRE a entidade canônica.
-- =============================================================================


-- =============================================================================
-- C1. CUSTOMERS
-- Pessoas ou empresas que já são clientes (tiveram pedido ou contrato).
-- =============================================================================

CREATE TABLE ginkgo.customers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    -- Identificação
    external_ids    JSONB NOT NULL DEFAULT '{}',  -- {"shopify": "123", "stripe": "cus_xxx"}
    name            TEXT NOT NULL,
    email           TEXT,
    phone           TEXT,
    document        TEXT,                      -- CPF/CNPJ
    document_type   TEXT,                      -- 'cpf' | 'cnpj'
    -- Endereço
    address         JSONB,                     -- {street, number, city, state, zip, country}
    -- Segmentação
    tags            TEXT[] NOT NULL DEFAULT '{}',
    segment         TEXT,                      -- 'vip' | 'regular' | 'churned' | custom
    lifetime_value  NUMERIC(14,2),             -- denormalizado, atualizado por worker
    order_count     INTEGER NOT NULL DEFAULT 0,
    -- Preferências / CRM
    preferred_channel TEXT,                    -- 'whatsapp' | 'email' | 'instagram'
    language        TEXT NOT NULL DEFAULT 'pt',
    notes           TEXT,
    custom_fields   JSONB NOT NULL DEFAULT '{}',
    -- Source
    source          TEXT,                      -- 'shopify' | 'manual' | 'lead_converted' | etc.
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_customers_tenant  ON ginkgo.customers (tenant_id);
CREATE INDEX idx_customers_email   ON ginkgo.customers (tenant_id, email);
CREATE INDEX idx_customers_phone   ON ginkgo.customers (tenant_id, phone);
CREATE INDEX idx_customers_tags    ON ginkgo.customers USING GIN (tags);
CREATE INDEX idx_customers_extids  ON ginkgo.customers USING GIN (external_ids);
-- FTS no nome para busca rápida pelo agente
CREATE INDEX idx_customers_name_fts ON ginkgo.customers
    USING GIN (to_tsvector('portuguese', name));

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'customers');

ALTER TABLE ginkgo.customers ENABLE ROW LEVEL SECURITY;

CREATE POLICY customers_tenant ON ginkgo.customers
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C2. LEADS
-- Contatos em pipeline de venda. Podem virar customers ao converter.
-- =============================================================================

CREATE TYPE ginkgo.lead_status AS ENUM (
    'new',
    'contacted',
    'qualified',
    'proposal',
    'negotiation',
    'won',          -- convertido para customer
    'lost',
    'disqualified'
);

CREATE TABLE ginkgo.leads (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    customer_id     UUID REFERENCES ginkgo.customers (id) ON DELETE SET NULL, -- preenchido ao converter
    external_ids    JSONB NOT NULL DEFAULT '{}',
    name            TEXT NOT NULL,
    email           TEXT,
    phone           TEXT,
    company         TEXT,
    status          ginkgo.lead_status NOT NULL DEFAULT 'new',
    score           INTEGER,                   -- lead score 0-100
    source          TEXT,                      -- 'instagram_dm' | 'whatsapp' | 'form' | 'referral'
    utm_source      TEXT,
    utm_medium      TEXT,
    utm_campaign    TEXT,
    assigned_to     UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    -- Pipeline
    stage_entered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    converted_at    TIMESTAMPTZ,
    lost_at         TIMESTAMPTZ,
    lost_reason     TEXT,
    -- IA
    ai_summary      TEXT,                      -- resumo gerado pelo Brann
    ai_pain_points  TEXT[],                    -- pontos de dor identificados
    ai_interests    TEXT[],
    notes           TEXT,
    custom_fields   JSONB NOT NULL DEFAULT '{}',
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_leads_tenant   ON ginkgo.leads (tenant_id);
CREATE INDEX idx_leads_status   ON ginkgo.leads (tenant_id, status);
CREATE INDEX idx_leads_assigned ON ginkgo.leads (assigned_to);
CREATE INDEX idx_leads_source   ON ginkgo.leads (source);
CREATE INDEX idx_leads_extids   ON ginkgo.leads USING GIN (external_ids);
CREATE INDEX idx_leads_name_fts ON ginkgo.leads
    USING GIN (to_tsvector('portuguese', name));

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'leads');

ALTER TABLE ginkgo.leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY leads_tenant ON ginkgo.leads
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C3. PRODUCTS
-- Catálogo interno de produtos/serviços do tenant.
-- Alimentado por Shopify, Mercado Livre, ou cadastro manual.
-- =============================================================================

CREATE TABLE ginkgo.products (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    external_ids    JSONB NOT NULL DEFAULT '{}',   -- {"shopify": "prod_123", "ml": "MLB..."}
    sku             TEXT,
    name            TEXT NOT NULL,
    description     TEXT,
    category        TEXT,
    tags            TEXT[] NOT NULL DEFAULT '{}',
    -- Preço
    price           NUMERIC(14,2),
    compare_at_price NUMERIC(14,2),
    currency        TEXT NOT NULL DEFAULT 'BRL',
    -- Estoque
    stock_quantity  INTEGER,
    track_inventory BOOLEAN NOT NULL DEFAULT true,
    -- Imagens
    image_urls      TEXT[] NOT NULL DEFAULT '{}',
    -- Status
    is_active       BOOLEAN NOT NULL DEFAULT true,
    is_digital      BOOLEAN NOT NULL DEFAULT false,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_products_tenant  ON ginkgo.products (tenant_id);
CREATE INDEX idx_products_sku     ON ginkgo.products (tenant_id, sku);
CREATE INDEX idx_products_active  ON ginkgo.products (tenant_id, is_active);
CREATE INDEX idx_products_tags    ON ginkgo.products USING GIN (tags);
CREATE INDEX idx_products_extids  ON ginkgo.products USING GIN (external_ids);
CREATE INDEX idx_products_fts     ON ginkgo.products
    USING GIN (to_tsvector('portuguese', name || ' ' || COALESCE(description, '')));

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'products');

ALTER TABLE ginkgo.products ENABLE ROW LEVEL SECURITY;

CREATE POLICY products_tenant ON ginkgo.products
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C4. ORDERS
-- Pedidos normalizados de qualquer plataforma de e-commerce.
-- =============================================================================

CREATE TYPE ginkgo.order_status AS ENUM (
    'pending',
    'confirmed',
    'processing',
    'shipped',
    'delivered',
    'cancelled',
    'refunded',
    'disputed'
);

CREATE TABLE ginkgo.orders (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    customer_id     UUID REFERENCES ginkgo.customers (id) ON DELETE SET NULL,
    external_ids    JSONB NOT NULL DEFAULT '{}',
    order_number    TEXT,
    source          TEXT,                      -- 'shopify' | 'ml' | 'shopee' | 'manual'
    status          ginkgo.order_status NOT NULL DEFAULT 'pending',
    -- Valores
    subtotal        NUMERIC(14,2) NOT NULL DEFAULT 0,
    discount_total  NUMERIC(14,2) NOT NULL DEFAULT 0,
    shipping_total  NUMERIC(14,2) NOT NULL DEFAULT 0,
    tax_total       NUMERIC(14,2) NOT NULL DEFAULT 0,
    total           NUMERIC(14,2) NOT NULL DEFAULT 0,
    currency        TEXT NOT NULL DEFAULT 'BRL',
    -- Envio
    shipping_address JSONB,
    tracking_code   TEXT,
    shipping_carrier TEXT,
    shipped_at      TIMESTAMPTZ,
    delivered_at    TIMESTAMPTZ,
    -- Notas
    customer_note   TEXT,
    internal_note   TEXT,
    -- Linha do tempo
    confirmed_at    TIMESTAMPTZ,
    cancelled_at    TIMESTAMPTZ,
    refunded_at     TIMESTAMPTZ,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_orders_tenant    ON ginkgo.orders (tenant_id);
CREATE INDEX idx_orders_customer  ON ginkgo.orders (customer_id);
CREATE INDEX idx_orders_status    ON ginkgo.orders (tenant_id, status);
CREATE INDEX idx_orders_source    ON ginkgo.orders (source);
CREATE INDEX idx_orders_extids    ON ginkgo.orders USING GIN (external_ids);
CREATE INDEX idx_orders_created   ON ginkgo.orders (tenant_id, created_at DESC);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'orders');

ALTER TABLE ginkgo.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY orders_tenant ON ginkgo.orders
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C5. ORDER ITEMS (linha de pedido)
-- =============================================================================

CREATE TABLE ginkgo.order_items (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    order_id        UUID NOT NULL REFERENCES ginkgo.orders (id) ON DELETE CASCADE,
    product_id      UUID REFERENCES ginkgo.products (id) ON DELETE SET NULL,
    external_product_id TEXT,                 -- ID externo se produto não foi mapeado
    name            TEXT NOT NULL,
    sku             TEXT,
    quantity        INTEGER NOT NULL DEFAULT 1,
    unit_price      NUMERIC(14,2) NOT NULL,
    discount        NUMERIC(14,2) NOT NULL DEFAULT 0,
    total           NUMERIC(14,2) NOT NULL,
    metadata        JSONB NOT NULL DEFAULT '{}'
);

CREATE INDEX idx_order_items_order   ON ginkgo.order_items (order_id);
CREATE INDEX idx_order_items_product ON ginkgo.order_items (product_id);
CREATE INDEX idx_order_items_tenant  ON ginkgo.order_items (tenant_id);

ALTER TABLE ginkgo.order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY order_items_tenant ON ginkgo.order_items
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C6. TASKS
-- Tarefas unificadas de ClickUp, Trello, Notion ou criadas pelos agentes.
-- =============================================================================

CREATE TYPE ginkgo.task_status AS ENUM (
    'backlog',
    'todo',
    'in_progress',
    'in_review',
    'done',
    'cancelled'
);

CREATE TYPE ginkgo.task_priority AS ENUM (
    'urgent',
    'high',
    'medium',
    'low'
);

CREATE TABLE ginkgo.tasks (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    external_ids    JSONB NOT NULL DEFAULT '{}',
    title           TEXT NOT NULL,
    description     TEXT,
    source          TEXT,                      -- 'clickup' | 'trello' | 'notion' | 'agent' | 'manual'
    status          ginkgo.task_status NOT NULL DEFAULT 'todo',
    priority        ginkgo.task_priority NOT NULL DEFAULT 'medium',
    assigned_to     UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    -- Relacionamentos
    customer_id     UUID REFERENCES ginkgo.customers (id) ON DELETE SET NULL,
    order_id        UUID REFERENCES ginkgo.orders (id) ON DELETE SET NULL,
    lead_id         UUID REFERENCES ginkgo.leads (id) ON DELETE SET NULL,
    parent_task_id  UUID REFERENCES ginkgo.tasks (id) ON DELETE SET NULL,
    -- Temporalidade
    due_date        TIMESTAMPTZ,
    started_at      TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    -- Tags
    tags            TEXT[] NOT NULL DEFAULT '{}',
    labels          TEXT[] NOT NULL DEFAULT '{}',
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_tasks_tenant    ON ginkgo.tasks (tenant_id);
CREATE INDEX idx_tasks_status    ON ginkgo.tasks (tenant_id, status);
CREATE INDEX idx_tasks_assigned  ON ginkgo.tasks (assigned_to);
CREATE INDEX idx_tasks_due       ON ginkgo.tasks (tenant_id, due_date);
CREATE INDEX idx_tasks_customer  ON ginkgo.tasks (customer_id);
CREATE INDEX idx_tasks_tags      ON ginkgo.tasks USING GIN (tags);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'tasks');

ALTER TABLE ginkgo.tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY tasks_tenant ON ginkgo.tasks
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C7. PAYMENTS
-- Pagamentos normalizados de Stripe, Asaas, Mercado Pago.
-- =============================================================================

CREATE TYPE ginkgo.payment_status AS ENUM (
    'pending',
    'processing',
    'paid',
    'failed',
    'refunded',
    'disputed',
    'cancelled'
);

CREATE TABLE ginkgo.payments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    order_id        UUID REFERENCES ginkgo.orders (id) ON DELETE SET NULL,
    customer_id     UUID REFERENCES ginkgo.customers (id) ON DELETE SET NULL,
    external_ids    JSONB NOT NULL DEFAULT '{}',
    source          TEXT,                      -- 'stripe' | 'asaas' | 'mercado_pago' | 'manual'
    status          ginkgo.payment_status NOT NULL DEFAULT 'pending',
    amount          NUMERIC(14,2) NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'BRL',
    payment_method  TEXT,                      -- 'credit_card' | 'pix' | 'boleto'
    description     TEXT,
    paid_at         TIMESTAMPTZ,
    refunded_at     TIMESTAMPTZ,
    refund_amount   NUMERIC(14,2),
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_payments_tenant   ON ginkgo.payments (tenant_id);
CREATE INDEX idx_payments_order    ON ginkgo.payments (order_id);
CREATE INDEX idx_payments_customer ON ginkgo.payments (customer_id);
CREATE INDEX idx_payments_status   ON ginkgo.payments (tenant_id, status);
CREATE INDEX idx_payments_created  ON ginkgo.payments (tenant_id, created_at DESC);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'payments');

ALTER TABLE ginkgo.payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY payments_tenant ON ginkgo.payments
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C8. REVIEWS
-- Avaliações de clientes de qualquer canal.
-- =============================================================================

CREATE TABLE ginkgo.reviews (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    customer_id     UUID REFERENCES ginkgo.customers (id) ON DELETE SET NULL,
    order_id        UUID REFERENCES ginkgo.orders (id) ON DELETE SET NULL,
    product_id      UUID REFERENCES ginkgo.products (id) ON DELETE SET NULL,
    external_ids    JSONB NOT NULL DEFAULT '{}',
    source          TEXT,                      -- 'google_business' | 'shopify' | 'ml' | 'manual'
    rating          SMALLINT CHECK (rating BETWEEN 1 AND 5),
    title           TEXT,
    content         TEXT,
    -- Análise de sentimento (gerada por worker)
    sentiment       TEXT,                      -- 'positive' | 'neutral' | 'negative'
    sentiment_score NUMERIC(4,3),              -- -1.0 a 1.0
    keywords        TEXT[],
    -- Resposta
    reply_content   TEXT,
    replied_at      TIMESTAMPTZ,
    -- Flags
    is_public       BOOLEAN NOT NULL DEFAULT true,
    is_verified     BOOLEAN NOT NULL DEFAULT false,
    reviewed_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_reviews_tenant   ON ginkgo.reviews (tenant_id);
CREATE INDEX idx_reviews_product  ON ginkgo.reviews (product_id);
CREATE INDEX idx_reviews_rating   ON ginkgo.reviews (tenant_id, rating);
CREATE INDEX idx_reviews_sentiment ON ginkgo.reviews (tenant_id, sentiment);
CREATE INDEX idx_reviews_fts      ON ginkgo.reviews
    USING GIN (to_tsvector('portuguese', COALESCE(content, '') || ' ' || COALESCE(title, '')));

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'reviews');

ALTER TABLE ginkgo.reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY reviews_tenant ON ginkgo.reviews
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C9. CALENDAR EVENTS
-- Eventos unificados de Google Calendar, Notion, ClickUp Calendar, etc.
-- =============================================================================

CREATE TABLE ginkgo.calendar_events (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    external_ids    JSONB NOT NULL DEFAULT '{}',
    source          TEXT,                      -- 'google_calendar' | 'notion' | 'agent' | 'manual'
    title           TEXT NOT NULL,
    description     TEXT,
    location        TEXT,
    -- Tempo
    starts_at       TIMESTAMPTZ NOT NULL,
    ends_at         TIMESTAMPTZ NOT NULL,
    all_day         BOOLEAN NOT NULL DEFAULT false,
    timezone        TEXT NOT NULL DEFAULT 'America/Sao_Paulo',
    is_recurring    BOOLEAN NOT NULL DEFAULT false,
    recurrence_rule TEXT,                      -- RRULE string
    -- Participantes
    organizer_id    UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    attendees       JSONB NOT NULL DEFAULT '[]', -- [{name, email, status}]
    -- Relacionamentos
    customer_id     UUID REFERENCES ginkgo.customers (id) ON DELETE SET NULL,
    lead_id         UUID REFERENCES ginkgo.leads (id) ON DELETE SET NULL,
    tags            TEXT[] NOT NULL DEFAULT '{}',
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_events_tenant    ON ginkgo.calendar_events (tenant_id);
CREATE INDEX idx_events_starts    ON ginkgo.calendar_events (tenant_id, starts_at);
CREATE INDEX idx_events_organizer ON ginkgo.calendar_events (organizer_id);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'calendar_events');

ALTER TABLE ginkgo.calendar_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY events_tenant ON ginkgo.calendar_events
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C10. INTEGRATION MAPPINGS
-- Mapeia registros externos para entidades canônicas.
-- Usado pelo sync worker para não criar duplicatas.
-- Ex: Shopify order #1234 → ginkgo.orders:uuid
-- =============================================================================

CREATE TABLE integrations.entity_mappings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    account_id      UUID NOT NULL REFERENCES integrations.accounts (id) ON DELETE CASCADE,
    provider        integrations.provider NOT NULL,
    -- Entidade canônica
    canonical_table TEXT NOT NULL,             -- 'customers' | 'orders' | 'products' | etc.
    canonical_id    UUID NOT NULL,
    -- Entidade externa
    external_id     TEXT NOT NULL,
    external_type   TEXT,                      -- tipo na plataforma externa
    -- Controle de sync
    last_synced_at  TIMESTAMPTZ,
    sync_hash       TEXT,                      -- hash do estado externo para detectar mudanças
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, provider, canonical_table, external_id)
);

CREATE INDEX idx_emaps_tenant    ON integrations.entity_mappings (tenant_id);
CREATE INDEX idx_emaps_canonical ON integrations.entity_mappings (canonical_table, canonical_id);
CREATE INDEX idx_emaps_external  ON integrations.entity_mappings (provider, external_id);

ALTER TABLE integrations.entity_mappings ENABLE ROW LEVEL SECURITY;

CREATE POLICY emaps_tenant ON integrations.entity_mappings
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C11. VIEWS ANALÍTICAS — Entidades Canônicas
-- =============================================================================

-- Resumo de clientes por tenant
CREATE VIEW ginkgo.customer_summary AS
SELECT
    c.tenant_id,
    COUNT(*)                                        AS total_customers,
    COUNT(*) FILTER (WHERE c.segment = 'vip')       AS vip_count,
    AVG(c.lifetime_value)                           AS avg_ltv,
    SUM(c.lifetime_value)                           AS total_ltv,
    MAX(c.created_at)                               AS last_customer_at
FROM ginkgo.customers c
GROUP BY c.tenant_id;

-- Funil de leads por tenant
CREATE VIEW ginkgo.lead_funnel AS
SELECT
    l.tenant_id,
    l.status,
    COUNT(*)                AS count,
    AVG(l.score)            AS avg_score,
    MIN(l.stage_entered_at) AS oldest_in_stage,
    MAX(l.stage_entered_at) AS newest_in_stage
FROM ginkgo.leads l
GROUP BY l.tenant_id, l.status;

-- Receita por tenant (30 / 90 / 365 dias)
CREATE VIEW ginkgo.revenue_summary AS
SELECT
    p.tenant_id,
    SUM(p.amount) FILTER (WHERE p.paid_at >= now() - INTERVAL '30 days')  AS revenue_30d,
    SUM(p.amount) FILTER (WHERE p.paid_at >= now() - INTERVAL '90 days')  AS revenue_90d,
    SUM(p.amount) FILTER (WHERE p.paid_at >= now() - INTERVAL '365 days') AS revenue_365d,
    COUNT(*) FILTER (WHERE p.status = 'paid' AND p.paid_at >= now() - INTERVAL '30 days') AS orders_30d
FROM ginkgo.payments p
WHERE p.status = 'paid'
GROUP BY p.tenant_id;

-- NPS aproximado por tenant
CREATE VIEW ginkgo.review_summary AS
SELECT
    r.tenant_id,
    ROUND(AVG(r.rating)::NUMERIC, 2)            AS avg_rating,
    COUNT(*)                                     AS total_reviews,
    COUNT(*) FILTER (WHERE r.rating >= 4)        AS positive_count,
    COUNT(*) FILTER (WHERE r.rating = 3)         AS neutral_count,
    COUNT(*) FILTER (WHERE r.rating <= 2)        AS negative_count,
    MAX(r.reviewed_at)                           AS last_review_at
FROM ginkgo.reviews r
GROUP BY r.tenant_id;


-- =============================================================================
-- FIM — ginkgo-schema-rag-entities-v1.sql
-- Próximos schemas:
--   ginkgo-schema-leaf-v1.sql    — channels, contacts, conversations,
--                                  messages, handoffs (Fase 4)
--   ginkgo-schema-command-v1.sql — sessions, tool_calls, policies (Fase 5)
-- =============================================================================
