# GINKGO WORKSPACE — PRD Completo
## Plataforma de Trabalho Inteligente para o Profissional Digital
### Do trabalhador solo à empresa — um sistema operacional de delegação para IA

> **Versão:** 1.0.0 | **Data:** Março 2026  
> **Status:** Visão de produto — aprovada para execução faseada  
> **Posicionamento:** "Você aprova. A IA executa."

---

## 1. A Visão em Uma Frase

A Ginkgo é o único workspace onde você **não opera as ferramentas** — você tem uma equipe de agentes de IA que opera por você, e você só vê os resultados, aprova ações e ajusta o rumo.

---

## 2. O Problema Real

O profissional digital hoje usa em média 6–9 ferramentas:

```
Instagram + TikTok    → para distribuir conteúdo
ClickUp / Notion      → para organizar tarefas
WhatsApp              → para atender clientes
Google Analytics/GMB  → para ver dados
HubSpot/Pipedrive     → para gerir leads
ChatGPT               → para escrever
Canva                 → para criar
```

São 6–9 logins. 6–9 planos. 6–9 interfaces. E **o humano ainda faz todo o trabalho operacional**.

A Ginkgo resolve isso com uma premissa simples:

```
ANTES: Humano opera as ferramentas
DEPOIS: Agentes operam as ferramentas. Humano aprova e ajusta.
```

---

## 3. Posicionamento e Público-Alvo

### Para quem é

```
SOLO / MICRO (ticket: R$150–350/mês)
  Freelancer digital, consultor, infoprodutor
  Precisa de: secretária IA + social media IA
  Dor principal: faz tudo sozinho, não tem tempo

PEQUENA EMPRESA (ticket: R$350–700/mês)
  Agência pequena, clínica, imobiliária, e-commerce local
  Precisa de: atendimento + conteúdo + relatórios + CRM
  Dor principal: time pequeno, muitas frentes

EMPRESA EM CRESCIMENTO (ticket: R$700–1.500/mês)
  Empresa com time de 5–50 pessoas
  Precisa de: workspace unificado + automações + dados
  Dor principal: ferramentas fragmentadas, dado disperso
```

### O que diferencia da concorrência

| Concorrente | O que faz | O que não faz |
|-------------|-----------|---------------|
| ClickUp / Notion | Organiza tarefas | Não executa, não atende, não cria |
| Hootsuite / Buffer | Agenda posts | Não cria, não analisa, não atende |
| HubSpot | CRM e leads | Caro, complexo, não tem agentes |
| ChatGPT / Claude | Gera conteúdo | Não integra, não publica, não atende |
| Zapier / n8n | Automatiza | Não tem agentes, exige configuração técnica |

**A Ginkgo é a única que fecha o ciclo completo:**
```
Dado bruto → Refinamento → Ação do agente → Aprovação → Resultado
```

---

## 4. Os 4 Agentes — Equipe Digital Completa

```
┌─────────────────────────────────────────────────────────────────┐
│                    SUA EQUIPE GINKGO                            │
│                                                                 │
│  👩‍💼 SECRETÁRIA        📱 SOCIAL MEDIA      📊 GESTOR          │
│  (Brann)             (Nyra)               (Alfred)             │
│  Atende 24h          Cria e posta         Analisa e reporta    │
│  Qualifica leads     Recicla conteúdo     Otimiza campanhas    │
│  Agenda              Gerencia calendário  Controla orçamento   │
│  Faz handoff         Relatório de perf.   Tarefas e projetos   │
│                                                                 │
│  ⚡ ASSISTENTE PESSOAL (Command)                                │
│  Telegram / Web — controla tudo          │
│  "pausa campanha", "cria post", "me manda relatório"            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 5. A Interface — Fusão de 4 Referências

### Navegação principal (5 áreas)

```
┌─────────────────────────────────────────────────────────────┐
│  🏢 Office  │  💬 Inbox  │  📋 Board  │  🎨 Studio  │  📊 Data │
└─────────────────────────────────────────────────────────────┘
```

### Office (Home — inspirado no OpenClaw 3D)
```
Visualização isométrica dos agentes trabalhando
  Secretária na mesa → atendendo leads no WhatsApp
  Social Media criando → pipeline de reel em andamento
  Gestor analisando → relatório rodando
  Assistente standby → aguardando comando

Estado dos agentes em tempo real:
  Trabalhando / Idle / Cansado (tokens baixos) / Offline
  Token health bar por agente
  Alertas flutuantes (lead quente, handoff, publicação aprovada)
```

### Inbox (inspirado no Chatwoot)
```
Conversas unificadas:
  WhatsApp (Brann)
  Instagram DM
  Telegram
  Email
  Google My Business

Por canal, com status de agente:
  🤖 Atendendo por IA   👤 Handoff para humano   ⏸ Pausado
```

### Board (inspirado no ClickUp/Notion)
```
Gestão de tarefas e projetos:
  Tasks criadas pelos agentes
  Tasks aprovadas pelo gestor
  Calendário editorial da Nyra
  Sincronização com ClickUp / Notion
  Relatórios automáticos do Alfred
```

### Studio (inspirado no Lovart)
```
Criação de conteúdo visual:
  Briefings para Nyra
  Visualização de Reels em produção
  Aprovação de posts antes de publicar
  Calendário de publicações multi-canal
  Métricas de performance por peça
```

### Data (Dashboard de inteligência)
```
Dados de todas as integrações em tempo real:
  Redes sociais (alcance, engajamento, top posts)
  Tráfego pago (ROAS, CPC, spend por campanha)
  Negócio local (GMB: visualizações, avaliações, cliques)
  Atendimento (conversas, leads, score, handoff rate)
  Financeiro (receita, custo por conversa, tokens)
  News Feed Perplexity (notícias do setor)
```

---

## 6. Integrações — Fontes de Dados e Canais de Ação

### Canais de comunicação (onde os agentes atuam)
```
WhatsApp        Evolution API      Brann atende e qualifica
Instagram DM    Meta Graph API     Brann + Nyra
Telegram        Bot API            Command + alertas
Email           Resend             Disparos + notificações
Website Chat    OpenClaw widget    Brann atende
```

### Redes sociais (onde a Nyra publica e analisa)
```
Instagram   Meta OAuth    Reels, posts, stories, carrossel
TikTok      TikTok OAuth  Vídeos, métricas, trending
YouTube     Google OAuth  Shorts, métricas, transcrição
Facebook    Meta OAuth    Posts, página, grupos
LinkedIn    LinkedIn OAuth Posts, artigos, métricas
Threads     Meta OAuth    Posts, engajamento
X           X OAuth       Posts, menções
```

### Ferramentas de trabalho (onde o Alfred opera)
```
ClickUp     OAuth    Tasks, projetos, sprints, relatórios
Notion      OAuth    Bases, wikis, documentos
Google Drive  OAuth  Documentos para RAG e compartilhamento
Gmail       OAuth    Emails → RAG, respostas automáticas
Calendar    OAuth    Agendamentos do Brann
```

### Negócio e dados
```
Google My Business   Avaliações, localização, métricas locais
Google Analytics 4   Tráfego do site, conversões, origem
Shopify              Pedidos, produtos, clientes, receita
Shopee               Pedidos, produtos
Google Ads           Campanhas, CPC, ROAS, qualidade
Meta Ads             Campanhas, alcance, leads, ROAS
TikTok Ads           Campanhas, plays, CPM
```

### Criação de conteúdo (ferramentas da Nyra)
```
ElevenLabs    Voz IA para narração de reels
HeyGen        Avatar IA em vídeo
Gamma AI      Apresentações automáticas
Blotato       Social cards + publicação multi-canal
Postiz        Agendamento open source (auto-hospedado)
FFmpeg        Processamento de vídeo (servidor)
Whisper       Transcrição de áudio
MoviePy       Crop, legendas, composição
```

---

## 7. Tokenização — Modelo de Margem Embutida

### Princípio
O usuário compra "tokens Ginkgo". Por dentro, cada token representa crédito de API com markup de margem.

```
CUSTO REAL DE API     TOKENS COBRADOS     MARGEM EMBUTIDA
─────────────────────────────────────────────────────────
OpenAI gpt-4o
  ~R$0,075/1k tokens  R$0,20/1k tokens    ~62%

Embeddings (RAG)
  ~R$0,001/1k tokens  R$0,005/1k tokens   ~80%

ElevenLabs (voz)
  ~R$0,18/1k chars    R$0,45/1k chars     ~60%

HeyGen (avatar vídeo)
  ~R$2,50/minuto      R$6,00/minuto       ~58%

Gamma AI (slides)
  ~R$0,30/documento   R$0,75/documento    ~60%

Whisper (transcrição)
  ~R$0,006/min        R$0,015/min         ~60%

Perplexity (news)
  ~R$0,001/query      R$0,003/query       ~67%

Apify (scraping)
  ~R$0,30/100 results R$0,75/100 results  ~60%
```

### Regra de pricing de tokens
```
Custo real da API × 2,5 = tokens cobrados ao cliente
Margem bruta média: 60–65%
```

### Como aparece para o usuário
```
"Criar Reel completo (script + voz + avatar): 150 tokens"
"Reciclar vídeo em 5 shorts: 80 tokens"
"Prospectar 15 leads qualificados: 120 tokens"
"Relatório semanal de tráfego: 30 tokens"
"Escanear leads Instagram: 50 tokens"
```

O usuário entende o custo em tokens. Não vê a API por trás.

---

## 8. Modelo de Assinatura

```
PLATAFORMA BASE (workspace + dashboard + news feed)
  Starter   R$97/mês   → 3 integrações · 50k tokens · 1 agente liberado
  Business  R$197/mês  → ilimitadas · 200k tokens · 3 agentes
  Scale     R$397/mês  → multi-workspace · 500k tokens · todos os agentes

ADD-ONS DE AGENTES (mensalidade por agente ativo)
  Secretária (Brann)        +R$147/mês   WhatsApp 24h · leads · handoff
  Social Media (Nyra)       +R$197/mês   Reels · posts · calendário
  Gestor/Analista (Alfred)  +R$147/mês   Relatórios · ClickUp · SQL
  Assistente (Command)      +R$197/mês   Telegram · controle total

PACOTES DE TOKENS
  Starter  50k tokens   R$79
  Growth   200k tokens  R$249
  Scale    1M tokens    R$890

ADD-ONS DE SKILLS (por skill/mês)
  Prospecção Ativa        R$97/mês   scraping + enriquecimento
  Reciclagem de Conteúdo  R$79/mês   corte · crop · legenda · distribuição
  Email Marketing         R$49/mês   templates · disparos · métricas
  Controle Financeiro     R$49/mês   dashboard financeiro · alertas · relatório
  Disparo em Massa WA     R$79/mês   Evolution API em lote
  Relatório Executivo     R$29/mês   PDF/WhatsApp semanal automático
```

### Ticket médio por perfil
```
Solo/Freelancer:   R$97 + R$147 (Brann) = R$244/mês
Pequena Empresa:   R$197 + R$147 + R$197 + skills = ~R$650/mês
Empresa Crescendo: R$397 + todos os agentes + skills = ~R$1.200/mês
```

---

## 9. Análise das 3 Skills Enviadas

### Skill 1 — Prospecção Ativa (Lead Scraping)

**Origem:** Prompt Exato para Raspagem de Leads com Manus + Apify + Meta Ads

**Avaliação: ✅ Alta viabilidade — skill de monetização imediata**

O que está bem desenhado:
- Multi-canal (Google, LinkedIn, Facebook, Crunchbase, GitHub) para cruzamento de evidências
- Qualificação por score (1–10) baseada em número de canais onde aparece
- Saída estruturada em planilha com campos práticos
- Versão 3 (combinada) é a mais assertiva — evidência em 2+ canais como critério mínimo

O que adaptar para a Ginkgo:
```
COMO SKILL GINKGO:

manifest:
  id: prospeccao-ativa
  agents: [brann, alfred]
  requires: [apify_api_key, meta_app_id]
  billing_impact: high
  price_brl: 97/mês + tokens por execução

Fluxo dentro da plataforma:
  Alfred recebe briefing (segmento, localização, keywords)
  → Dispara Apify (Google, LinkedIn)
  → Cruza com Meta Ads API
  → Enriquece com Hunter.io (emails)
  → Salva em contacts com tags=[prospecto, canal_X]
  → Gera lead_score baseado em evidências
  → Brann inicia abordagem automática via WhatsApp

Tokenização:
  15 leads com 3 canais cruzados = ~120 tokens Ginkgo
  Custo real: ~R$1,50 em APIs
  Cobrado: ~R$2,40 em tokens (markup 60%)
  + mensalidade da skill R$97/mês

Limitação a documentar:
  LinkedIn tem rate limit severo — Apify ajuda mas tem custo
  Meta Ads API não expõe dados de cliques de terceiros
  LGPD: deixar claro no onboarding que dados são públicos
```

---

### Skill 2 — Controle Financeiro (Finance Dashboard)

**Origem:** Guia Completo: Controle de Renda e Investimentos (regra 25-15-50-10)

**Avaliação: ⚠️ Média viabilidade — bom como skill de contexto, não de execução direta**

O que está bem:
- Framework 25-15-50-10 é universalmente aplicável para PMEs
- Estrutura de contas separadas por categoria é implementável como dashboard
- Automação de transferências e alocação é um fluxo n8n simples

O que adaptar para a Ginkgo:
```
COMO SKILL GINKGO:

Não é uma skill de "scraping" ou "criação" — é uma skill de
inteligência financeira. O Alfred monitora e reporta.

manifest:
  id: controle-financeiro
  agents: [alfred]
  requires: [stripe, shopify ou entrada manual]
  billing_impact: low
  price_brl: 49/mês

O que o Alfred faz:
  Recebe receita total do período (via Stripe/Shopify/manual)
  → Calcula alocação 25-15-50-10 automaticamente
  → Compara com gastos reais (categorias declaradas)
  → Gera relatório de desvio
  → Alerta no WhatsApp/Telegram se alguma categoria estourou
  → Relatório mensal em PDF

Casos de uso reais para PME:
  "Este mês você gastou R$3.200 em ferramentas (32% da receita).
   Sua meta é 50% em operacionais. Reduzir ou ajustar?"

  "Você tem R$12.000 em caixa. Baseado no seu histórico,
   3 meses de emergência = R$18.000. Você está em 67% da meta."

Tokenização:
  Relatório mensal automático = 30 tokens
  Custo real: ~R$0,15 em API
  Cobrado: ~R$0,30

Nota: este conteúdo (guia Mark Tilbury) é material de
conteúdo educativo, não arquitetura de skill. A skill real
precisa de integração com fonte de dados financeiros.
```

---

### Skill 3 — Reciclagem de Conteúdo (Content Recycler)

**Origem:** Arquitetura: Skill de Reciclagem de Conteúdo — 5 pipelines completos

**Avaliação: ✅✅ Alta viabilidade — a skill mais completa e mais valiosa das três**

O que está excelente:
- 5 pipelines separados e bem definidos (inventário, análise, edição, copy, distribuição)
- Stack técnica correta: yt-dlp + Auto-Editor + FFmpeg + MoviePy + Whisper + Postiz
- Fluxo Mermaid claro e implementável
- Pseudocódigo Python executável como ponto de partida

O que adaptar para a Ginkgo:
```
COMO SKILL GINKGO:

Esta é uma skill da Nyra — o agente de conteúdo.

manifest:
  id: nyra-content-recycler
  agents: [nyra]
  requires: [youtube_api, instagram_api, tiktok_api, openai_key]
  billing_impact: high
  price_brl: 79/mês + tokens por execução

Adaptações necessárias:
  1. Postiz → substituir por Blotato (já na stack Ginkgo)
     ou manter Postiz auto-hospedado como opção mais barata

  2. Processamento de vídeo → rodar no VPS (não no Supabase)
     FFmpeg + MoviePy precisam de CPU/memória dedicada
     Recomendado: worker dedicado no VPS Hostinger

  3. Manus Data API → substituir por APIs diretas
     (YouTube Data API + yt-dlp para download)

  4. Auto-Editor → incluir no docker-compose do VPS
     pip install auto-editor no container de workers

  5. Adicionar HeyGen como opção premium:
     Reciclar conteúdo COM avatar IA = produto mais premium
     Custo maior mas diferenciação alta

Fluxo completo na Ginkgo:
  Usuário: "Recicle meu último vídeo do YouTube em 5 shorts"
  ↓
  Nyra (via Command ou dashboard Studio):
    → yt-dlp: baixa o vídeo
    → Whisper: transcreve
    → GPT-4o: identifica 5 highlights (timestamps)
    → FFmpeg: corta os 5 clipes
    → Auto-Editor: remove silêncios de cada clipe
    → MoviePy: crop 9:16 + legendas dinâmicas
    → GPT-4o: gera caption + hashtags para cada clipe
    → Blotato ou Postiz: agenda publicação escalonada
  ↓
  Dashboard Studio: aprovação antes de publicar (ou auto-publish)

Tokenização por execução:
  Reciclar 1 vídeo (até 60min) em 5 shorts = 150 tokens
  Custo real:
    Whisper: ~R$0,30
    GPT-4o: ~R$0,25
    Infraestrutura VPS: ~R$0,10
    Total real: ~R$0,65
  Cobrado: ~R$1,65 (150 tokens × R$0,011/token)
  Margem: ~60%

Skills complementares sugeridas:
  nyra-content-recycler  → recicla conteúdo existente
  nyra-reels-pipeline    → cria conteúdo novo do zero
  nyra-editorial         → calendário + distribuição programada
```

---

## 10. Skills Adicionais — Roadmap Completo

### P2 — Lançamento com expansão

```
nyra-content-recycler    R$79/mês   yt-dlp + FFmpeg + MoviePy + Whisper
nyra-reels-pipeline      Incluso/Nyra  ElevenLabs + HeyGen + Blotato
prospeccao-ativa         R$97/mês   Apify + Meta Ads + Hunter.io
email-marketing          R$49/mês   Resend + templates + métricas
relatorio-executivo      R$29/mês   Alfred + PDF + WhatsApp weekly
controle-financeiro      R$49/mês   Alfred + dash financeiro + alertas
```

### P3 — Marketplace

```
disparo-massa-whatsapp   R$79/mês   Evolution API em lote + compliance
noticiario-nichado       R$29/mês   Perplexity + segmento + curadoria
preenchimento-leads      R$49/mês   Brann captura → Alfred enriquece
lembrete-inteligente     R$29/mês   Command + calendar + WhatsApp
gestao-google-ads        R$79/mês   Alfred + Google Ads API + otimização
prospecao-instagram      R$79/mês   Apify Instagram + DM automatizado
triagem-curriculos       R$79/mês   Brann entrevista → Alfred avalia
```

### P4 — Skills de parceiros (revshare 70/30)

```
Qualquer desenvolvedor pode criar skills seguindo o SDK.
Monetização: assinatura ou por execução.
Ginkgo fica com 30% de toda receita da skill.
```

---

## 11. News Feed Inteligente (Perplexity)

Funcionalidade base em todos os planos. É o diferencial de intelligence que nenhuma ferramenta de social media tem.

```
A cada 4h, por tenant:

Perplexity sonar-pro recebe query personalizada:
  "Notícias relevantes para [segmento] nos últimos 2 dias.
   Foco em Brasil. JSON: [{title, summary, type, relevance, source_url}]"

Tipos de card:
  📰 Notícia do setor
  📈 Tendência de conteúdo (viral no TikTok/IG)
  ⚠️ Alerta de algoritmo (mudança no Meta/TikTok)
  💡 Oportunidade de pauta
  🏷️ Menção à sua marca

Ação rápida em cada card:
  [Criar post sobre isso] → dispara Nyra
  [Salvar] → vai para board
  [Descartar]

Isso cria um loop natural de uso diário:
  Usuário abre plataforma → vê news feed → ativa Nyra para criar
```

---

## 12. Office Visual — Fase 4

```
Base técnica: Supabase Realtime lendo tool_executions

Visualização:
  Cada agente é um personagem no escritório
  Mesa do agente pisca quando está executando uma tool
  Balão de fala mostra o que está fazendo
  Barra de token mostra saúde de energia
  Sala de reunião ativa durante stand-up diário (Daily Summary)

Estados visuais:
  🟢 Trabalhando   → animação de digitação na mesa
  🟡 Cansado       → token < 20%, personagem inclinado
  🔴 Offline       → token = 0, luzes apagadas na mesa
  💬 Em conversa   → balão de fala com preview da mensagem
  📊 Analisando    → telas acesas no monitor do Alfred
  🎬 Criando       → câmera/estúdio aceso na mesa da Nyra
  ✈️ Enviando       → personagem "caminhando" para o canal

Marketing value:
  Screenshot do escritório ocupado = proof of value visual
  "Minha equipe Ginkgo hoje" → viral no LinkedIn/Instagram
```

---

## 13. Onboarding — Do cadastro ao primeiro valor em 10 minutos

```
PASSO 1 — Cadastro (2 min)
  Nome, email, segmento do negócio
  Trial 7 dias · sem cartão

PASSO 2 — Conectar um canal (3 min)
  Instagram OU WhatsApp OU Google Meu Negócio
  Dados reais aparecem no dashboard instantaneamente
  "Uau, já tem informação do meu negócio aqui"

PASSO 3 — Primeira ação do agente (5 min)
  Brann: "Escreva uma mensagem de boas-vindas para um lead"
  → Brann responde em segundos
  "Meu assistente acabou de responder"

PASSO 4 — News Feed configurado
  Perplexity já rodando com o segmento declarado
  Primeiras notícias relevantes aparecem

→ Usuário entendeu o valor sem precisar ler manual
```

---

## 14. Fases de Execução do Produto

```
FASE 1 — MVP Leaf (já em construção)
  Brann + WhatsApp + RAG + dashboard básico + billing
  Meta: 5 clientes · MRR R$2.000

FASE 2 — Workspace Completo
  Nyra + conteúdo + integrações OAuth (Meta, Google, TikTok)
  Alfred + relatórios + ClickUp
  Dashboard Data completo + News Feed Perplexity
  Studio de conteúdo (aprovação)
  Meta: 20 clientes · MRR R$10.000

FASE 3 — Skills + Command
  Command via Telegram
  Skills: Prospecção, Reciclagem, Email, Financeiro
  Office visual (Supabase Realtime)
  Meta: 50 clientes · MRR R$25.000

FASE 4 — Marketplace + Office 3D
  SDK de skills para terceiros
  Office visual isométrico completo
  White-label para agências
  Meta: 200 clientes · MRR R$100.000
```

---

## 15. Localização no Repositório

```
docs/prd/
  GINKGO-WORKSPACE-PRD.md     ← este documento

packages/
  skills/
    prospeccao-ativa/
      manifest.json
      tools/scrape_leads.ts
      workflows/lead-scraping.json
    content-recycler/
      manifest.json
      tools/recycle_video.ts
      workers/video-processor.py    ← FFmpeg + MoviePy no VPS
      workflows/content-recycle.json
    controle-financeiro/
      manifest.json
      tools/financial_report.ts
    email-marketing/
    relatorio-executivo/
```

---

*Ginkgo AI Systems — GINKGO-WORKSPACE-PRD.md v1.0.0 — Março 2026*  
*"Você aprova. A IA executa."*
