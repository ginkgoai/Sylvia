# MARKET-REPORT.md
## Relatório de Mercado — Ginkgo AI Systems
### Panorama, dores, concorrência, gaps e blueprint ideal

> **Versão:** 1.0.0 | **Data:** Março 2026  
> **Base:** Análise estratégica Manus AI + pesquisa de mercado  
> **Uso:** Alimentar decisões de produto e posicionamento comercial

---

## 1. Panorama — Onde a Ginkgo está entrando

A Ginkgo está no cruzamento de **quatro mercados convergindo**:

```
1. Work OS / Workspace         → organização do trabalho com IA embutida
2. Customer Platform           → CRM + marketing + atendimento unificado
3. Omnichannel / Inbox         → conversas, leads e vendas via WhatsApp/Instagram
4. Agentic Automation          → IA que decide e executa, não só sugere
```

**Por que o Brasil é o mercado certo agora:**
- ~185 milhões de usuários de internet (penetração ~86,9% — fim de 2025)
- ~150 milhões de identidades em redes sociais (out/2025)
- ~148 milhões de usuários do WhatsApp — WhatsApp é infraestrutura cultural e comercial
- Adoção digital acelerada em PMEs que ainda operam com ferramentas fragmentadas

**A maré do mercado:**
- "Agentes com memória e contexto" estão virando padrão (Zendesk CX Trends 2026)
- Foco deixou de ser "funciona?" e passou para "é bom de verdade?" (Intercom 2026)
- Cobrança por valor entregue (outcome/credits) substituindo seat-based pricing

---

## 2. Dores Reais — Os Jobs-to-be-done que pagam a conta

### Fragmentação e perda de contexto
PMEs operam com muitos logins, muitos painéis e muita "colagem manual" entre dados. A categoria de CDP existe porque dados do cliente ficam espalhados e as empresas querem um "cliente 360". Sem dados unificados não existe personalização nem automação confiável — a IA vira brinquedo.

### Atendimento: expectativa de resolução instantânea, com contexto
"Contextual intelligence" é o elo que faltava para resolver bem, rápido e sem reiniciar conversa. Consumidores esperam histórico, personalização e resolução na primeira interação. Responder rápido não basta — precisa responder certo, com contexto e regras.

### Custo e imprevisibilidade de operação (incluindo tokens de IA)
Empresas monitorando custo de tokens e governança porque o gasto cresce com uso real. Para o cliente, a Ginkgo existe para reduzir tempo e aumentar ROI. Para a plataforma, metering + billing + limites precisam nascer no dia zero — senão o negócio quebra.

### Marketing e conteúdo: demanda por escala e repurpose
Repurposing e reutilização inteligente de conteúdo já virou prática dominante. Alta parcela de profissionais replica conteúdo com pequenas adaptações entre plataformas. A área de "conteúdo + reciclagem" não é nice-to-have — é dor recorrente e recorrentemente cara.

### Omnichannel e WhatsApp como canal principal
Empresas querem "um inbox só" e histórico único do contato porque o cliente troca de canal. O padrão de mercado já exige: omnichannel, perfil do contato, roteamento, colaboração, automação e agente que resolve.

### LGPD e governança de IA
A Ginkgo vai inevitavelmente tocar dados pessoais. LGPD define tratamento de dados e direitos dos titulares. "Autonomia sem governança" vira risco jurídico e operacional. Compliance precisa ser feature, não afterthought.

---

## 3. Mapa da Concorrência

### Work OS com IA embutida

| Player | Posicionamento | O que fazem bem | O que não fazem |
|--------|---------------|-----------------|-----------------|
| ClickUp | "ClickUp Brain" — IA em todo lugar | UI madura, projetos, docs | Não opera o mundo externo por você |
| Notion | Workspace com IA e automações | Docs, colaboração, busca | Não atende, não publica, não analisa ads |
| monday.com | AI work platform | Automações, integrações | Não tem agentes que executam |
| Airtable | Apps + interfaces + automations + AI | Flexibilidade de dados | Complexo demais para SMB |

**Lição:** dominam UI e colaboração, mas falham quando o objetivo é operar o mundo externo automaticamente.

### Customer Platform com agentes

| Player | Posicionamento | Modelo de cobrança | Diferencial |
|--------|---------------|-------------------|-------------|
| HubSpot | Breeze AI Agents | Credits por ação executada | Enorme base de CRM + marketing |
| Salesforce | Agentforce | Por outcome/conversa | Data Cloud como espinha dorsal |
| Zendesk | AI Agents autônomos | Por resolução autônoma | Helpdesk maduro |
| Intercom Fin | AI agent por resolução | $0,99 por resolução | Modelo outcome puro |

**Lição crítica:** os gigantes estão indo para "agentes + dados unificados + governança + cobrança por valor". A Ginkgo precisa nascer com o mesmo DNA, com produto mais simples e time-to-value menor para SMB.

### WhatsApp-first e vendas conversacionais (Brasil)

| Player | Foco | Limitação para PME |
|--------|------|--------------------|
| respond.io | Inbox omnichannel + CRM | Caro, complexo, sem agentes cognitivos |
| Kommo | WhatsApp CRM + bots | Não tem conteúdo nem gestão integrada |
| RD Station | CRM + marketing + WhatsApp | Não tem agentes de execução |
| Zenvia / Blip | Canal WhatsApp enterprise | Foco em enterprise, não SMB |

**Lição:** no Brasil, ganhar o "Inbox + Lead profile + automação + qualidade" em WhatsApp/Instagram vale ouro — mas poucas soluções conectam isso com conteúdo + gestão + dados em um lugar só.

### Conteúdo e publicação social

| Player | O que fazem | O que não fazem |
|--------|-------------|-----------------|
| Hootsuite | Criação + agendamento + analytics + inbox | Não tem agente que cria de verdade |
| Buffer | Criar + organizar + repurpose com IA | Sem integração com negócio (leads, vendas) |
| Sprout Social | Smart Inbox + analytics | Caro, não tem execução autônoma |

**Lição:** "Studio de conteúdo" precisa competir com UX dessas ferramentas, mas a vantagem da Ginkgo é trazer agente + aprovação + execução + dados do negócio juntos.

---

## 4. Posicionamento Único da Ginkgo

**A tese competitiva correta:**

> Nenhuma ferramenta hoje une: estado unificado do cliente + runtime de agentes com tools + inbound real (WhatsApp/Instagram) + aprovação e governança + UI viva (Office). A Ginkgo é a primeira a fechar esse ciclo para PMEs brasileiras.

```
CONCORRENTES ATUAIS      GINKGO
────────────────────     ─────────────────────────────────
Sistema de registro  →   Sistema de execução
"Organize seus dados"→   "Seus agentes operam por você"
Seat-based pricing   →   Tokens + outcome + skills
Setup manual         →   Onboarding em 10 minutos
6–9 ferramentas      →   1 workspace
Humano opera as APIs →   Agente opera as APIs, humano aprova
```

**O moat real (não é a feature list):**

O moat é a **integração entre camadas**: o Brann que atendeu o lead alimenta o Alfred que gerou o relatório que o Command enviou por Telegram e a Nyra usou para criar o post. Nenhuma ferramenta existente faz esse ciclo fechado automaticamente.

---

## 5. O que seria ideal — Blueprint de produto

### Data Hub (espinha dorsal)

Para unificar dados de outros serviços do cliente, a Ginkgo está criando, na prática, uma **mini-CDP operacional**. O que isso requer:

```
Objetos canônicos:
  Contact/Lead · Company · Conversation · Message
  Deal/Pipeline · ContentItem · Campaign · Order · Ticket · Task

Identity resolution mínima:
  merge por telefone + email + IDs externos (Meta, Google, Shopify)

Timeline única por contato:
  mensagens + compras + campanhas + tarefas + anotações

RAG com permissões:
  busca vetorial isolada por tenant (RLS + ACL)
```

**Sem Data Hub canônico, o resto vira painéis bonitos em cima de dados quebrados.**

### Módulos de interface (5 áreas)

```
Office    → estado vivo dos agentes (tokens, tasks, alertas)
Inbox     → atendimento omnichannel + leads + handoff
Board     → gestão de tarefas + calendário + projetos
Studio    → conteúdo + aprovação + publicação + análise
Data      → dashboard de inteligência + news feed
```

### Loop de qualidade para agentes (o gap mais importante)

Os líderes de mercado já tratam performance de agente como operação contínua com ferramentas para analisar e testar. **Isso ainda está faltando no blueprint atual da Ginkgo.** O que precisa existir:

```
Análise de prompts:
  versões · performance · drift · comparação A/B

Análise de tool calls:
  taxa de uso · taxa de erro · latência por tool · custo

Análise de RAG:
  hit rate · score médio · perguntas sem resposta

Dashboard de qualidade por agente por tenant:
  "Brann errou 12% das qualificações essa semana → ajustar prompt"
```

Isso é o que transforma o "agente que demo" em "agente que opera em produção com confiança".

---

## 6. Gaps Identificados — O que falta preencher

### Gap 1 — Data Hub canônico (modelo de objetos + identidade)
**Status:** Não especificado formalmente  
**Impacto:** Alto — sem isso, integrações viram painéis desconexos  
**Solução:** Definir objetos canônicos + pipeline de identity resolution + timeline unificada

### Gap 2 — Loop de qualidade para agentes (Train/Test/Analyze)
**Status:** Não existe no produto atual  
**Impacto:** Alto — sem isso, não dá para melhorar agentes em produção  
**Solução:** Langfuse como camada de observabilidade + dashboard de performance por agente/tenant

### Gap 3 — Cobrança por outcome (além de assinatura + tokens)
**Status:** Modelo atual é assinatura + tokens  
**Impacto:** Médio — limita conversão de clientes que querem "pagar pelo resultado"  
**Solução:** Explorar modelo híbrido: assinatura base + tokens + "por resolução" para Brann

### Gap 4 — "Train" de agente dentro do produto
**Status:** Prompts só são alterados via prompt_versions no banco  
**Impacto:** Médio — o gestor não consegue "melhorar o agente" sem acesso técnico  
**Solução:** Interface de prompt editor no dashboard com versionamento e teste side-by-side

### Gap 5 — Segurança do n8n self-hosted
**Status:** Não documentado formalmente  
**Impacto:** Alto — CVE-2026-21858 (Ni8mare) teve gravidade crítica; n8n tem vulnerabilidades ativas  
**Solução:** Política de atualização obrigatória + endpoints internos (não públicos) + versão pinada no docker-compose

---

## 7. Metas de Produto por Fase

### Fase 1 — MVP Leaf (meses 1–3)
```
Meta: 5 clientes · MRR R$2.000
Produto: Brann + WhatsApp + RAG + dashboard básico + billing
Diferencial: "Seu WhatsApp respondendo 24h com inteligência"
```

### Fase 2 — Workspace Completo (meses 3–6)
```
Meta: 20 clientes · MRR R$10.000
Produto: Nyra + Alfred + OAuth redes sociais + Studio + Data Hub básico
Diferencial: "Uma equipe digital completa: secretária, social media e analista"
```

### Fase 3 — Skills + Command (meses 6–12)
```
Meta: 50 clientes · MRR R$25.000
Produto: Command + skills + Office visual + marketplace inicial
Diferencial: "Plataforma que você fala por Telegram e os agentes executam"
```

### Fase 4 — Plataforma (mês 12+)
```
Meta: 200 clientes · MRR R$100.000
Produto: Marketplace aberto + white-label + Office 3D + AgentOps
Diferencial: "Sistema operacional de agentes para o seu negócio"
```

---

## 8. O Pitch Correto por Segmento

### Para fechar os primeiros 20 clientes
```
NÃO USAR: "sistema operacional de delegação para IA"
USAR:      "O Brann responde seu WhatsApp 24h e nunca deixa lead sem resposta"

Dor específica → solução tangível → resultado mensurável
```

### Para reter e expandir
```
Depois que o Brann funciona:
"Quer que a Nyra também cuide do seu Instagram automaticamente?"

Depois que a Nyra funciona:
"E se o Alfred gerasse seu relatório de vendas todo domingo às 8h?"
```

### Métricas de ROI para o cliente
```
Leads capturados sem intervenção humana
Conversas atendidas fora do horário comercial
Tempo economizado em criação de conteúdo
Custo por lead vs custo do plano Ginkgo
```

---

*Ginkgo AI Systems — docs/prd/MARKET-REPORT.md v1.0.0 — Março 2026*
