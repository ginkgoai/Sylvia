# Ginkgo Platform — Blueprint Técnico Final
## Versão definitiva da arquitetura de engenharia

> **Versão:** 2.0.0 | **Data:** Março 2026  
> **Status:** Referência canônica — não alterar sem versionamento

---

## 1. Visão de Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENTES / OPERADORES                     │
│              Dashboard Web · Telegram Bot · API direta           │
└──────────────────────────────┬──────────────────────────────────┘
                                │ HTTPS / WSS
┌──────────────────────────────▼──────────────────────────────────┐
│                       CLOUDFLARE (CDN + DDoS)                    │
└──────────┬───────────────────────────────────────┬──────────────┘
           │                                       │
    ┌──────▼──────┐                        ┌──────▼──────┐
    │  Vercel     │                        │  Railway /  │
    │  apps/web   │                        │  Fly.io     │
    │  Next.js    │                        │  apps/api   │
    └──────┬──────┘                        └──────┬──────┘
           │                                      │
           └──────────────────┬───────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│                        API CORE (Fastify)                        │
│                                                                   │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │ Auth / RBAC │  │   Billing /  │  │   Integrations       │   │
│  │ Tenants     │  │  Entitlements│  │   Layer              │   │
│  └─────────────┘  └──────────────┘  └──────────────────────┘   │
│                                                                   │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │  RAG Core   │  │ Agent Runtime│  │   Tool Registry      │   │
│  │  + Retrieval│  │ Brann/Alfred │  │   + Policy Engine    │   │
│  └─────────────┘  └──────────────┘  └──────────────────────┘   │
│                                                                   │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │Observability│  │ Skill Runtime│  │   Webhook Gateway    │   │
│  │ + Metering  │  │ + Marketplace│  │                      │   │
│  └─────────────┘  └──────────────┘  └──────────────────────┘   │
└─────────────────────────────┬───────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│                      WORKERS ASSÍNCRONOS                         │
│  provisioning · ingestion · sync · metering · notifications      │
└──────┬──────────────────────────────────────────┬───────────────┘
       │                                          │
┌──────▼──────────────┐              ┌────────────▼──────────────┐
│  SERVIÇOS EXTERNOS  │              │       DATA LAYER           │
│                     │              │                            │
│  n8n                │              │  Supabase Postgres         │
│  Evolution API      │              │  pgvector (embeddings)     │
│  Chatwoot           │              │  Supabase Storage          │
│  Stripe             │              │  Redis (cache/filas)       │
│  OpenAI / LLMs      │              │                            │
│  Meta Graph API     │              └────────────────────────────┘
│  Google APIs        │
│  Shopify / Shopee   │
│  ClickUp            │
│  OpenClaw           │
└─────────────────────┘
```

---

## 2. Estrutura de Código

```
ginkgo/
├── apps/
│   ├── web/                    # Next.js 14 App Router
│   │   ├── app/
│   │   │   ├── (auth)/         # login, register, oauth callbacks
│   │   │   ├── (dashboard)/    # área logada por módulo
│   │   │   └── api/            # BFF routes
│   │   ├── components/
│   │   │   ├── ui/             # design system
│   │   │   ├── charts/         # Recharts customizado
│   │   │   └── feeds/          # realtime feeds
│   │   └── lib/
│   │       ├── supabase.ts
│   │       ├── stripe.ts
│   │       └── integrations/
│   │
│   └── api/                    # Fastify + TypeScript
│       ├── src/
│       │   ├── modules/
│       │   │   ├── auth/
│       │   │   ├── tenants/
│       │   │   ├── billing/
│       │   │   ├── agents/
│       │   │   ├── rag/
│       │   │   ├── tools/
│       │   │   ├── skills/
│       │   │   └── webhooks/
│       │   ├── middleware/
│       │   │   ├── auth.ts
│       │   │   ├── tenant.ts
│       │   │   └── ratelimit.ts
│       │   └── plugins/
│       │       ├── supabase.ts
│       │       ├── redis.ts
│       │       └── stripe.ts
│
├── packages/
│   ├── db/                     # schema + migrations + tipos gerados
│   ├── auth/                   # helpers de auth compartilhados
│   ├── billing/                # lógica de billing agnóstica
│   ├── rag/                    # pipeline de ingestão e retrieval
│   ├── agents/                 # runtime de agentes (Brann, Alfred, Nyra)
│   ├── integrations/           # connectors (Meta, Google, Shopify…)
│   └── shared/                 # tipos, utils, constantes
│
├── workers/
│   ├── provisioning/           # onboarding de tenant
│   ├── ingestion/              # pipeline RAG
│   ├── sync/                   # sync com integrações externas
│   ├── metering/               # contagem de uso e tokens
│   └── notifications/          # alertas WhatsApp / email
│
├── infra/
│   ├── docker/
│   │   └── docker-compose.yml
│   ├── deploy/
│   └── scripts/
│
├── n8n/
│   └── workflows/
│
└── docs/
    ├── architecture/
    ├── prd/
    └── ops/
```

---

## 3. Platform Core

### 3.1 Auth e RBAC

```typescript
// Roles por tenant
type TenantRole = 'owner' | 'admin' | 'operator' | 'viewer'

// Permissões por role
const PERMISSIONS = {
  owner:    ['*'],
  admin:    ['agents.*', 'knowledge.*', 'channels.*', 'billing.view'],
  operator: ['conversations.*', 'leads.*', 'handoff.*'],
  viewer:   ['dashboard.view', 'reports.view']
}

// Middleware de tenant
// Toda request autenticada deve:
// 1. Validar JWT (Supabase Auth)
// 2. Extrair tenant_id do token ou header X-Tenant-ID
// 3. Validar membership do user naquele tenant
// 4. Injetar {tenant_id, user_id, role} no request context
```

### 3.2 Billing e Entitlements

```
Modelo de 3 camadas:
  1. Subscription (Stripe)     → plano mensal recorrente
  2. Add-ons (Stripe one-time) → skills oficiais ou pacotes de tokens
  3. Marketplace (Stripe Connect) → skills da comunidade com revshare

Entitlement check:
  Antes de qualquer operação premium:
  1. Verificar se tenant tem subscription ativa
  2. Verificar se o plano inclui o recurso solicitado
  3. Verificar saldo de tokens se operação consome tokens
  4. Se bloqueado: retornar 402 com payload de upgrade

Token consumption:
  Cada execução de agente decrementa token_balances.balance
  Se balance <= 0: bloquear ou cobrar overage conforme config do plano
```

### 3.3 Integrations Layer

```
Cada integração segue o padrão:

interface Integration {
  provider: string              // 'meta' | 'google' | 'shopify' | 'evolution'
  connect(tenantId, code): Promise<tokens>
  refresh(tenantId): Promise<tokens>
  pull(tenantId, since): Promise<data>
  webhook(payload): Promise<void>
}

Tokens sempre:
  - Criptografados em repouso (pgcrypto / Supabase Vault)
  - Renovados automaticamente pelo worker sync
  - Nunca expostos ao frontend
```

---

## 4. Agent Runtime

### 4.1 Arquitetura do Runtime

```
Mensagem recebida
  → Webhook Gateway
    → Identificar tenant + canal
      → Session Manager (contexto da conversa)
        → Agent Resolver (qual agente?)
          → Policy Check (pode executar?)
            → LLM Call (com system prompt versionado)
              → Tool Dispatcher (se tool_call)
                → Tool Executor (com log obrigatório)
                  → Response Formatter
                    → Canal de saída
                      → Metering (debitar tokens)
                        → Observability Log
```

### 4.2 Agentes

| Agente | Canal principal | Modelo | Tools core |
|--------|----------------|--------|------------|
| Brann | WhatsApp (Evolution) | gpt-4o | search_knowledge, create_lead, handoff_human, fetch_catalog, schedule |
| Alfred | Interno / API | gpt-4o | query_sql_readonly, generate_report, parse_pdf, extract_fields |
| Nyra | Interno / API | gpt-4o | web_research, draft_copy, summarize, manage_calendar |
| Command | Telegram / Web (OpenClaw) | gpt-4o | Acesso a todas as tools por permissão |

### 4.3 Tool Registry

```typescript
interface Tool {
  name: string
  description: string
  agent: string[]              // quais agentes podem usar
  inputSchema: JSONSchema
  outputSchema: JSONSchema
  permissions: string[]        // permissões necessárias no tenant
  timeout: number
  retries: number
  log: boolean                 // sempre true em produção
  readOnly: boolean
}

// Registro central — toda tool deve ser registrada aqui
// Nenhum agente chama função não registrada
```

### 4.4 Policy Engine

```
Regras por agente (imutáveis):
  Brann:    can_read=true  | can_write=false | destructive=never
  Alfred:   can_read=true  | can_write=requires_confirm | destructive=never
  Nyra:     can_read=true  | can_write=drafts_only | publish=requires_confirm
  Command:  can_read=true  | can_write=by_permission | scope=tenant_only

Regras por tenant (configuráveis):
  handoff_threshold: integer (score mínimo para alertar)
  max_tool_calls_per_turn: integer (default: 5)
  allowed_tools: string[] (subset do Tool Registry)
  blocked_topics: string[] (termos que forçam handoff)
```

---

## 5. RAG Core

### 5.1 Pipeline Completo

```
INGESTÃO
  Fonte (upload/drive/url/integration)
    → knowledge_assets (salva bruto no Storage)
      → Extraction Worker
          PDF → texto via pdf-parse
          DOC → texto via mammoth
          Imagem → OCR / caption via Vision API
          Áudio → transcrição via Whisper
          Vídeo → frames + transcrição
        → knowledge_assets.status = 'extracted'
          → Normalization
              limpeza, deduplicação, metadados, idioma
            → Chunking
                500-900 tokens, overlap 80-150
                split por parágrafo > frase > fixo
              → Embedding
                  text-embedding-3-small (1536 dims)
                  batch de 20 por request
                → knowledge_chunks + pgvector
                  → knowledge_documents.status = 'indexed'

RETRIEVAL
  Query do agente
    → Embedding da query
      → Busca vetorial (pgvector cosine)
        → Busca lexical (Postgres full-text)
          → Merge e deduplicação
            → Filtros: tenant_id, access_role, status, tags
              → Rerank (cross-encoder ou score ponderado)
                → Top-k = 5
                  → Injetar no prompt como contexto
                    → retrieval_logs (query, chunks, scores)
```

### 5.2 Fontes suportadas (v1 → v2)

| Fonte | v1 | v2 |
|-------|----|----|
| Upload manual (PDF, DOC, TXT, MD) | ✅ | ✅ |
| URL pública | ✅ | ✅ |
| FAQ estruturado | ✅ | ✅ |
| Google Drive / Docs / Sheets | — | ✅ |
| Notion | — | ✅ |
| CRM notes | — | ✅ |
| Áudio / transcrição | — | ✅ |
| Vídeo / frames | — | v3 |
| WhatsApp histórico | — | ✅ |

### 5.3 Segurança

```
Toda operação RAG:
  WHERE tenant_id = $tenant_id          -- obrigatório
  AND status = 'indexed'                -- só chunks prontos
  AND access_roles @> $user_roles       -- controle por role
  AND sensitivity NOT IN $blocked       -- por configuração do plano

RLS no Supabase:
  knowledge_chunks: tenant_id isolado via policy
  knowledge_assets: idem
  retrieval_logs: idem
```

---

## 6. Skill Runtime e Marketplace

### 6.1 Estrutura de uma Skill

```
skill-package/
  manifest.json       # declaração completa
  prompts/            # system prompts por agente
  tools/              # tools específicas da skill
  workflows/          # workflows n8n exportados
  ui/                 # extensões de UI (componentes React)
  docs/               # documentação
```

### 6.2 Manifest

```json
{
  "id": "shopify-analytics-pro",
  "name": "Shopify Analytics Pro",
  "version": "1.2.0",
  "author": "community-dev",
  "category": "ecommerce",
  "agents": ["alfred", "command"],
  "requires": {
    "integrations": ["shopify"],
    "plan": "avancado"
  },
  "permissions": ["orders.read", "products.read", "reports.write"],
  "tools": ["shopify_query_orders", "shopify_generate_report"],
  "billing": {
    "model": "subscription",
    "price_brl": 49,
    "trial_days": 7
  },
  "revshare": {
    "developer": 0.70,
    "platform": 0.30
  }
}
```

### 6.3 Fases do Marketplace

```
Fase 1 (agora): NÃO construir. Só preparar schema.
Fase 2: Skills internas como se fossem externas (Leaf, Wave, Pyre, Command)
Fase 3: skill_registry + tenant_skills + manifest loader
Fase 4: GitHub import + validação automatizada + install flow
Fase 5: Monetização comunitária + Stripe Connect para revshare
```

---

## 7. Produtos Comerciais

### 7.1 Leaf — Atendimento

```
Canal: WhatsApp (Evolution API)
Agente: Brann
Core: atendimento, qualificação SPIN, lead capture, handoff, RAG básico
Skills incluídas: FAQ Responder, Lead Qualifier, Appointment Booker
Planos: Básico, Avançado, Futurista
```

### 7.2 Wave — Operação e Tráfego

```
Canal: Dashboard / API
Agente: Alfred
Core: SQL Agent, relatórios, extração documental, métricas
Skills incluídas: Report Generator, Document Parser, Campaign Analyzer
Planos: Avançado, Futurista
```

### 7.3 Pyre — Conteúdo

```
Canal: Dashboard / OpenClaw
Agente: Nyra
Core: pesquisa de mercado, pipeline de conteúdo, calendário editorial
Skills incluídas: Content Creator, Trend Researcher, Meeting Assistant
Planos: Avançado, Futurista
```

### 7.4 Command — Assistente Unificado

```
Canal: Telegram (OpenClaw) / Web
Agente: Command Assistant (acesso a todos os agentes)
Core: orquestrador conversacional, acesso à memória do tenant, LAPLACE routing
Skills incluídas: todas as skills ativas do tenant
Planos: Futurista
```

---

## 8. Deploy e Infra

### 8.1 Topologia

```
Cloudflare (DNS + CDN + DDoS)
  ├── apps/web → Vercel
  ├── apps/api → Railway (ou Fly.io)
  ├── workers/* → Railway (jobs separados)
  ├── n8n → Railway (container)
  ├── Evolution API → Railway (container)
  ├── Chatwoot → Railway (container)
  ├── Redis → Railway (managed) ou Upstash
  └── OpenClaw → Railway (container por tenant)

Supabase Cloud:
  ├── Postgres (banco principal)
  ├── pgvector (embeddings)
  ├── Auth (Supabase Auth)
  └── Storage (assets RAG, uploads)

Stripe:
  ├── Subscriptions (planos recorrentes)
  ├── Payment Intents (pacotes de tokens)
  └── Connect (revshare marketplace — fase 5)
```

### 8.2 Variáveis de ambiente por serviço

```bash
# apps/api
SUPABASE_URL
SUPABASE_SERVICE_ROLE_KEY
REDIS_URL
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
OPENAI_API_KEY
EVOLUTION_API_URL
EVOLUTION_API_KEY
CHATWOOT_URL
CHATWOOT_API_TOKEN

# apps/web
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY

# workers
SUPABASE_URL
SUPABASE_SERVICE_ROLE_KEY
REDIS_URL
OPENAI_API_KEY          # para embeddings no ingestion worker
```

---

## 9. Observabilidade

### 9.1 O que logar em toda execução

```typescript
interface ExecutionLog {
  tenant_id: string
  agent: string
  conversation_id?: string
  prompt_version: string
  tools_used: string[]
  input_tokens: number
  output_tokens: number
  latency_ms: number
  cost_usd: number
  rag_chunks_used?: string[]
  rag_scores?: number[]
  success: boolean
  error?: string
  handoff?: boolean
  created_at: string
}
```

### 9.2 Métricas críticas por tenant

```
Operacional:
  custo_por_conversa
  latencia_media_ms
  taxa_handoff_pct
  taxa_erro_pct
  taxa_rag_hit_pct      (buscas com similarity >= 0.70)

Comercial:
  leads_capturados_dia
  score_medio_leads
  conversao_lead_agendamento
  tempo_medio_qualificacao

Financeiro:
  tokens_usados_periodo
  custo_total_periodo
  custo_por_tenant
  margem_estimada
```

### 9.3 Stack de observabilidade

```
Logs estruturados → PostgreSQL (tool_executions, audit_logs)
Dashboard → Metabase conectado ao Supabase
Alertas → n8n → WhatsApp operador
Tracing (fase 2) → LangSmith para fluxos LangGraph
Métricas (fase 2) → Grafana + Prometheus
```

---

## 10. Fluxo completo do cliente

```
1. Lead acessa landing page
2. Clica em "Começar" → Stripe Checkout (plano selecionado)
3. Pagamento → webhook stripe → tenant criado automaticamente
4. Email de boas-vindas com acesso ao dashboard
5. Onboarding guiado:
   a. Conectar WhatsApp (QR Evolution)
   b. Upload da base de conhecimento (FAQ, catálogo)
   c. Configurar Brann (prompt, handoff, score threshold)
   d. Testar com mensagem de exemplo
6. Go-live: Brann operando no WhatsApp do cliente
7. Dashboard: cliente acompanha conversas, leads, custo
8. Upsell: skill adicional, pacote de tokens, upgrade de plano
```

---

## 11. Prioridade de execução

```
Sprint 1-3   → Core infra + banco + canal WhatsApp + Brann básico
Sprint 4-6   → Lead score + handoff + RAG v1 + dashboard
Sprint 7-10  → Auth web + billing Stripe + onboarding automatizado
Sprint 11-14 → Alfred + Wave + Command Assistant
Sprint 15-18 → Nyra + Pyre + skills internas
Sprint 19+   → Marketplace framework + skills externas
```

---

**Ginkgo AI Systems — Blueprint Técnico Final**  
`architecture v2.0.0 — Março 2026`
