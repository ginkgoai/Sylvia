# AUDIT-GAPS-MAPPING.md — Ginkgo AI Systems
## Auditoria de Arquitetura e Mapeamento de Lacunas

> **Data:** Abril 2026  
> **Status:** Draft de Auditoria  
> **Objetivo:** Identificar o que já temos, o que mudou e o que falta para a arquitetura "Sem Lacunas".

---

## 1. Estado Atual do Repositório (Inventário)

O repositório conta com 32+ documentos técnicos. A estrutura está organizada, mas existem sobreposições e conceitos que precisam de unificação.

| Domínio | Status Atual | Observação |
|---|---|---|
| **Branding/Nomes** | **Inconsistente** | Ainda existem referências a "Wave" e "Pyre". O novo padrão é **Leaf by Ginkgo**. |
| **Agent OS** | **Conceitual** | Temos o PRD, mas falta a especificação de integração com o CEO Fantasma. |
| **Ginkgo Source** | **Estruturado** | Temos o manual v1.1.0, mas falta a camada de "Human Oversight" como sistema. |
| **Governança** | **Fragmentada** | Temos contratos de agentes e roteamento, mas falta a "Matriz de Risco" unificada. |
| **Infra/Deploy** | **Sólido** | Setup Docker, Migrations e Workers bem definidos. |

---

## 2. Lacunas Identificadas (Gaps)

Após analisar os novos conteúdos (pasted_content 1-6), as seguintes lacunas foram mapeadas:

### Gap A: Camada de Observabilidade e Controle Humano (Human Oversight Layer)
- **O que falta:** Um documento que transforme a filosofia de "humano no loop" em um sistema formal de **Governança Adaptativa**.
- **Necessidade:** Definir Níveis de Risco (1, 2, 3), Score de Confiança e Fluxos de Aprovação Seletiva.

### Gap B: O CEO Fantasma (Orquestrador Executivo)
- **O que falta:** O CEO Fantasma está descrito como conceito, mas não está integrado como o **Maestro** acima de Brann, Alfred e Nyra.
- **Necessidade:** Especificar a "Memória Situacional" e o "Painel Executivo" como o cockpit central da empresa.

### Gap C: Unificação de Produto (Leaf by Ginkgo)
- **O que falta:** Substituir formalmente Wave/Pyre por Leaf em toda a documentação técnica.
- **Necessidade:** Refatorar o `GINKGO-AGENT-OS-PRD.md` e o `README.md`.

### Gap D: Integração Claude Opus 4.6 (Cognição Premium)
- **O que falta:** Definir onde o Opus 4.6 entra vs. modelos menores para otimização de custo/performance.
- **Necessidade:** Criar a política de "Escalonamento Cognitivo".

### Gap E: Ciclo de Aprendizado por Erro
- **O que falta:** O sistema não tem um fluxo formal onde o "erro capturado pelo humano" vira "melhoria de prompt/regra".
- **Necessidade:** Especificar o `Failure Analyst Agent` e o loop de feedback.

---

## 3. Plano de Fechamento de Lacunas (Arquitetura Sem Retrabalho)

1.  **Criar `HUMAN-OVERSIGHT-GOVERNANCE.md`:** O protocolo de combate para intervenção humana.
2.  **Criar `CEO-GHOST-SPEC.md`:** A especificação técnica do orquestrador central.
3.  **Refatorar `GINKGO-AGENT-OS-PRD.md` para v2.0:** Unificar Leaf, integrar CEO Fantasma e Governança.
4.  **Atualizar `INDEX.md` e `README.md`:** Refletir a nova hierarquia de marca e produto.

---

*Ginkgo AI Systems — docs/AUDIT-GAPS-MAPPING.md — Abril 2026*
