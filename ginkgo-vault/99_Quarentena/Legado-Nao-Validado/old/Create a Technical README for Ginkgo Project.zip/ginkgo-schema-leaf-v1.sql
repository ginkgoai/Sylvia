-- =============================================================================
-- GINKGO AI SYSTEMS — DATABASE SCHEMA v1.0
-- Parte 3: LEAF — Atendimento Inteligente (Fase 4)
-- Agente: Brann
--
-- Depende de:
--   ginkgo-schema-v1.sql              (Fases 1+2)
--   ginkgo-schema-rag-entities-v1.sql (Fase 3 + Entidades Canônicas)
--
-- Engine: Supabase Postgres 15+
-- Schema principal: leaf
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS leaf;


-- =============================================================================
-- TYPES / ENUMS
-- =============================================================================

CREATE TYPE leaf.channel_type AS ENUM (
    'whatsapp',
    'instagram',
    'telegram',
    'email',
    'chatwoot',
    'webchat',
    'sms'
);

CREATE TYPE leaf.channel_status AS ENUM (
    'active',
    'inactive',
    'error',
    'reconnecting'
);

CREATE TYPE leaf.contact_type AS ENUM (
    'lead',       -- ainda não é customer
    'customer',   -- já tem registro em ginkgo.customers
    'unknown'     -- primeiro contato, ainda não identificado
);

CREATE TYPE leaf.conversation_status AS ENUM (
    'open',
    'bot',        -- sendo tratado pelo Brann
    'handoff',    -- aguardando operador humano
    'human',      -- operador humano assumiu
    'resolved',
    'expired'
);

CREATE TYPE leaf.message_direction AS ENUM (
    'inbound',    -- recebido do contato
    'outbound'    -- enviado pela plataforma (bot ou humano)
);

CREATE TYPE leaf.message_type AS ENUM (
    'text',
    'audio',
    'image',
    'video',
    'document',
    'sticker',
    'location',
    'contact_card',
    'interactive',  -- botões, listas (WhatsApp)
    'template',     -- template HSM WhatsApp
    'system'        -- mensagem interna da plataforma
);

CREATE TYPE leaf.message_status AS ENUM (
    'queued',
    'sent',
    'delivered',
    'read',
    'failed'
);

CREATE TYPE leaf.sender_type AS ENUM (
    'contact',    -- o cliente enviou
    'bot',        -- Brann enviou
    'human',      -- operador humano enviou
    'system'      -- mensagem automática do sistema
);

CREATE TYPE leaf.handoff_reason AS ENUM (
    'requested_by_contact',   -- cliente pediu falar com humano
    'bot_uncertain',          -- Brann não soube responder
    'escalation_rule',        -- regra de negócio ativou escalada
    'sentiment_negative',     -- sentimento negativo detectado
    'keyword_trigger',        -- palavra-chave de escalada
    'timeout',                -- tempo sem resposta do bot
    'manual'                  -- operador forçou
);

CREATE TYPE leaf.sales_phase AS ENUM (
    'active_listening',       -- escuta ativa
    'pain_amplification',     -- amplificação de dor (SPIN)
    'connected_presentation', -- apresentação conectada
    'micro_commitment',       -- micro-compromisso
    'single_cta',             -- CTA único
    'post_sale',              -- pós-venda
    'support'                 -- suporte puro
);


-- =============================================================================
-- L1. CHANNELS
-- Canal de atendimento configurado por tenant.
-- Ex: número WhatsApp +55 53 99..., conta Instagram @gtech.automatiza
-- =============================================================================

CREATE TABLE leaf.channels (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    agent_id        UUID REFERENCES agents.instances (id) ON DELETE SET NULL,
    channel_type    leaf.channel_type NOT NULL,
    name            TEXT NOT NULL,             -- ex: "WhatsApp Principal"
    status          leaf.channel_status NOT NULL DEFAULT 'inactive',
    -- Identificação do canal na plataforma externa
    external_id     TEXT,                      -- phone number id, instagram account id, etc.
    external_name   TEXT,                      -- nome/número como aparece na plataforma
    -- Configuração de integração
    account_id      UUID REFERENCES integrations.accounts (id) ON DELETE SET NULL,
    -- Configuração do canal
    is_default      BOOLEAN NOT NULL DEFAULT false,
    auto_reply      BOOLEAN NOT NULL DEFAULT true,
    working_hours   JSONB,                     -- {enabled: true, schedule: [{day: 1, start: "08:00", end: "18:00"}]}
    away_message    TEXT,                      -- mensagem fora do horário
    greeting_message TEXT,
    -- Métricas (denormalizadas, atualizadas por worker)
    total_conversations INTEGER NOT NULL DEFAULT 0,
    open_conversations  INTEGER NOT NULL DEFAULT 0,
    -- Controle
    last_error      TEXT,
    last_error_at   TIMESTAMPTZ,
    connected_at    TIMESTAMPTZ,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_channels_tenant  ON leaf.channels (tenant_id);
CREATE INDEX idx_channels_type    ON leaf.channels (channel_type);
CREATE INDEX idx_channels_status  ON leaf.channels (status);

SELECT ginkgo.create_updated_at_trigger('leaf', 'channels');

ALTER TABLE leaf.channels ENABLE ROW LEVEL SECURITY;

CREATE POLICY channels_tenant ON leaf.channels
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- L2. CONTACTS
-- Pessoa que entrou em contato por qualquer canal.
-- Pode ser ligada a ginkgo.leads ou ginkgo.customers.
-- Um contact pode ter múltiplos channel_identities (WhatsApp E Instagram).
-- =============================================================================

CREATE TABLE leaf.contacts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    -- Vínculo com entidades canônicas
    contact_type    leaf.contact_type NOT NULL DEFAULT 'unknown',
    customer_id     UUID REFERENCES ginkgo.customers (id) ON DELETE SET NULL,
    lead_id         UUID REFERENCES ginkgo.leads (id) ON DELETE SET NULL,
    -- Identificação
    name            TEXT,
    phone           TEXT,
    email           TEXT,
    -- Identificadores por canal (ex: WhatsApp JID, Instagram user_id)
    channel_ids     JSONB NOT NULL DEFAULT '{}',   -- {"whatsapp": "5553991214817@s.whatsapp.net", "instagram": "12345678"}
    -- Perfil
    avatar_url      TEXT,
    language        TEXT NOT NULL DEFAULT 'pt',
    timezone        TEXT,
    tags            TEXT[] NOT NULL DEFAULT '{}',
    -- Contexto de IA (atualizado pelo Brann após cada conversa)
    ai_profile      JSONB NOT NULL DEFAULT '{}',   -- {pains, interests, objections, phase_history}
    -- Métricas de atendimento
    conversation_count  INTEGER NOT NULL DEFAULT 0,
    last_seen_at        TIMESTAMPTZ,
    first_seen_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- Opt-in/Opt-out
    opted_in        BOOLEAN NOT NULL DEFAULT true,
    opted_out_at    TIMESTAMPTZ,
    -- Bloqueio
    is_blocked      BOOLEAN NOT NULL DEFAULT false,
    blocked_at      TIMESTAMPTZ,
    blocked_reason  TEXT,
    notes           TEXT,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_contacts_tenant   ON leaf.contacts (tenant_id);
CREATE INDEX idx_contacts_phone    ON leaf.contacts (tenant_id, phone);
CREATE INDEX idx_contacts_customer ON leaf.contacts (customer_id);
CREATE INDEX idx_contacts_lead     ON leaf.contacts (lead_id);
CREATE INDEX idx_contacts_chan_ids ON leaf.contacts USING GIN (channel_ids);
CREATE INDEX idx_contacts_tags     ON leaf.contacts USING GIN (tags);
CREATE INDEX idx_contacts_type     ON leaf.contacts (tenant_id, contact_type);

SELECT ginkgo.create_updated_at_trigger('leaf', 'contacts');

ALTER TABLE leaf.contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY contacts_tenant ON leaf.contacts
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );

-- Trigger: mantém conversation_count atualizado
CREATE OR REPLACE FUNCTION leaf.sync_contact_conv_count()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE leaf.contacts SET conversation_count = conversation_count + 1
        WHERE id = NEW.contact_id;
    END IF;
    RETURN NULL;
END;
$$;
-- (trigger criado após leaf.conversations)


-- =============================================================================
-- L3. CONVERSATIONS
-- Uma conversa = uma sessão de atendimento em um canal específico.
-- Múltiplas mensagens, um contato, um canal.
-- =============================================================================

CREATE TABLE leaf.conversations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    channel_id      UUID NOT NULL REFERENCES leaf.channels (id) ON DELETE CASCADE,
    contact_id      UUID NOT NULL REFERENCES leaf.contacts (id) ON DELETE CASCADE,
    agent_id        UUID REFERENCES agents.instances (id) ON DELETE SET NULL,
    -- Status do fluxo
    status          leaf.conversation_status NOT NULL DEFAULT 'bot',
    sales_phase     leaf.sales_phase NOT NULL DEFAULT 'active_listening',
    -- Operador humano (quando em handoff/human)
    assigned_to     UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    assigned_at     TIMESTAMPTZ,
    -- Identificador externo (session_id da Evolution API, thread_id, etc.)
    external_id     TEXT,
    -- Contexto ativo de IA — injetado a cada resposta do Brann
    context_summary TEXT,                      -- resumo gerado pelo Brann da conversa atual
    rag_context     JSONB NOT NULL DEFAULT '{}', -- último contexto RAG retornado
    lead_profile    JSONB NOT NULL DEFAULT '{}', -- perfil de lead construído na conversa
    -- Métricas
    message_count   INTEGER NOT NULL DEFAULT 0,
    bot_message_count INTEGER NOT NULL DEFAULT 0,
    human_message_count INTEGER NOT NULL DEFAULT 0,
    first_response_time_seconds INTEGER,       -- tempo até 1ª resposta do bot
    resolution_time_seconds     INTEGER,       -- tempo total até resolved
    -- Satisfação (pós-conversa)
    csat_score      SMALLINT CHECK (csat_score BETWEEN 1 AND 5),
    csat_feedback   TEXT,
    csat_at         TIMESTAMPTZ,
    -- Flags
    is_spam         BOOLEAN NOT NULL DEFAULT false,
    human_takeover  BOOLEAN NOT NULL DEFAULT false, -- flag de takeover ativo
    -- Temporalidade
    last_message_at TIMESTAMPTZ,
    resolved_at     TIMESTAMPTZ,
    expired_at      TIMESTAMPTZ,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_convs_tenant    ON leaf.conversations (tenant_id);
CREATE INDEX idx_convs_channel   ON leaf.conversations (channel_id);
CREATE INDEX idx_convs_contact   ON leaf.conversations (contact_id);
CREATE INDEX idx_convs_status    ON leaf.conversations (tenant_id, status);
CREATE INDEX idx_convs_assigned  ON leaf.conversations (assigned_to);
CREATE INDEX idx_convs_phase     ON leaf.conversations (sales_phase);
CREATE INDEX idx_convs_last_msg  ON leaf.conversations (tenant_id, last_message_at DESC);

SELECT ginkgo.create_updated_at_trigger('leaf', 'conversations');

ALTER TABLE leaf.conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY convs_tenant ON leaf.conversations
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );

-- Trigger para contact.conversation_count
CREATE TRIGGER trg_sync_contact_conv_count
    AFTER INSERT ON leaf.conversations
    FOR EACH ROW EXECUTE FUNCTION leaf.sync_contact_conv_count();


-- =============================================================================
-- L4. MESSAGES
-- Cada mensagem trocada numa conversa.
-- Particionado por mês: em produção, milhões de mensagens por tenant.
-- =============================================================================

CREATE TABLE leaf.messages (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL REFERENCES leaf.conversations (id) ON DELETE CASCADE,
    -- Identificação externa (para deduplicação com webhook da Evolution API)
    external_id     TEXT,
    -- Direção e tipo
    direction       leaf.message_direction NOT NULL,
    message_type    leaf.message_type NOT NULL DEFAULT 'text',
    sender_type     leaf.sender_type NOT NULL,
    sender_id       UUID,                      -- profile_id se human, agent_id se bot, contact_id se contact
    -- Conteúdo
    content         TEXT,                      -- texto principal
    caption         TEXT,                      -- legenda de mídia
    -- Mídia
    media_url       TEXT,                      -- URL do arquivo no storage ou externo
    media_type      TEXT,                      -- MIME type
    media_size      INTEGER,                   -- bytes
    media_duration  INTEGER,                   -- segundos (áudio/vídeo)
    -- Transcrição de áudio (gerada pelo STT worker)
    audio_transcript TEXT,
    -- Metadados de entrega
    status          leaf.message_status NOT NULL DEFAULT 'queued',
    status_updated_at TIMESTAMPTZ,
    -- Metadados WhatsApp / Instagram
    quoted_message_id TEXT,                    -- mensagem citada (reply)
    reaction        TEXT,                      -- emoji de reação recebida
    -- Contexto de IA da resposta (apenas para mensagens do bot)
    ai_model        TEXT,                      -- modelo usado (ex: 'gpt-4o')
    ai_tokens_used  INTEGER,
    ai_latency_ms   INTEGER,
    ai_sales_phase  leaf.sales_phase,          -- fase de venda no momento do envio
    ai_rag_used     BOOLEAN NOT NULL DEFAULT false,
    -- Análise de sentimento (para mensagens inbound)
    sentiment       TEXT,                      -- 'positive' | 'neutral' | 'negative'
    sentiment_score NUMERIC(4,3),
    -- Typing delay aplicado (humanização Brann)
    typing_delay_ms INTEGER,
    -- Flags
    is_deleted      BOOLEAN NOT NULL DEFAULT false,
    is_forwarded    BOOLEAN NOT NULL DEFAULT false,
    metadata        JSONB NOT NULL DEFAULT '{}',
    sent_at         TIMESTAMPTZ NOT NULL DEFAULT now()
)
PARTITION BY RANGE (sent_at);

-- Partições trimestrais 2025
CREATE TABLE leaf.messages_2025_q1
    PARTITION OF leaf.messages
    FOR VALUES FROM ('2025-01-01') TO ('2025-04-01');
CREATE TABLE leaf.messages_2025_q2
    PARTITION OF leaf.messages
    FOR VALUES FROM ('2025-04-01') TO ('2025-07-01');
CREATE TABLE leaf.messages_2025_q3
    PARTITION OF leaf.messages
    FOR VALUES FROM ('2025-07-01') TO ('2025-10-01');
CREATE TABLE leaf.messages_2025_q4
    PARTITION OF leaf.messages
    FOR VALUES FROM ('2025-10-01') TO ('2026-01-01');

-- Partições 2026
CREATE TABLE leaf.messages_2026_h1
    PARTITION OF leaf.messages
    FOR VALUES FROM ('2026-01-01') TO ('2026-07-01');
CREATE TABLE leaf.messages_2026_h2
    PARTITION OF leaf.messages
    FOR VALUES FROM ('2026-07-01') TO ('2027-01-01');

CREATE INDEX idx_msgs_tenant   ON leaf.messages (tenant_id, sent_at DESC);
CREATE INDEX idx_msgs_conv     ON leaf.messages (conversation_id, sent_at ASC);
CREATE INDEX idx_msgs_ext_id   ON leaf.messages (tenant_id, external_id);
CREATE INDEX idx_msgs_dir      ON leaf.messages (direction, sent_at DESC);
CREATE INDEX idx_msgs_type     ON leaf.messages (sender_type, sent_at DESC);
-- FTS no conteúdo para busca de histórico
CREATE INDEX idx_msgs_fts      ON leaf.messages
    USING GIN (to_tsvector('portuguese', COALESCE(content, '') || ' ' || COALESCE(audio_transcript, '')));

ALTER TABLE leaf.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY msgs_tenant ON leaf.messages
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );

-- Trigger: atualiza métricas da conversa a cada nova mensagem
CREATE OR REPLACE FUNCTION leaf.sync_conversation_metrics()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    UPDATE leaf.conversations SET
        message_count = message_count + 1,
        bot_message_count = bot_message_count +
            CASE WHEN NEW.sender_type = 'bot' THEN 1 ELSE 0 END,
        human_message_count = human_message_count +
            CASE WHEN NEW.sender_type = 'human' THEN 1 ELSE 0 END,
        last_message_at = NEW.sent_at,
        updated_at = now()
    WHERE id = NEW.conversation_id;

    -- Atualiza last_seen_at do contact em mensagens inbound
    IF NEW.direction = 'inbound' THEN
        UPDATE leaf.contacts SET
            last_seen_at = NEW.sent_at,
            updated_at   = now()
        WHERE id = (
            SELECT contact_id FROM leaf.conversations WHERE id = NEW.conversation_id
        );
    END IF;

    RETURN NULL;
END;
$$;

CREATE TRIGGER trg_sync_conv_metrics
    AFTER INSERT ON leaf.messages
    FOR EACH ROW EXECUTE FUNCTION leaf.sync_conversation_metrics();


-- =============================================================================
-- L5. MESSAGE BATCHES
-- Brann agrupa múltiplas mensagens numa única resposta lógica,
-- enviando cada bloco com typing delay individual.
-- Esta tabela registra o batch para analytics e reenvio.
-- =============================================================================

CREATE TABLE leaf.message_batches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL REFERENCES leaf.conversations (id) ON DELETE CASCADE,
    -- IDs das mensagens neste batch (em ordem)
    message_ids     UUID[] NOT NULL DEFAULT '{}',
    -- Contexto da geração
    trigger_message_id UUID,                   -- mensagem do contato que gerou este batch
    ai_model        TEXT,
    ai_tokens_used  INTEGER,
    ai_latency_ms   INTEGER,
    sales_phase     leaf.sales_phase,
    rag_was_used    BOOLEAN NOT NULL DEFAULT false,
    rag_chunk_ids   UUID[],                    -- chunks usados nesta resposta
    audio_included  BOOLEAN NOT NULL DEFAULT false,
    total_delay_ms  INTEGER,                   -- delay total de typing aplicado
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_batches_conv   ON leaf.message_batches (conversation_id);
CREATE INDEX idx_batches_tenant ON leaf.message_batches (tenant_id, created_at DESC);

ALTER TABLE leaf.message_batches ENABLE ROW LEVEL SECURITY;

CREATE POLICY batches_tenant ON leaf.message_batches
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- L6. HANDOFFS
-- Registro de cada transferência bot → humano ou humano → bot.
-- =============================================================================

CREATE TABLE leaf.handoffs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL REFERENCES leaf.conversations (id) ON DELETE CASCADE,
    contact_id      UUID NOT NULL REFERENCES leaf.contacts (id) ON DELETE CASCADE,
    -- Direção da transferência
    from_type       leaf.sender_type NOT NULL,  -- quem estava antes
    to_type         leaf.sender_type NOT NULL,  -- quem assumiu
    -- Motivo
    reason          leaf.handoff_reason NOT NULL,
    reason_detail   TEXT,
    -- Operador envolvido
    operator_id     UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    -- Temporalidade
    requested_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    accepted_at     TIMESTAMPTZ,               -- quando o operador aceitou
    resolved_at     TIMESTAMPTZ,               -- quando foi encerrado/devolvido ao bot
    wait_time_seconds INTEGER,                 -- tempo até operador aceitar
    handle_time_seconds INTEGER,               -- tempo do operador na conversa
    -- Contexto
    bot_summary     TEXT,                      -- resumo gerado pelo Brann antes de passar
    resolution_note TEXT,                      -- nota do operador ao fechar
    outcome         TEXT,                      -- 'resolved' | 'returned_to_bot' | 'expired'
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_handoffs_tenant  ON leaf.handoffs (tenant_id);
CREATE INDEX idx_handoffs_conv    ON leaf.handoffs (conversation_id);
CREATE INDEX idx_handoffs_op      ON leaf.handoffs (operator_id);
CREATE INDEX idx_handoffs_reason  ON leaf.handoffs (reason);
CREATE INDEX idx_handoffs_created ON leaf.handoffs (tenant_id, created_at DESC);

SELECT ginkgo.create_updated_at_trigger('leaf', 'handoffs');

ALTER TABLE leaf.handoffs ENABLE ROW LEVEL SECURITY;

CREATE POLICY handoffs_tenant ON leaf.handoffs
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- L7. CONVERSATION LABELS
-- Sistema de etiquetas para organizar conversas (ex: "urgente", "pós-venda").
-- =============================================================================

CREATE TABLE leaf.labels (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    color       TEXT NOT NULL DEFAULT '#00e5a0',
    description TEXT,
    is_active   BOOLEAN NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, name)
);

CREATE TABLE leaf.conversation_labels (
    conversation_id UUID NOT NULL REFERENCES leaf.conversations (id) ON DELETE CASCADE,
    label_id        UUID NOT NULL REFERENCES leaf.labels (id) ON DELETE CASCADE,
    added_by        UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    added_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (conversation_id, label_id)
);

CREATE INDEX idx_conv_labels_label ON leaf.conversation_labels (label_id);

ALTER TABLE leaf.labels ENABLE ROW LEVEL SECURITY;
ALTER TABLE leaf.conversation_labels ENABLE ROW LEVEL SECURITY;

CREATE POLICY labels_tenant ON leaf.labels
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );

CREATE POLICY conv_labels_tenant ON leaf.conversation_labels
    USING (
        conversation_id IN (
            SELECT id FROM leaf.conversations c
            WHERE c.tenant_id IN (
                SELECT tenant_id FROM ginkgo.memberships m
                JOIN ginkgo.profiles p ON p.id = m.profile_id
                WHERE p.auth_user_id = auth.uid()
            )
        )
    );


-- =============================================================================
-- L8. QUICK REPLIES
-- Respostas rápidas configuradas por tenant para operadores humanos.
-- =============================================================================

CREATE TABLE leaf.quick_replies (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    title       TEXT NOT NULL,             -- nome curto para busca (ex: "Saudação")
    content     TEXT NOT NULL,             -- conteúdo da mensagem
    shortcut    TEXT,                      -- ex: "/ola" para autocompletar
    tags        TEXT[] NOT NULL DEFAULT '{}',
    is_active   BOOLEAN NOT NULL DEFAULT true,
    use_count   INTEGER NOT NULL DEFAULT 0,
    created_by  UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, shortcut)
);

CREATE INDEX idx_qr_tenant   ON leaf.quick_replies (tenant_id);
CREATE INDEX idx_qr_shortcut ON leaf.quick_replies (tenant_id, shortcut);
CREATE INDEX idx_qr_tags     ON leaf.quick_replies USING GIN (tags);

SELECT ginkgo.create_updated_at_trigger('leaf', 'quick_replies');

ALTER TABLE leaf.quick_replies ENABLE ROW LEVEL SECURITY;

CREATE POLICY quick_replies_tenant ON leaf.quick_replies
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- L9. CANNED FLOWS
-- Fluxos de resposta pré-configurados para o Brann.
-- Podem ser ativados por keyword, contexto ou fase de venda.
-- =============================================================================

CREATE TABLE leaf.canned_flows (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    description     TEXT,
    trigger_type    TEXT NOT NULL,             -- 'keyword' | 'phase' | 'intent' | 'manual'
    trigger_value   TEXT,                      -- a keyword, fase ou intent que ativa
    -- Sequência de mensagens a enviar
    messages        JSONB NOT NULL DEFAULT '[]',
    -- [{type: 'text', content: '...', delay_ms: 1000}, {type: 'audio', ...}]
    -- Condições
    conditions      JSONB NOT NULL DEFAULT '{}',
    -- Prioridade (quando múltiplos flows batem)
    priority        INTEGER NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    use_count       INTEGER NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_flows_tenant   ON leaf.canned_flows (tenant_id);
CREATE INDEX idx_flows_trigger  ON leaf.canned_flows (trigger_type, trigger_value);
CREATE INDEX idx_flows_active   ON leaf.canned_flows (is_active);

SELECT ginkgo.create_updated_at_trigger('leaf', 'canned_flows');

ALTER TABLE leaf.canned_flows ENABLE ROW LEVEL SECURITY;

CREATE POLICY flows_tenant ON leaf.canned_flows
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- L10. BRANN CONFIG
-- Configuração específica do agente Brann por tenant.
-- Separada de agents.instances para não poluir o agent_core genérico.
-- =============================================================================

CREATE TABLE leaf.brann_config (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL UNIQUE
                                REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    agent_id                UUID REFERENCES agents.instances (id) ON DELETE SET NULL,
    -- Personalidade
    agent_name              TEXT NOT NULL DEFAULT 'Brann',
    agent_persona           TEXT,              -- descrição da persona
    -- Vendas
    default_sales_phase     leaf.sales_phase NOT NULL DEFAULT 'active_listening',
    spin_selling_enabled    BOOLEAN NOT NULL DEFAULT true,
    mirroring_enabled       BOOLEAN NOT NULL DEFAULT true,
    -- Humanização
    typing_delay_enabled    BOOLEAN NOT NULL DEFAULT true,
    typing_wpm              INTEGER NOT NULL DEFAULT 40,  -- palavras por minuto simuladas
    min_delay_ms            INTEGER NOT NULL DEFAULT 800,
    max_delay_ms            INTEGER NOT NULL DEFAULT 4000,
    -- Áudio
    audio_enabled           BOOLEAN NOT NULL DEFAULT true,
    audio_probability       NUMERIC(3,2) NOT NULL DEFAULT 0.40, -- 40% das respostas substantivas
    elevenlabs_voice_id     TEXT,
    -- RAG
    rag_enabled             BOOLEAN NOT NULL DEFAULT true,
    rag_min_score           NUMERIC(4,3) NOT NULL DEFAULT 0.65,
    rag_max_chunks          INTEGER NOT NULL DEFAULT 6,
    -- Handoff
    handoff_keywords        TEXT[] NOT NULL DEFAULT
                                ARRAY['humano', 'atendente', 'pessoa', 'falar com alguém'],
    handoff_sentiment_threshold NUMERIC(4,3) NOT NULL DEFAULT -0.5,
    -- Takeover
    takeover_keyword        TEXT NOT NULL DEFAULT '#takeover',
    return_keyword          TEXT NOT NULL DEFAULT '#bot',
    -- Contexto
    max_history_messages    INTEGER NOT NULL DEFAULT 20,
    context_window_tokens   INTEGER NOT NULL DEFAULT 8000,
    -- LLM
    llm_model               TEXT NOT NULL DEFAULT 'gpt-4o',
    llm_temperature         NUMERIC(3,2) NOT NULL DEFAULT 0.7,
    llm_max_tokens          INTEGER NOT NULL DEFAULT 1000,
    -- CRM automático
    auto_update_lead        BOOLEAN NOT NULL DEFAULT true,
    auto_create_lead        BOOLEAN NOT NULL DEFAULT true,
    -- Configurações extras
    extra_config            JSONB NOT NULL DEFAULT '{}',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

SELECT ginkgo.create_updated_at_trigger('leaf', 'brann_config');

ALTER TABLE leaf.brann_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY brann_cfg_tenant ON leaf.brann_config
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );

-- Apenas owner/admin pode editar
CREATE POLICY brann_cfg_edit ON leaf.brann_config
    FOR UPDATE
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m.role IN ('owner', 'admin')
        )
    );


-- =============================================================================
-- L11. CONVERSATION SESSIONS (Redis mirror)
-- Estado em tempo real da conversa — espelhado do Redis para persistência.
-- Atualizado a cada mensagem pelo Brann. Permite recovery após restart.
-- =============================================================================

CREATE TABLE leaf.conversation_sessions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL UNIQUE
                        REFERENCES leaf.conversations (id) ON DELETE CASCADE,
    -- Estado do Brann nesta conversa
    current_phase   leaf.sales_phase NOT NULL DEFAULT 'active_listening',
    turn_count      INTEGER NOT NULL DEFAULT 0,
    -- Últimas N mensagens (cache para contexto sem ir ao banco)
    recent_messages JSONB NOT NULL DEFAULT '[]',  -- [{role, content, ts}]
    -- Perfil do lead construído até agora
    lead_profile    JSONB NOT NULL DEFAULT '{}',
    -- Flags de controle
    human_takeover  BOOLEAN NOT NULL DEFAULT false,
    takeover_by     UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    -- TTL — expirado se sem mensagem há X horas
    last_activity   TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at      TIMESTAMPTZ NOT NULL DEFAULT now() + INTERVAL '24 hours',
    metadata        JSONB NOT NULL DEFAULT '{}',
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_sessions_tenant  ON leaf.conversation_sessions (tenant_id);
CREATE INDEX idx_sessions_expires ON leaf.conversation_sessions (expires_at);

SELECT ginkgo.create_updated_at_trigger('leaf', 'conversation_sessions');

ALTER TABLE leaf.conversation_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY sessions_tenant ON leaf.conversation_sessions
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- L12. FUNCTIONS — Helpers para o Brann
-- =============================================================================

-- Busca ou cria contact pelo identificador do canal
-- Chamada pelo webhook worker a cada mensagem inbound
CREATE OR REPLACE FUNCTION leaf.upsert_contact(
    p_tenant_id     UUID,
    p_channel_type  TEXT,
    p_channel_id    TEXT,   -- JID do WhatsApp, user_id do Instagram, etc.
    p_name          TEXT DEFAULT NULL,
    p_phone         TEXT DEFAULT NULL,
    p_avatar_url    TEXT DEFAULT NULL
)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_contact_id UUID;
BEGIN
    -- Tenta encontrar pelo channel_id
    SELECT id INTO v_contact_id
    FROM leaf.contacts
    WHERE tenant_id = p_tenant_id
      AND channel_ids ->> p_channel_type = p_channel_id
    LIMIT 1;

    IF v_contact_id IS NULL THEN
        -- Cria novo contact
        INSERT INTO leaf.contacts (
            tenant_id, channel_ids, name, phone, avatar_url
        ) VALUES (
            p_tenant_id,
            jsonb_build_object(p_channel_type, p_channel_id),
            p_name,
            p_phone,
            p_avatar_url
        )
        RETURNING id INTO v_contact_id;
    ELSE
        -- Atualiza dados se fornecidos
        UPDATE leaf.contacts SET
            name       = COALESCE(p_name, name),
            phone      = COALESCE(p_phone, phone),
            avatar_url = COALESCE(p_avatar_url, avatar_url),
            channel_ids = channel_ids || jsonb_build_object(p_channel_type, p_channel_id),
            updated_at = now()
        WHERE id = v_contact_id;
    END IF;

    RETURN v_contact_id;
END;
$$;

-- Busca conversa aberta de um contato num canal, ou cria nova
CREATE OR REPLACE FUNCTION leaf.get_or_create_conversation(
    p_tenant_id  UUID,
    p_channel_id UUID,
    p_contact_id UUID,
    p_agent_id   UUID DEFAULT NULL
)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_conv_id UUID;
BEGIN
    -- Conversa aberta existente
    SELECT id INTO v_conv_id
    FROM leaf.conversations
    WHERE tenant_id  = p_tenant_id
      AND channel_id = p_channel_id
      AND contact_id = p_contact_id
      AND status NOT IN ('resolved', 'expired')
    ORDER BY created_at DESC
    LIMIT 1;

    IF v_conv_id IS NULL THEN
        INSERT INTO leaf.conversations (
            tenant_id, channel_id, contact_id, agent_id, status
        ) VALUES (
            p_tenant_id, p_channel_id, p_contact_id, p_agent_id, 'bot'
        )
        RETURNING id INTO v_conv_id;
    END IF;

    RETURN v_conv_id;
END;
$$;

-- Ativa handoff: muda status da conversa e cria registro de handoff
CREATE OR REPLACE FUNCTION leaf.trigger_handoff(
    p_conversation_id UUID,
    p_reason          leaf.handoff_reason,
    p_reason_detail   TEXT DEFAULT NULL,
    p_bot_summary     TEXT DEFAULT NULL
)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_handoff_id UUID;
    v_tenant_id  UUID;
    v_contact_id UUID;
BEGIN
    SELECT tenant_id, contact_id INTO v_tenant_id, v_contact_id
    FROM leaf.conversations WHERE id = p_conversation_id;

    -- Atualiza status da conversa
    UPDATE leaf.conversations SET
        status         = 'handoff',
        human_takeover = true,
        updated_at     = now()
    WHERE id = p_conversation_id;

    -- Cria registro de handoff
    INSERT INTO leaf.handoffs (
        tenant_id, conversation_id, contact_id,
        from_type, to_type, reason, reason_detail, bot_summary
    ) VALUES (
        v_tenant_id, p_conversation_id, v_contact_id,
        'bot', 'human', p_reason, p_reason_detail, p_bot_summary
    )
    RETURNING id INTO v_handoff_id;

    RETURN v_handoff_id;
END;
$$;


-- =============================================================================
-- L13. VIEWS — Dashboard de Atendimento
-- =============================================================================

-- Visão geral de atendimento por tenant
CREATE VIEW leaf.attendance_overview AS
SELECT
    c.tenant_id,
    COUNT(*) FILTER (WHERE c.status = 'bot')      AS bot_active,
    COUNT(*) FILTER (WHERE c.status = 'handoff')  AS pending_handoff,
    COUNT(*) FILTER (WHERE c.status = 'human')    AS with_human,
    COUNT(*) FILTER (WHERE c.status = 'open')     AS open_total,
    COUNT(*) FILTER (WHERE c.status = 'resolved'
        AND c.resolved_at >= now() - INTERVAL '24 hours') AS resolved_today,
    ROUND(AVG(c.first_response_time_seconds)::NUMERIC, 0) AS avg_first_response_s,
    ROUND(AVG(c.resolution_time_seconds)::NUMERIC, 0)     AS avg_resolution_s,
    ROUND(AVG(c.csat_score)::NUMERIC, 2)                  AS avg_csat,
    COUNT(*) FILTER (WHERE c.human_takeover = true)       AS takeovers_total
FROM leaf.conversations c
WHERE c.created_at >= now() - INTERVAL '30 days'
GROUP BY c.tenant_id;

-- Conversas em handoff aguardando operador (inbox de handoffs)
CREATE VIEW leaf.handoff_inbox AS
SELECT
    h.id           AS handoff_id,
    h.tenant_id,
    h.conversation_id,
    h.reason,
    h.reason_detail,
    h.bot_summary,
    h.requested_at,
    h.wait_time_seconds,
    ct.id          AS contact_id,
    ct.name        AS contact_name,
    ct.phone       AS contact_phone,
    ct.avatar_url,
    ch.name        AS channel_name,
    ch.channel_type
FROM leaf.handoffs h
JOIN leaf.conversations cv ON cv.id = h.conversation_id
JOIN leaf.contacts ct      ON ct.id = h.contact_id
JOIN leaf.channels ch      ON ch.id = cv.channel_id
WHERE h.accepted_at IS NULL
  AND h.resolved_at IS NULL
ORDER BY h.requested_at ASC;

-- Métricas do Brann por tenant
CREATE VIEW leaf.brann_metrics AS
SELECT
    m.tenant_id,
    COUNT(*) FILTER (WHERE m.sender_type = 'bot')               AS bot_messages_sent,
    COUNT(*) FILTER (WHERE m.ai_rag_used = true)                AS rag_used_count,
    COUNT(*) FILTER (WHERE m.audio_included = false
        AND m.sender_type = 'bot')                              AS text_only_responses,
    ROUND(AVG(m.ai_latency_ms) FILTER (WHERE m.sender_type = 'bot')::NUMERIC, 0) AS avg_ai_latency_ms,
    ROUND(AVG(m.ai_tokens_used) FILTER (WHERE m.sender_type = 'bot')::NUMERIC, 0) AS avg_tokens_per_msg,
    SUM(m.ai_tokens_used) FILTER (WHERE m.sender_type = 'bot') AS total_tokens_used,
    COUNT(*) FILTER (WHERE m.sentiment = 'positive'
        AND m.direction = 'inbound')                            AS positive_inbound,
    COUNT(*) FILTER (WHERE m.sentiment = 'negative'
        AND m.direction = 'inbound')                            AS negative_inbound
FROM leaf.messages m
WHERE m.sent_at >= now() - INTERVAL '30 days'
GROUP BY m.tenant_id;

-- Distribuição de fases de venda ativas
CREATE VIEW leaf.sales_phase_distribution AS
SELECT
    tenant_id,
    sales_phase,
    COUNT(*)                        AS active_conversations,
    AVG(message_count)::NUMERIC(6,1) AS avg_messages
FROM leaf.conversations
WHERE status IN ('bot', 'open')
GROUP BY tenant_id, sales_phase;


-- =============================================================================
-- L14. SEED DATA — brann_config default para novos tenants
-- (Normalmente inserido pelo provisioning worker ao ativar skill 'leaf')
-- =============================================================================

-- Comentado — executar via provisioning worker, não em seed global:
/*
INSERT INTO leaf.brann_config (tenant_id, agent_id)
SELECT t.id, ai.id
FROM ginkgo.tenants t
JOIN agents.instances ai ON ai.tenant_id = t.id AND ai.skill_key = 'leaf'
WHERE NOT EXISTS (
    SELECT 1 FROM leaf.brann_config bc WHERE bc.tenant_id = t.id
);
*/


-- =============================================================================
-- FIM — ginkgo-schema-leaf-v1.sql
--
-- Schema completo: ~850 linhas
-- Tabelas: channels, contacts, conversations, messages, message_batches,
--          handoffs, labels, conversation_labels, quick_replies,
--          canned_flows, brann_config, conversation_sessions
-- Functions: upsert_contact, get_or_create_conversation, trigger_handoff
-- Views: attendance_overview, handoff_inbox, brann_metrics,
--        sales_phase_distribution
--
-- Próximo schema:
--   ginkgo-schema-command-v1.sql — Command Assistant / OpenClaw
--   sessions, tool_calls, tool_registry, runtime_policies (Fase 5)
-- =============================================================================
