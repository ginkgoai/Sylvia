# Ginkgo Source
## Plataforma Operacional para Criação e Entrega de Soluções Digitais com IA

> O **Ginkgo Source** é o sistema onde clientes entram e as soluções nascem. Ele atua como o núcleo de conversão entre intenção e execução, coordenando uma malha de agentes, workflows e sistemas inteligentes para entregar automações, aplicações, sites e operações de IA.
> **Versão:** 1.0.0 | **Data:** Abril 2026
> **Filosofia:** Da demanda à operação. Você pede. O Source estrutura. A Ginkgo entrega.

---

## Índice

1.  [Visão Geral](#1-visão-geral)
2.  [Arquitetura do Sistema](#2-arquitetura-do-sistema)
3.  [Catálogo de Agentes-Base](#3-catálogo-de-agentes-base)
4.  [Pipeline de Operação e Jornada do Cliente](#4-pipeline-de-operação-e-jornada-do-cliente)
5.  [Stack Tecnológica Conceitual](#5-stack-tecnológica-conceitual)
6.  [Princípios de Governança](#6-princípios-de-governança)
7.  [Posicionamento Estratégico](#7-posicionamento-estratégico)
8.  [Documentação Completa](#8-documentação-completa)

---

## 1. Visão Geral

O Ginkgo Source é a plataforma operacional central da Ginkgo AI Systems. Ele transforma demandas empresariais em soluções operacionais concretas, atuando como um **sistema operacional de agentes** onde cada agente é um módulo inteligente com identidade, memória, skills, ferramentas, permissões e telemetria.

**Missão Computacional:** Converter uma intenção humana imperfeita em uma solução estruturada, rastreável, modular e implantável.

**O que o Ginkgo Source entrega:**

| Linha de Produto | Descrição | Exemplos |
|---|---|---|
| **Soluções Prontas** | Pacotes padronizados com implantação rápida. | Atendimento IA, Social Media IA, Gestão/Ops IA, Landing Pages, Dashboards. |
| **Soluções Híbridas** | Base pronta com adaptações por nicho, canal ou processo. | Pacote de Atendimento IA com integração CRM e voz. |
| **Soluções Personalizadas** | Projetos criados sob demanda para necessidades únicas. | Agentes exclusivos, workflows complexos, apps próprios, portais internos. |

---

## 2. Arquitetura do Sistema

O Ginkgo Source opera como um **pipeline de transformação** de demanda, seguindo princípios de arquitetura que garantem escalabilidade, auditabilidade e reuso.

```text
[Canais de Entrada]
  ├─ Site / Landing Page
  ├─ Formulário Inteligente
  ├─ WhatsApp / Chat
  ├─ API / Dashboard Interno
        ↓
[Camada de Entrada] -> Captura e normaliza pedidos
        ↓
[Camada de Diagnóstico] -> Transforma demanda em problema compreensível
        ↓
[Camada de Roteamento] -> Despacha para agentes, define ordem de execução
        ↓
[Camada de Agentes] -> Execução especializada (Intake, Discovery, Architect, Builders, QA, Success)
        ↓
[Camada de Base de Ativos] -> Memória operacional reutilizável (prompts, templates, workflows)
        ↓
[Camada de Execução] -> Geração de artefatos (workflows, frontends, conteúdo)
        ↓
[Camada de Validação] -> Controle de qualidade (coerência, completude, segurança)
        ↓
[Camada de Implantação] -> Ativação da solução e continuidade operacional
```

**Princípios de Arquitetura:**

1.  **Separação entre Pensar, Decidir e Executar:** O sistema não concentra tudo em um único agente, reduzindo alucinação operacional e aumentando o reuso.
2.  **O Router Não é Executor:** O router central classifica, prioriza, delega e consolida, mas não executa tarefas complexas.
3.  **Toda Tarefa Produz Artefato:** Cada etapa gera uma saída objetiva (briefing, escopo, plano técnico, workflow, layout, etc.).
4.  **Reuso é Prioridade:** O sistema busca reutilizar templates, prompts, blocos lógicos e integrações antes de criar do zero.
5.  **Toda Solução Classificável:** Cada entrega se encaixa em uma taxonomia clara para facilitar automação futura e análise.

---

## 3. Catálogo de Agentes-Base do Ginkgo Source

Cada agente possui uma função única, entradas definidas, ferramentas autorizadas e formato de saída esperado.

| Agente | Função | Entradas Típicas | Saídas Típicas |
|---|---|---|---|
| **Source Intake** | Normaliza entrada e prepara triagem. | Pedido bruto (texto, formulário, mensagem). | Demanda estruturada. |
| **Source Discovery** | Refina o problema real, reduz ambiguidade. | Demanda estruturada. | Briefing técnico-comercial. |
| **Source Architect** | Desenha a solução macro e define a composição. | Briefing, histórico, ativos reutilizáveis. | Arquitetura proposta, módulos, plano de implementação. |
| **Source Builder Flow** | Constrói lógica operacional e automações. | Especificação de fluxo, blueprint executável. | Workflow funcional, integrações, regras. |
| **Source Builder Interface** | Produz interfaces de uso (front-end). | Arquitetura de interface, estrutura de telas. | Landing pages, dashboards, portais, apps leves. |
| **Source Content** | Cria ativos de comunicação relacionados à solução. | Briefing de comunicação, contexto da solução. | Copy, roteiros, posts, criativos. |
| **Source QA** | Audita consistência, clareza e segurança da solução. | Artefatos de execução, briefing, políticas. | Aprovação/reprovação com ajustes. |
| **Source Success** | Fecha o ciclo operacional, garante continuidade e expansão. | Solução implantada, feedback do cliente. | Plano de continuidade, recomendações de expansão. |

**Contrato Operacional dos Agentes:** Cada agente deve aderir a um contrato explícito que define seu propósito, inputs aceitos, ações proibidas, ferramentas permitidas, schema de output esperado, critérios de sucesso, condições de falha e regras de escalonamento.

---

## 4. Pipeline de Operação e Jornada do Cliente

O Ginkgo Source guia o cliente através de uma jornada estruturada, desde a captação da demanda até a expansão da solução.

1.  **Entrada:** Cliente chega via landing page, formulário, WhatsApp, chat, etc.
2.  **Leitura da Demanda:** O sistema identifica tipo de problema, urgência, complexidade e categoria de solução.
3.  **Diagnóstico:** A demanda é convertida em um briefing claro e objetivo.
4.  **Roteamento:** O router central escolhe os agentes especialistas que atuarão na demanda.
5.  **Produção:** Agentes constroem a proposta, escopo, workflow, interface, conteúdo e documentação.
6.  **Validação:** O Agente QA revisa consistência, clareza e viabilidade da solução.
7.  **Implantação:** A solução é ativada, documentada e entregue ao cliente.
8.  **Expansão:** O cliente recebe melhorias, upgrades e novos módulos, garantindo retenção e upsell.

**Estados do Sistema:** Todo pedido possui estados explícitos (`captured`, `diagnosing`, `in_execution`, `deployed`, etc.) para auditoria, dashboards e automação interna.

---

## 5. Stack Tecnológica Conceitual

Embora o manual seja agnóstico a ferramentas específicas, a lógica operacional sugere a seguinte stack conceitual:

| Camada | Componentes Conceituais | Ferramentas Chave (Exemplos) |
|---|---|---|
| **Orquestração** | Router, fila de tarefas, agentes especializados. | OpenClaw, BullMQ, n8n. |
| **Execução** | Runtime de agentes, automações, construtor de interface, geração de conteúdo. | Claude Code, Fastify/Node.js, MoviePy, React/Next.js. |
| **Memória** | Histórico de clientes, projetos, preferências, ativos. | Supabase (Postgres), Redis, Supabase Vector/Qdrant. |
| **Entrega** | Dashboard, portal do cliente, documentação, suporte. | Next.js, Chatwoot, Supabase Storage. |

---

## 6. Princípios de Governança

**Regras de Governança:**

-   **Toda tarefa:** Deve ter objetivo, contexto, limite, saída esperada e status.
-   **Todo agente:** Deve ter função única, entradas definidas, ferramentas permitidas, formato de saída, critérios de falha e escalonamento.
-   **Toda entrega:** Deve passar por revisão lógica, comercial, técnica e validação final.

**Metas Operacionais (Estágios de Evolução):**

1.  **Estágio 1 (Agência Assistida por IA):** Você supervisiona a maior parte das operações.
2.  **Estágio 2 (Agência Operada por IA com Revisão Humana):** Agentes executam 70-80% das tarefas, com sua revisão estratégica.
3.  **Estágio 3 (Agência Semi-Autônoma):** Você atua como diretor de estratégia e validação, com alta autonomia dos agentes.

---

## 7. Posicionamento Estratégico

O Ginkgo Source não é apenas uma agência, um SaaS ou um chatbot. É um **sistema operacional de criação e entrega de soluções digitais com IA e automação**.

**Frases-Mãe de Posicionamento:**

-   "Onde sua necessidade vira sistema."
-   "O núcleo onde soluções nascem."
-   "Da demanda à operação."
-   "Entre a ideia e a implantação, existe o Source.""
-   "Você pede. O Source estrutura. A Ginkgo entrega."

---

## 8. Documentação Completa

Para uma visão aprofundada de todos os componentes, arquitetura e guias de implementação, consulte o [Índice da Documentação Completa](docs/INDEX.md).

---

*Ginkgo AI Systems — Ginkgo Source README v1.0.0 — Abril 2026*
