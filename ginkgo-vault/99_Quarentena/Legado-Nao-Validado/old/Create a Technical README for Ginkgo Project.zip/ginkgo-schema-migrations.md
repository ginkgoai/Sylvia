# Ginkgo — Schema por Lotes de Migração
## Migrations organizadas por domínio e ordem de execução

> **Versão:** 1.0.0 | **Data:** Março 2026  
> Execute na ordem dos lotes. Nunca pule um lote.

---

## Ordem de execução

```
Lote 0 → Extensions e enums (pré-requisito)
Lote 1 → Platform Core (tenants, users, planos)
Lote 2 → Leaf (canais, contatos, conversas, mensagens)
Lote 3 → RAG (fontes, assets, chunks, embeddings)
Lote 4 → Agents e Skills (agentes, tools, prompts, skills)
Lote 5 → Observabilidade e metering
Lote 6 → Billing e Stripe
Lote 7 → Integrações e OAuth
Lote 8 → Marketplace (schema preparatório — sem lógica ainda)
```

---

## LOTE 0 — Extensions e Setup

```sql
-- 000_extensions.sql

-- pgvector para embeddings
CREATE EXTENSION IF NOT EXISTS vector;

-- pgcrypto para criptografia de tokens
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- uuid para geração de IDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- full-text search em português
-- (habilitar para busca híbrida no RAG)
```

---

## LOTE 1 — Platform Core

```sql
-- 001_platform_core.sql

-- ─────────────────────────────────────────────────
-- TENANTS
-- ─────────────────────────────────────────────────
CREATE TABLE tenants (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            TEXT NOT NULL,
  slug            TEXT UNIQUE,                    -- URL-friendly identifier
  plan            TEXT NOT NULL DEFAULT 'basico', -- basico | avancado | futurista
  status          TEXT NOT NULL DEFAULT 'active', -- active | suspended | churned | trialing
  timezone        TEXT DEFAULT 'America/Sao_Paulo',
  language        TEXT DEFAULT 'pt-BR',
  config_json     JSONB DEFAULT '{}',             -- branding, preferences
  created_at      TIMESTAMPTZ DEFAULT now(),
  updated_at      TIMESTAMPTZ DEFAULT now()
);

-- ─────────────────────────────────────────────────
-- PROFILES (usuários dentro de um tenant)
-- ─────────────────────────────────────────────────
CREATE TABLE profiles (
  id              UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  role            TEXT NOT NULL DEFAULT 'operator', -- owner | admin | operator | viewer
  name            TEXT,
  email           TEXT,
  avatar_url      TEXT,
  metadata_json   JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT now()
);

-- ─────────────────────────────────────────────────
-- MEMBERSHIPS (user → tenant, suporte a multi-tenant futuro)
-- ─────────────────────────────────────────────────
CREATE TABLE memberships (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  profile_id      UUID REFERENCES profiles(id) ON DELETE CASCADE,
  role            TEXT NOT NULL DEFAULT 'operator',
  invited_by      UUID REFERENCES profiles(id),
  accepted_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE(tenant_id, profile_id)
);

-- ─────────────────────────────────────────────────
-- PLAN LIMITS
-- ─────────────────────────────────────────────────
CREATE TABLE plan_limits (
  plan                  TEXT PRIMARY KEY,
  max_messages_mo       INTEGER,
  max_documents         INTEGER,
  max_agents            INTEGER,
  max_channels          INTEGER,
  max_members           INTEGER DEFAULT 3,
  rag_enabled           BOOLEAN DEFAULT false,
  sql_agent_enabled     BOOLEAN DEFAULT false,
  skills_enabled        BOOLEAN DEFAULT false,
  marketplace_enabled   BOOLEAN DEFAULT false,
  token_included        BIGINT DEFAULT 0          -- tokens incluídos no plano
);

-- Seed dos planos
INSERT INTO plan_limits VALUES
  ('basico',    500,   50,  1, 2, 2, false, false, false, false, 600000),
  ('avancado',  2000,  200, 3, 4, 5, true,  true,  true,  false, 2400000),
  ('futurista', 99999, 500, 4, 8, 20, true, true,  true,  true,  10000000);

-- ─────────────────────────────────────────────────
-- AUDIT LOGS
-- ─────────────────────────────────────────────────
CREATE TABLE audit_logs (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  actor_id        UUID,                           -- profile_id ou system
  event_type      TEXT NOT NULL,
  resource_type   TEXT,
  resource_id     UUID,
  payload_json    JSONB DEFAULT '{}',
  ip_address      INET,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_audit_tenant ON audit_logs(tenant_id, created_at DESC);
```

---

## LOTE 2 — Leaf (Atendimento)

```sql
-- 002_leaf.sql

-- ─────────────────────────────────────────────────
-- CHANNELS
-- ─────────────────────────────────────────────────
CREATE TABLE channels (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  type            TEXT NOT NULL,   -- whatsapp | telegram | webchat | email | instagram
  name            TEXT,
  config_json     JSONB DEFAULT '{}',  -- instance_name, token, webhook_url, etc
  status          TEXT DEFAULT 'active',  -- active | disconnected | error
  connected_at    TIMESTAMPTZ,
  last_seen_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_channels_tenant ON channels(tenant_id, type);

-- ─────────────────────────────────────────────────
-- CONTACTS
-- ─────────────────────────────────────────────────
CREATE TABLE contacts (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  external_id     TEXT,                          -- ID no WhatsApp, CRM externo, etc
  name            TEXT,
  phone           TEXT,
  email           TEXT,
  avatar_url      TEXT,
  tags            TEXT[] DEFAULT '{}',
  metadata_json   JSONB DEFAULT '{}',
  first_seen_at   TIMESTAMPTZ DEFAULT now(),
  last_seen_at    TIMESTAMPTZ DEFAULT now(),
  created_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE(tenant_id, phone)
);

CREATE INDEX idx_contacts_tenant ON contacts(tenant_id);
CREATE INDEX idx_contacts_phone ON contacts(tenant_id, phone);
CREATE INDEX idx_contacts_tags ON contacts USING GIN(tags);

-- ─────────────────────────────────────────────────
-- CONVERSATIONS
-- ─────────────────────────────────────────────────
CREATE TABLE conversations (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id),
  channel_id      UUID REFERENCES channels(id),
  assigned_agent  TEXT DEFAULT 'brann',  -- brann | alfred | nyra | command | human
  status          TEXT DEFAULT 'open',   -- open | handoff | closed | waiting
  handoff_reason  TEXT,
  opened_at       TIMESTAMPTZ DEFAULT now(),
  closed_at       TIMESTAMPTZ,
  metadata_json   JSONB DEFAULT '{}'
);

CREATE INDEX idx_conv_tenant ON conversations(tenant_id, status);
CREATE INDEX idx_conv_contact ON conversations(contact_id);

-- ─────────────────────────────────────────────────
-- MESSAGES
-- ─────────────────────────────────────────────────
CREATE TABLE messages (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
  sender_type     TEXT NOT NULL,  -- user | agent | human | system
  sender_id       TEXT,           -- contact.id ou profile.id ou agent name
  content         TEXT,
  content_type    TEXT DEFAULT 'text',  -- text | audio | image | document
  media_url       TEXT,
  metadata_json   JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_messages_conv ON messages(conversation_id, created_at ASC);
CREATE INDEX idx_messages_tenant ON messages(tenant_id, created_at DESC);

-- ─────────────────────────────────────────────────
-- LEAD SCORES
-- ─────────────────────────────────────────────────
CREATE TABLE lead_scores (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id) ON DELETE CASCADE UNIQUE,
  score           INTEGER DEFAULT 0,
  tier            TEXT DEFAULT 'cold',  -- hot (>=70) | warm (40-69) | cold (<40)
  reason_json     JSONB DEFAULT '{}',
  updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_scores_tenant ON lead_scores(tenant_id, score DESC);

-- ─────────────────────────────────────────────────
-- APPOINTMENTS
-- ─────────────────────────────────────────────────
CREATE TABLE appointments (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id      UUID REFERENCES contacts(id),
  conversation_id UUID REFERENCES conversations(id),
  datetime        TIMESTAMPTZ NOT NULL,
  duration_min    INTEGER DEFAULT 30,
  status          TEXT DEFAULT 'scheduled',  -- scheduled | confirmed | cancelled | completed
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_appt_tenant ON appointments(tenant_id, datetime);
```

---

## LOTE 3 — RAG (Base de Conhecimento)

```sql
-- 003_rag.sql

-- ─────────────────────────────────────────────────
-- KNOWLEDGE SOURCES (configuração da fonte)
-- ─────────────────────────────────────────────────
CREATE TABLE knowledge_sources (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  type            TEXT NOT NULL,  -- upload | google_drive | url | notion | integration
  name            TEXT,
  config_json     JSONB DEFAULT '{}',  -- credentials, folder_id, url, etc
  sync_enabled    BOOLEAN DEFAULT false,
  sync_frequency  TEXT DEFAULT 'manual',  -- manual | daily | weekly
  last_sync_at    TIMESTAMPTZ,
  status          TEXT DEFAULT 'active',
  created_at      TIMESTAMPTZ DEFAULT now()
);

-- ─────────────────────────────────────────────────
-- KNOWLEDGE ASSETS (arquivo/documento bruto)
-- ─────────────────────────────────────────────────
CREATE TABLE knowledge_assets (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  source_id       UUID REFERENCES knowledge_sources(id),
  type            TEXT NOT NULL,  -- pdf | docx | txt | md | url | audio | image | spreadsheet
  title           TEXT,
  file_url        TEXT,           -- Supabase Storage path
  file_size_bytes INTEGER,
  language        TEXT DEFAULT 'pt',
  tags            TEXT[] DEFAULT '{}',
  sensitivity     TEXT DEFAULT 'internal',  -- public | internal | confidential
  status          TEXT DEFAULT 'pending',   -- pending | extracting | chunking | indexed | error
  error_message   TEXT,
  version         INTEGER DEFAULT 1,
  metadata_json   JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT now(),
  indexed_at      TIMESTAMPTZ
);

CREATE INDEX idx_assets_tenant ON knowledge_assets(tenant_id, status);
CREATE INDEX idx_assets_tags ON knowledge_assets USING GIN(tags);

-- ─────────────────────────────────────────────────
-- KNOWLEDGE CHUNKS
-- ─────────────────────────────────────────────────
CREATE TABLE knowledge_chunks (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  asset_id        UUID REFERENCES knowledge_assets(id) ON DELETE CASCADE,
  chunk_index     INTEGER,
  total_chunks    INTEGER,
  chunk_text      TEXT NOT NULL,
  embedding       VECTOR(1536),
  tokens          INTEGER,
  metadata_json   JSONB DEFAULT '{}',  -- section, page, source, title, language
  access_roles    TEXT[] DEFAULT '{}', -- roles que podem acessar este chunk
  created_at      TIMESTAMPTZ DEFAULT now()
);

-- Índice HNSW para busca vetorial rápida
CREATE INDEX idx_chunks_embedding ON knowledge_chunks
  USING hnsw (embedding vector_cosine_ops)
  WITH (m = 16, ef_construction = 64);

-- Índice full-text para busca híbrida
CREATE INDEX idx_chunks_fts ON knowledge_chunks
  USING GIN (to_tsvector('portuguese', chunk_text));

CREATE INDEX idx_chunks_tenant ON knowledge_chunks(tenant_id);

-- ─────────────────────────────────────────────────
-- KNOWLEDGE SUMMARIES (resumos macro de documentos)
-- ─────────────────────────────────────────────────
CREATE TABLE knowledge_summaries (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  asset_id        UUID REFERENCES knowledge_assets(id) ON DELETE CASCADE,
  summary_text    TEXT,
  key_topics      TEXT[],
  created_at      TIMESTAMPTZ DEFAULT now()
);

-- ─────────────────────────────────────────────────
-- RETRIEVAL LOGS
-- ─────────────────────────────────────────────────
CREATE TABLE retrieval_logs (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  agent           TEXT,
  query_text      TEXT,
  query_embedding VECTOR(1536),
  top_chunks      JSONB,          -- [{chunk_id, score, text_preview}]
  score_avg       FLOAT,
  chunks_returned INTEGER,
  used_in_msg_id  UUID REFERENCES messages(id),
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_retrieval_tenant ON retrieval_logs(tenant_id, created_at DESC);

-- ─────────────────────────────────────────────────
-- INGESTION JOBS (controle do pipeline)
-- ─────────────────────────────────────────────────
CREATE TABLE ingestion_jobs (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  asset_id        UUID REFERENCES knowledge_assets(id),
  status          TEXT DEFAULT 'queued',  -- queued | running | completed | failed
  stage           TEXT,                   -- extract | normalize | chunk | embed | index
  attempts        INTEGER DEFAULT 0,
  max_attempts    INTEGER DEFAULT 3,
  error_message   TEXT,
  chunks_created  INTEGER,
  started_at      TIMESTAMPTZ,
  completed_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_jobs_status ON ingestion_jobs(status, created_at);
```

---

## LOTE 4 — Agents e Skills

```sql
-- 004_agents_skills.sql

-- ─────────────────────────────────────────────────
-- AGENTS (instâncias por tenant)
-- ─────────────────────────────────────────────────
CREATE TABLE agents (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  type            TEXT NOT NULL,   -- brann | alfred | nyra | command
  name            TEXT,            -- nome customizado pelo tenant
  enabled         BOOLEAN DEFAULT false,
  model           TEXT DEFAULT 'gpt-4o',
  temperature     FLOAT DEFAULT 0.4,
  max_tokens      INTEGER DEFAULT 800,
  config_json     JSONB DEFAULT '{}',
  tools_enabled   TEXT[] DEFAULT '{}',
  prompt_version  TEXT,
  updated_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE(tenant_id, type)
);

-- ─────────────────────────────────────────────────
-- PROMPT VERSIONS
-- ─────────────────────────────────────────────────
CREATE TABLE prompt_versions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  agent_type      TEXT NOT NULL,
  version         TEXT NOT NULL,
  content         TEXT NOT NULL,
  changelog       TEXT,
  active          BOOLEAN DEFAULT false,
  created_by      UUID REFERENCES profiles(id),
  created_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE(tenant_id, agent_type, version)
);

CREATE INDEX idx_prompts_active ON prompt_versions(tenant_id, agent_type, active);

-- ─────────────────────────────────────────────────
-- TOOL REGISTRY (catálogo global de tools)
-- ─────────────────────────────────────────────────
CREATE TABLE tool_registry (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            TEXT UNIQUE NOT NULL,
  description     TEXT,
  agents_allowed  TEXT[] DEFAULT '{}',
  input_schema    JSONB DEFAULT '{}',
  output_schema   JSONB DEFAULT '{}',
  permissions     TEXT[] DEFAULT '{}',
  timeout_ms      INTEGER DEFAULT 5000,
  retries         INTEGER DEFAULT 3,
  read_only       BOOLEAN DEFAULT true,
  enabled         BOOLEAN DEFAULT true,
  created_at      TIMESTAMPTZ DEFAULT now()
);

-- ─────────────────────────────────────────────────
-- TOOL EXECUTIONS (log de toda execução de tool)
-- ─────────────────────────────────────────────────
CREATE TABLE tool_executions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  agent_type      TEXT,
  tool_name       TEXT,
  conversation_id UUID REFERENCES conversations(id),
  input_json      JSONB DEFAULT '{}',
  output_json     JSONB DEFAULT '{}',
  success         BOOLEAN,
  latency_ms      INTEGER,
  tokens_used     INTEGER DEFAULT 0,
  error_message   TEXT,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_tool_exec_tenant ON tool_executions(tenant_id, created_at DESC);
CREATE INDEX idx_tool_exec_name ON tool_executions(tenant_id, tool_name);

-- ─────────────────────────────────────────────────
-- SKILLS REGISTRY (catálogo global de skills)
-- ─────────────────────────────────────────────────
CREATE TABLE skills (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug            TEXT UNIQUE NOT NULL,  -- 'shopify-analytics-pro'
  name            TEXT NOT NULL,
  description     TEXT,
  category        TEXT,          -- ecommerce | marketing | ops | content | custom
  author          TEXT,          -- 'ginkgo' | 'community'
  version         TEXT DEFAULT '1.0.0',
  manifest_json   JSONB NOT NULL,
  status          TEXT DEFAULT 'draft',  -- draft | review | published | deprecated
  official        BOOLEAN DEFAULT false,
  requires_plan   TEXT DEFAULT 'avancado',
  price_brl       NUMERIC DEFAULT 0,
  trial_days      INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT now(),
  published_at    TIMESTAMPTZ
);

-- ─────────────────────────────────────────────────
-- TENANT SKILLS (skills instaladas por tenant)
-- ─────────────────────────────────────────────────
CREATE TABLE tenant_skills (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  skill_id        UUID REFERENCES skills(id),
  status          TEXT DEFAULT 'active',  -- active | suspended | trial | expired
  config_json     JSONB DEFAULT '{}',
  installed_at    TIMESTAMPTZ DEFAULT now(),
  expires_at      TIMESTAMPTZ,
  UNIQUE(tenant_id, skill_id)
);

-- ─────────────────────────────────────────────────
-- SKILL USAGE EVENTS
-- ─────────────────────────────────────────────────
CREATE TABLE skill_usage_events (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  skill_id        UUID REFERENCES skills(id),
  event_type      TEXT,
  tokens_used     INTEGER DEFAULT 0,
  metadata_json   JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_skill_usage ON skill_usage_events(tenant_id, skill_id, created_at DESC);
```

---

## LOTE 5 — Observabilidade e Metering

```sql
-- 005_observability.sql

-- ─────────────────────────────────────────────────
-- INCIDENTS
-- ─────────────────────────────────────────────────
CREATE TABLE incidents (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  severity        TEXT DEFAULT 'low',   -- low | medium | high | critical
  category        TEXT,                 -- agent_error | tool_failure | rag_miss | billing | integration
  description     TEXT NOT NULL,
  workflow        TEXT,
  agent           TEXT,
  resolved        BOOLEAN DEFAULT false,
  resolved_at     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_incidents_open ON incidents(tenant_id, resolved, created_at DESC);

-- ─────────────────────────────────────────────────
-- USAGE EVENTS (granular — base do metering)
-- ─────────────────────────────────────────────────
CREATE TABLE usage_events (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  event_type      TEXT NOT NULL,   -- message | token | document | tool_call | handoff | skill_run
  quantity        BIGINT DEFAULT 1,
  unit            TEXT DEFAULT 'count',  -- count | token | byte | second
  agent           TEXT,
  skill_id        UUID REFERENCES skills(id),
  metadata_json   JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_usage_tenant ON usage_events(tenant_id, event_type, created_at DESC);
CREATE INDEX idx_usage_period ON usage_events(tenant_id, created_at);

-- ─────────────────────────────────────────────────
-- METERING SUMMARIES (agregados por período — evita full scan)
-- ─────────────────────────────────────────────────
CREATE TABLE metering_summaries (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  period          TEXT NOT NULL,        -- YYYY-MM
  messages_count  INTEGER DEFAULT 0,
  tokens_used     BIGINT DEFAULT 0,
  documents_count INTEGER DEFAULT 0,
  tool_calls      INTEGER DEFAULT 0,
  handoffs        INTEGER DEFAULT 0,
  cost_usd        NUMERIC DEFAULT 0,
  updated_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE(tenant_id, period)
);

-- Views para dashboard
CREATE VIEW vw_daily_activity AS
SELECT
  DATE(created_at) AS dia,
  tenant_id,
  COUNT(*) FILTER (WHERE sender_type = 'user')  AS msgs_user,
  COUNT(*) FILTER (WHERE sender_type = 'agent') AS msgs_agent
FROM messages
WHERE created_at >= now() - interval '30 days'
GROUP BY 1, 2
ORDER BY 1 DESC;

CREATE VIEW vw_hot_leads AS
SELECT
  c.id, c.name, c.phone, c.tags,
  ls.score, ls.tier, ls.updated_at
FROM contacts c
JOIN lead_scores ls ON ls.contact_id = c.id
WHERE ls.score >= 70
ORDER BY ls.score DESC;

CREATE VIEW vw_handoff_rate AS
SELECT
  tenant_id,
  COUNT(*)                                              AS total,
  COUNT(*) FILTER (WHERE status = 'handoff')           AS handoffs,
  ROUND(COUNT(*) FILTER (WHERE status = 'handoff') * 100.0 / NULLIF(COUNT(*),0), 1) AS pct
FROM conversations
WHERE opened_at >= now() - interval '30 days'
GROUP BY tenant_id;
```

---

## LOTE 6 — Billing e Stripe

```sql
-- 006_billing.sql

-- ─────────────────────────────────────────────────
-- SUBSCRIPTIONS
-- ─────────────────────────────────────────────────
CREATE TABLE subscriptions (
  id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id               UUID REFERENCES tenants(id) ON DELETE CASCADE UNIQUE,
  stripe_customer_id      TEXT UNIQUE,
  stripe_subscription_id  TEXT UNIQUE,
  plan                    TEXT NOT NULL,
  status                  TEXT DEFAULT 'trialing', -- trialing | active | past_due | canceled | unpaid
  trial_ends_at           TIMESTAMPTZ,
  current_period_start    TIMESTAMPTZ,
  current_period_end      TIMESTAMPTZ,
  cancel_at               TIMESTAMPTZ,
  canceled_at             TIMESTAMPTZ,
  created_at              TIMESTAMPTZ DEFAULT now(),
  updated_at              TIMESTAMPTZ DEFAULT now()
);

-- ─────────────────────────────────────────────────
-- TOKEN BALANCES (saldo atual por tenant)
-- ─────────────────────────────────────────────────
CREATE TABLE token_balances (
  tenant_id       UUID PRIMARY KEY REFERENCES tenants(id) ON DELETE CASCADE,
  balance         BIGINT DEFAULT 0,         -- tokens disponíveis agora
  used_period     BIGINT DEFAULT 0,         -- tokens usados no período atual
  refill_at       TIMESTAMPTZ,              -- próxima recarga pelo plano
  updated_at      TIMESTAMPTZ DEFAULT now()
);

-- ─────────────────────────────────────────────────
-- TOKEN TRANSACTIONS (histórico completo)
-- ─────────────────────────────────────────────────
CREATE TABLE token_transactions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  type            TEXT NOT NULL,    -- purchase | plan_refill | consumption | bonus | refund | expiry
  amount          BIGINT NOT NULL,  -- positivo = crédito | negativo = débito
  balance_after   BIGINT,
  source_type     TEXT,             -- stripe_payment | tool_execution | plan_renewal
  source_id       TEXT,             -- stripe payment_intent id ou tool_execution id
  description     TEXT,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_token_txn_tenant ON token_transactions(tenant_id, created_at DESC);

-- ─────────────────────────────────────────────────
-- INVOICES
-- ─────────────────────────────────────────────────
CREATE TABLE invoices (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID REFERENCES tenants(id) ON DELETE CASCADE,
  stripe_invoice_id   TEXT UNIQUE,
  amount_brl          NUMERIC,
  period              TEXT,         -- YYYY-MM
  status              TEXT,         -- draft | open | paid | void | uncollectible
  pdf_url             TEXT,
  issued_at           TIMESTAMPTZ,
  paid_at             TIMESTAMPTZ,
  created_at          TIMESTAMPTZ DEFAULT now()
);

-- ─────────────────────────────────────────────────
-- SKILL REVENUE SHARE (marketplace fase 5)
-- ─────────────────────────────────────────────────
CREATE TABLE skill_revenue_share (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id        UUID REFERENCES skills(id),
  tenant_id       UUID REFERENCES tenants(id),
  period          TEXT,
  gross_brl       NUMERIC,
  developer_pct   FLOAT DEFAULT 0.70,
  platform_pct    FLOAT DEFAULT 0.30,
  developer_brl   NUMERIC,
  platform_brl    NUMERIC,
  stripe_transfer_id TEXT,
  status          TEXT DEFAULT 'pending',  -- pending | paid | failed
  created_at      TIMESTAMPTZ DEFAULT now()
);
```

---

## LOTE 7 — Integrações e OAuth

```sql
-- 007_integrations.sql

-- ─────────────────────────────────────────────────
-- INTEGRATIONS (tokens OAuth por provider)
-- ─────────────────────────────────────────────────
CREATE TABLE integrations (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID REFERENCES tenants(id) ON DELETE CASCADE,
  provider            TEXT NOT NULL,  -- google | meta | shopify | shopee | clickup | evolution | openclaw
  status              TEXT DEFAULT 'connected',  -- connected | expired | error | disconnected
  -- tokens criptografados com pgcrypto
  access_token_enc    TEXT,  -- pgp_sym_encrypt(token, key)
  refresh_token_enc   TEXT,
  token_expires_at    TIMESTAMPTZ,
  scopes              TEXT[],
  metadata_json       JSONB DEFAULT '{}',  -- page_id, ig_account_id, location_id, shop_domain
  connected_at        TIMESTAMPTZ DEFAULT now(),
  last_sync_at        TIMESTAMPTZ,
  UNIQUE(tenant_id, provider)
);

-- ─────────────────────────────────────────────────
-- META METRICS (dados puxados da Meta Graph API)
-- ─────────────────────────────────────────────────
CREATE TABLE meta_metrics (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  date            DATE NOT NULL,
  account_type    TEXT,   -- instagram | facebook_page
  account_id      TEXT,
  impressions     INTEGER DEFAULT 0,
  reach           INTEGER DEFAULT 0,
  profile_views   INTEGER DEFAULT 0,
  messages_in     INTEGER DEFAULT 0,
  messages_out    INTEGER DEFAULT 0,
  top_posts       JSONB DEFAULT '[]',
  raw_json        JSONB DEFAULT '{}',
  synced_at       TIMESTAMPTZ DEFAULT now(),
  UNIQUE(tenant_id, date, account_id)
);

CREATE INDEX idx_meta_tenant ON meta_metrics(tenant_id, date DESC);

-- ─────────────────────────────────────────────────
-- GMB METRICS (Google My Business)
-- ─────────────────────────────────────────────────
CREATE TABLE gmb_metrics (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id) ON DELETE CASCADE,
  date            DATE NOT NULL,
  location_id     TEXT,
  views_maps      INTEGER DEFAULT 0,
  views_search    INTEGER DEFAULT 0,
  clicks_call     INTEGER DEFAULT 0,
  clicks_website  INTEGER DEFAULT 0,
  clicks_directions INTEGER DEFAULT 0,
  rating_avg      FLOAT,
  review_count    INTEGER DEFAULT 0,
  new_reviews     JSONB DEFAULT '[]',
  synced_at       TIMESTAMPTZ DEFAULT now(),
  UNIQUE(tenant_id, date, location_id)
);

CREATE INDEX idx_gmb_tenant ON gmb_metrics(tenant_id, date DESC);
```

---

## LOTE 8 — Marketplace (Schema preparatório)

```sql
-- 008_marketplace.sql
-- ATENÇÃO: Este lote cria apenas o schema.
-- Nenhuma lógica de negócio é implementada aqui.
-- Marketplace é fase 4-5 da plataforma.

-- ─────────────────────────────────────────────────
-- SKILL VERSIONS
-- ─────────────────────────────────────────────────
CREATE TABLE skill_versions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id        UUID REFERENCES skills(id) ON DELETE CASCADE,
  version         TEXT NOT NULL,
  changelog       TEXT,
  manifest_json   JSONB NOT NULL,
  published_at    TIMESTAMPTZ,
  deprecated_at   TIMESTAMPTZ,
  UNIQUE(skill_id, version)
);

-- ─────────────────────────────────────────────────
-- SKILL PERMISSIONS (declaradas no manifest)
-- ─────────────────────────────────────────────────
CREATE TABLE skill_permissions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id        UUID REFERENCES skills(id) ON DELETE CASCADE,
  permission      TEXT NOT NULL,  -- 'orders.read', 'reports.write', etc
  required        BOOLEAN DEFAULT true,
  description     TEXT
);

-- ─────────────────────────────────────────────────
-- SKILL REVIEWS (futuro — avaliações da comunidade)
-- ─────────────────────────────────────────────────
CREATE TABLE skill_reviews (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id        UUID REFERENCES skills(id),
  tenant_id       UUID REFERENCES tenants(id),
  rating          INTEGER CHECK (rating BETWEEN 1 AND 5),
  comment         TEXT,
  created_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE(skill_id, tenant_id)
);
```

---

## RLS Policies

```sql
-- 009_rls.sql
-- Row Level Security para isolamento multi-tenant

-- Habilitar RLS nas tabelas sensíveis
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_chunks ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE token_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE token_transactions ENABLE ROW LEVEL SECURITY;

-- Política base: tenant isolado via função helper
CREATE OR REPLACE FUNCTION current_tenant_id()
RETURNS UUID AS $$
  SELECT (current_setting('app.tenant_id', true))::UUID;
$$ LANGUAGE sql STABLE;

-- Exemplo de policy (aplicar em todas as tabelas com tenant_id)
CREATE POLICY tenant_isolation ON contacts
  USING (tenant_id = current_tenant_id());

-- NOTA: O service_role do Supabase ignora RLS por padrão.
-- Workers e API usam service_role com tenant_id explícito em toda query.
-- Frontend usa anon key com RLS ativo via JWT claim.
```

---

## Seed do Tenant Zero

```sql
-- seed/tenant_zero.sql

INSERT INTO tenants (id, name, slug, plan, status, timezone, language, config_json)
VALUES (
  'f47ac10b-58cc-4372-a567-000000000000',
  'Ginkgo AI Systems (Interno)',
  'ginkgo-internal',
  'futurista',
  'active',
  'America/Sao_Paulo',
  'pt-BR',
  '{"branding":{"tone":"consultivo","persona":"técnico mas acessível"}}'
);

-- Token balance inicial do Tenant Zero
INSERT INTO token_balances (tenant_id, balance)
VALUES ('f47ac10b-58cc-4372-a567-000000000000', 10000000);

-- Agente Brann ativo
INSERT INTO agents (tenant_id, type, enabled, model, temperature, max_tokens, config_json, tools_enabled, prompt_version)
VALUES (
  'f47ac10b-58cc-4372-a567-000000000000',
  'brann', true,
  'gpt-4o', 0.4, 800,
  '{"max_context_messages":12,"rag_top_k":5,"typing_indicator":true,"handoff_threshold_score":70}',
  ARRAY['search_knowledge','create_lead','update_contact','handoff_human','fetch_catalog','schedule_appointment'],
  'brann-t0-v1.0'
);

-- Canal WhatsApp
INSERT INTO channels (tenant_id, type, name, config_json, status)
VALUES (
  'f47ac10b-58cc-4372-a567-000000000000',
  'whatsapp',
  'WhatsApp Principal',
  '{"evolution_instance":"ginkgo-zero","webhook_url":"https://n8n.ginkgosystems.tech/webhook/whatsapp-t0","typing_delay_ms":1200}',
  'active'
);

-- Skills oficiais da Ginkgo (publicadas como internas)
INSERT INTO skills (slug, name, category, author, official, requires_plan, price_brl, status)
VALUES
  ('leaf-core',    'Leaf Core',    'atendimento', 'ginkgo', true, 'basico',    0,  'published'),
  ('wave-ops',     'Wave Ops',     'operacao',    'ginkgo', true, 'avancado',  0,  'published'),
  ('pyre-content', 'Pyre Content', 'conteudo',    'ginkgo', true, 'avancado',  0,  'published'),
  ('command-ai',   'Command AI',   'assistente',  'ginkgo', true, 'futurista', 0,  'published');
```

---

## check-schema.sql

```sql
-- Validação pós-migration
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name IN (
    'tenants','profiles','memberships','plan_limits','audit_logs',
    'channels','contacts','conversations','messages','lead_scores','appointments',
    'knowledge_sources','knowledge_assets','knowledge_chunks','knowledge_summaries','retrieval_logs','ingestion_jobs',
    'agents','prompt_versions','tool_registry','tool_executions',
    'skills','tenant_skills','skill_usage_events',
    'incidents','usage_events','metering_summaries',
    'subscriptions','token_balances','token_transactions','invoices',
    'integrations','meta_metrics','gmb_metrics',
    'skill_versions','skill_permissions','skill_reviews'
  )
ORDER BY table_name;
-- Esperado: 37 tabelas
```

---

**Ginkgo AI Systems — Schema Migrations**  
`schema v1.0.0 — Março 2026`
