# Ginkgo Platform — Modelo de Negócio Revisado
## Base + Add-ons + Tokens

> **Versão:** 2.1.0 | **Data:** Março 2026

---

## Lógica central

```
PLATAFORMA BASE (mensalidade fixa)
  → Dashboard completo com todas as integrações conectadas
  → Observabilidade total (métricas, gráficos, KPIs)
  → Feed de notícias relevantes via Perplexity API
  → Ginkgo Office (status visual dos agentes)
  → Alertas e daily summary

ADD-ONS (mensalidade extra por módulo)
  → Brann — Atendimento WhatsApp
  → Command — Gestor via Telegram
  → Nyra — Influencer IA / Conteúdo
  → Skills específicas (por skill/mês)

TOKENS (consumo por uso)
  → Debitados a cada execução de agente
  → Plano base inclui cota mínima
  → Pacotes adicionais sob demanda
```

---

## Pricing revisado

### Plano Base — Dashboard + Observabilidade

| Plano | Preço | O que inclui |
|-------|-------|-------------|
| **Starter** | R$ 97/mês | Dashboard + 3 integrações + news feed + 50k tokens |
| **Business** | R$ 197/mês | Dashboard + integrações ilimitadas + news feed + office view + 200k tokens |
| **Scale** | R$ 397/mês | Tudo + multi-workspace + API access + 500k tokens |

### Add-ons de Agentes

| Add-on | Preço | O que faz |
|--------|-------|-----------|
| **Brann** (Atendimento) | + R$ 147/mês | WhatsApp 24h, lead capture, handoff, RAG |
| **Command** (Gestor) | + R$ 197/mês | Telegram, acesso a todos os agentes, LAPLACE routing |
| **Nyra** (Influencer IA) | + R$ 197/mês | Reels, posts, calendário, tráfego pago |
| **Alfred** (Analista) | + R$ 147/mês | SQL Agent, relatórios, extração documental |

### Add-ons de Skills

| Skill | Preço | O que faz |
|-------|-------|-----------|
| RAG Base (Knowledge) | + R$ 49/mês | Upload de docs, FAQ, busca semântica |
| Shopify Intelligence | + R$ 49/mês | Pedidos, produtos, métricas e-commerce |
| ClickUp Sync | + R$ 29/mês | Tarefas, projetos, status |
| Google Ads Manager | + R$ 79/mês | Campanhas, ROAS, otimização |
| Meta Ads Manager | + R$ 79/mês | Campanhas Facebook/Instagram |
| TikTok Ads Manager | + R$ 79/mês | Campanhas TikTok |
| Prospecção Ativa | + R$ 97/mês | Scraping + enriquecimento + CRM |

### Pacotes de Tokens

| Pacote | Tokens | Preço |
|--------|--------|-------|
| Starter | 500k | R$ 79 |
| Growth | 2M | R$ 249 |
| Scale | 10M | R$ 890 |

---

## Jornada do cliente

```
1. Cadastro grátis (7 dias trial)
   → Conecta Instagram, GMB, WhatsApp
   → Vê dashboard com seus dados reais
   → Recebe news feed personalizado
   → "UAU, já tem valor sem pagar nada"

2. Converte para Starter (R$ 97)
   → Mais integrações
   → Feed mais completo
   → Office view

3. Adiciona Brann (+ R$ 147)
   → WhatsApp começa a atender
   → Primeiro lead capturado
   → Handoff funciona
   → "Isso está pagando sozinho"

4. Adiciona Nyra (+ R$ 197)
   → Primeiro Reel gerado
   → Post agendado automaticamente
   → "Economizei horas"

5. Adiciona skills conforme necessidade
   → Shopify, ClickUp, Ads
   → Cada skill resolve uma dor específica

Ticket médio maduro: R$ 97 + R$ 147 + R$ 197 + skills = R$ 500–800/mês
```

---

## Dashboard Base — O que mostra

### Seção 1 — Overview geral
- KPIs de todos os canais conectados
- Gráfico de atividade (últimos 7/30 dias)
- Status dos agentes (office view mini)

### Seção 2 — Redes Sociais (por plataforma)
- Instagram: alcance, impressões, seguidores, posts top
- TikTok: views, shares, trending sounds
- Facebook: page insights, engajamento
- LinkedIn: impressões, cliques, crescimento
- YouTube: views, watch time, subscribers
- X/Threads: impressões, menções

### Seção 3 — Tráfego Pago
- Meta Ads: spend, CPC, ROAS, conversões
- TikTok Ads: spend, CPM, plays
- Google Ads: CPC, CPA, quality score
- Comparativo de plataformas

### Seção 4 — Negócio Local
- Google Meu Negócio: views, cliques, avaliações
- Novas avaliações (com sentiment)
- Perguntas sem resposta (alerta)

### Seção 5 — News Feed (Perplexity)
- Notícias do setor do cliente (configurável)
- Tendências de conteúdo (IA + social listening)
- Alertas de menções à marca
- Oportunidades de conteúdo
- Novidades de plataformas (Instagram, TikTok updates)
- Atualização de algoritmos

---

## News Feed — Integração Perplexity

### Como funciona

```
Worker-sync (a cada 4h):
  1. Buscar perfil do tenant (segmento, keywords, concorrentes)
  2. POST Perplexity API /chat/completions
     model: sonar-pro
     query: notícias relevantes para [segmento] nos últimos 2 dias
  3. Estruturar resultado em news_items
  4. Salvar em Supabase com tenant_id
  5. Exibir no dashboard com fonte e link

Queries geradas automaticamente por segmento:
  imobiliária  → "mercado imobiliário [cidade] tendências"
  e-commerce   → "comportamento consumidor digital brasil"
  clínica      → "saúde digital atendimento telemedicina"
  (customizável pelo tenant)
```

### Tipos de card no feed
- 📰 Notícia do setor
- 📈 Tendência de conteúdo (viral no TikTok/IG)
- ⚠️ Alerta de algoritmo (mudança no Meta/TikTok)
- 💡 Oportunidade de pauta (assunto em alta)
- 🏷️ Menção à marca (se monitoramento ativo)

### Tabela no banco

```sql
CREATE TABLE news_items (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     UUID REFERENCES tenants(id),
  type          TEXT,  -- news | trend | alert | opportunity | mention
  title         TEXT,
  summary       TEXT,
  source_url    TEXT,
  source_name   TEXT,
  relevance     FLOAT, -- 0-1, calculado pelo Perplexity
  tags          TEXT[],
  read          BOOLEAN DEFAULT false,
  saved         BOOLEAN DEFAULT false,
  fetched_at    TIMESTAMPTZ DEFAULT now()
);
```

---

## Variável de ambiente adicional

```bash
PERPLEXITY_API_KEY=     # Perplexity API (modelo sonar-pro)
```

---

*Ginkgo AI Systems — Business Model v2.1.0 — Março 2026*
