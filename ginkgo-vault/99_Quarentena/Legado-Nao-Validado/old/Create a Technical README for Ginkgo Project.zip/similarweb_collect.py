import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient
import json

client = ApiClient()

domains = [
    'clickup.com',
    'notion.so',
    'hootsuite.com',
    'hubspot.com',
    'zapier.com',
    'buffer.com',
    'manychat.com',
]

results = {}

for domain in domains:
    print(f"\n=== {domain} ===")
    data = {}

    # Global Rank
    try:
        r = client.call_api('SimilarWeb/get_global_rank', path_params={'domain': domain})
        data['global_rank'] = r
        print(f"  rank: OK")
    except Exception as e:
        data['global_rank'] = {'error': str(e)}
        print(f"  rank: ERROR {e}")

    # Visits Total
    try:
        r = client.call_api('SimilarWeb/get_visits_total',
            path_params={'domain': domain},
            query={'country': 'world', 'granularity': 'monthly', 'start_date': '2025-07', 'end_date': '2025-12'})
        data['visits_total'] = r
        print(f"  visits: OK")
    except Exception as e:
        data['visits_total'] = {'error': str(e)}
        print(f"  visits: ERROR {e}")

    # Bounce Rate
    try:
        r = client.call_api('SimilarWeb/get_bounce_rate',
            path_params={'domain': domain},
            query={'country': 'world', 'granularity': 'monthly', 'start_date': '2025-07', 'end_date': '2025-12'})
        data['bounce_rate'] = r
        print(f"  bounce: OK")
    except Exception as e:
        data['bounce_rate'] = {'error': str(e)}
        print(f"  bounce: ERROR {e}")

    # Traffic Sources Desktop
    try:
        r = client.call_api('SimilarWeb/get_traffic_sources_desktop',
            path_params={'domain': domain},
            query={'country': 'world', 'granularity': 'monthly', 'start_date': '2025-09', 'end_date': '2025-12'})
        data['traffic_sources'] = r
        print(f"  sources: OK")
    except Exception as e:
        data['traffic_sources'] = {'error': str(e)}
        print(f"  sources: ERROR {e}")

    results[domain] = data

# Save to file immediately
with open('/home/ubuntu/similarweb_data.json', 'w') as f:
    json.dump(results, f, indent=2)

print("\n\nData saved to /home/ubuntu/similarweb_data.json")
print(json.dumps(results, indent=2)[:3000])
