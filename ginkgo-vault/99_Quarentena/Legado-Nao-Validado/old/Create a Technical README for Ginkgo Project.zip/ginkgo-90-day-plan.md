# Ginkgo — Plano de 90 Dias
## Do zero ao primeiro caixa real

> **Versão:** 1.0.0 | **Data:** Março 2026  
> **Horizonte:** Semana 1 → Semana 13  
> **Meta:** 5 clientes pagantes, operação estável, base para escalar

---

## Tese do plano

Não é um plano de features. É um plano de sobrevivência inteligente.

Cada semana tem uma única pergunta dominante:

```
Semanas 1–2   → "O chão aguenta peso?"
Semanas 3–4   → "O agente funciona de verdade?"
Semanas 5–6   → "O cliente consegue entrar sozinho?"
Semanas 7–8   → "Alguém pagaria por isso?"
Semanas 9–10  → "Conseguimos repetir o onboarding?"
Semanas 11–13 → "Está gerando caixa previsível?"
```

---

## Metas dos 90 dias

| Meta | Valor |
|------|-------|
| Clientes pagantes | 5 |
| MRR ao final | R$ 2.000–3.500 |
| Custo operacional mensal | < R$ 800 |
| Margem bruta estimada | > 70% |
| Churn no período | 0 |
| Tempo médio de onboarding | < 5 dias |
| Taxa de handoff | < 20% das conversas |
| Leads processados / cliente | > 50 no período |

---

## FASE 1 — Fundação (Semanas 1–2)

**Meta:** infra rodando, banco estruturado, canal WhatsApp ativo.

### Semana 1 — Infra e Core

| Dia | Tarefa | Prompt |
|-----|--------|--------|
| Seg | Provisionar VPS Hostinger, DNS Cloudflare, Docker | P-01 |
| Seg | Rodar docker-compose, validar healthchecks | P-01 validação |
| Ter | Criar projeto Supabase, aplicar migrations lote 0–3 | P-02 |
| Ter | Seed Tenant Zero, validar schema | P-02 validação |
| Qua | Setup Evolution API, conectar número de teste | P-03 |
| Qua | Testar webhook: mensagem → log no Supabase | P-03 validação |
| Qui | Setup Stripe: produtos, preços, webhook | (manual) |
| Qui | Criar planos no Stripe: Básico R$250, Avançado R$450, Futurista R$890 | (manual) |
| Sex | Buffer: corrigir problemas de infra encontrados | — |
| Sex | Documentar o que funcionou e o que não funcionou | — |

**Critério de saída da semana 1:**
```
✅ n8n.ginkgosystems.tech respondendo 200
✅ evolution.ginkgosystems.tech respondendo
✅ chatwoot.ginkgosystems.tech acessível
✅ Supabase: 37 tabelas, Tenant Zero inserido
✅ Webhook Evolution → Supabase logando mensagens
✅ Stripe: 3 produtos criados com preços em BRL
```

---

### Semana 2 — Brann v1 Operacional

| Dia | Tarefa | Prompt |
|-----|--------|--------|
| Seg | Fluxo de atendimento base (webhook → OpenAI → Evolution) | P-04 |
| Ter | Tools: create_lead, fetch_catalog | P-05 |
| Ter | Testar create_lead e fetch_catalog com conversas reais | P-05 validação |
| Qua | System prompt v1, sanitização de output WhatsApp | P-06 |
| Qua | Inserir prompt no banco, testar rollback | P-06 validação |
| Qui | Lead Score Engine | P-07 |
| Qui | Tool handoff_human + Chatwoot integration | P-05 (handoff) |
| Sex | Alertas de incidente em todos os fluxos | P-08 |
| Sex | Teste completo end-to-end: conversa → score → handoff | Manual |

**Critério de saída da semana 2:**
```
✅ Brann responde em < 5s no WhatsApp
✅ Lead salvo após qualificação mínima
✅ Score calculado após cada mensagem
✅ Handoff chega no Chatwoot com resumo
✅ Operador recebe alerta quando score >= 70
✅ Falha de OpenAI → fallback + alerta, não silêncio
```

---

## FASE 2 — Produto (Semanas 3–4)

**Meta:** RAG funcionando, dashboard visível, Tenant Zero operando como produto real.

### Semana 3 — RAG Básico

| Dia | Tarefa | Prompt |
|-----|--------|--------|
| Seg | Pipeline de ingestão de documentos | P-10 |
| Ter | Tool search_knowledge conectada ao Brann | P-11 |
| Qua | Criar e indexar FAQ + catálogo do Tenant Zero | P-12 |
| Qui | Script rag-quality-test: validar 9/10 perguntas | P-12 validação |
| Sex | Ajustar chunking se necessário e reindexar | — |

**Critério de saída da semana 3:**
```
✅ PDF ou markdown indexado em < 2 min
✅ Brann responde perguntas do FAQ com base real
✅ retrieval_logs populado com scores > 0.70
✅ Pergunta fora da base → Brann não inventa, oferece handoff
✅ rag-quality-test: 9+/10 perguntas passando
```

---

### Semana 4 — Dashboard e Observabilidade

| Dia | Tarefa | Prompt |
|-----|--------|--------|
| Seg | Views SQL de métricas (vw_daily_activity, etc) | P-14 schema |
| Ter | n8n: Daily Summary automático às 08h | P-14 workflow |
| Qua | Validar Metabase/Supabase Studio mostrando dados reais | P-14 validação |
| Qui | Executar os 7 testes de validação end-to-end | P-13 |
| Sex | Corrigir falhas encontradas nos testes | — |

**Critério de saída da semana 4:**
```
✅ 7/7 testes passando
✅ Daily summary chegando no WhatsApp às 08h
✅ Métricas visíveis no Supabase Studio
✅ Zero incidentes severity='high' sem alerta
✅ Tenant Zero operando 48h sem intervenção manual
```

---

## FASE 3 — Onboarding e Venda (Semanas 5–6)

**Meta:** provision-tenant funcionando, primeiro cliente externo pago.

### Semana 5 — Frontend Auth + Billing

| Dia | Tarefa | Prompt |
|-----|--------|--------|
| Seg | Setup Next.js 14 + Supabase Auth + layout | FE-01 |
| Ter | Middleware de proteção de rotas, login/register | FE-01 |
| Qua | Página de billing: plano atual, meters de uso | FE-03 |
| Qui | Stripe Checkout para novos planos | FE-03 |
| Qui | Stripe webhook → atualizar subscriptions + token_balances | FE-03 |
| Sex | Testar fluxo completo: cadastro → checkout → tenant ativo | Manual |

**Critério de saída da semana 5:**
```
✅ Login/register funcional com Supabase Auth
✅ Dashboard protegido por middleware
✅ Checkout Stripe processando em modo teste
✅ Webhook Stripe atualizando subscriptions no banco
✅ Token balance refletindo plano contratado
```

---

### Semana 6 — Provision + Primeiro Cliente

| Dia | Tarefa | Prompt |
|-----|--------|--------|
| Seg | Script provision-tenant.sh completo | P-15 |
| Seg | SOPs operacionais (4 documentos) | P-15 |
| Ter | Testar provision com tenant de teste | P-15 validação |
| Qua | Identificar 3 prospects para cliente piloto | Comercial |
| Qua | Preparar proposta e material de demonstração | Comercial |
| Qui | Call de demonstração com prospect 1 | Comercial |
| Sex | Go-live cliente piloto (se fechado) | P-15 go-live |
| Sex | Se não fechado: go-live com Tenant Zero como case | — |

**Critério de saída da semana 6:**
```
✅ provision-tenant.sh cria tenant funcional em < 5 min
✅ Pelo menos 1 cliente em produção (real ou simulado)
✅ 48h de operação estável sem intervenção
✅ Daily summary do cliente chegando ao operador
✅ Playbook comercial rascunhado
```

---

## FASE 4 — Tração (Semanas 7–9)

**Meta:** 3 clientes pagantes, onboarding replicável, primeiros R$ de MRR.

### Semana 7 — Dashboard completo + KPIs ao vivo

| Dia | Tarefa | Prompt |
|-----|--------|--------|
| Seg-Ter | Dashboard overview com KPIs reais e feed ao vivo | FE-02 |
| Qua | Página de Conversas (inbox unificado simples) | Frontend |
| Qui | Página de Leads (CRM básico com score e tags) | Frontend |
| Sex | Testar dashboard com dados reais do cliente piloto | Manual |

---

### Semana 8 — Segundo e Terceiro Clientes

| Dia | Foco | Ação |
|-----|------|------|
| Seg | Prospecção ativa | 10 contatos no WhatsApp (segmentos definidos) |
| Ter | Follow-up e qualificação | Responder interessados, agendar demos |
| Qua | Demos | 2–3 calls de demonstração ao vivo |
| Qui | Fechamento | Enviar proposta + link de checkout |
| Sex | Onboarding | Se fechado: provision-tenant + indexação da base |

**Script de abordagem inicial:**
```
"Oi [nome], vi que vocês [context específico do negócio].
Desenvolvemos um sistema que coloca um assistente de IA no WhatsApp 
de vocês para atender, qualificar e encaminhar leads automaticamente.
Posso te mostrar funcionando em 15 min?"
```

---

### Semana 9 — Otimização e Retenção

| Foco | Ações |
|------|-------|
| Qualidade do Brann | Revisar prompts com base em conversas reais dos clientes |
| RAG | Identificar perguntas não respondidas e adicionar à base |
| Handoff | Analisar taxa de handoff — se > 25%, ajustar prompt |
| Feedback | Call de 20 min com cada cliente: o que funciona, o que falta |
| Documentação | Atualizar SOPs com aprendizados reais |

**Métrica de saúde por cliente:**
```
Taxa de resposta útil   > 80%  (sem handoff nem fallback vazio)
Latência média          < 5s
Taxa de handoff         < 20%
Leads capturados        > 20/semana
Custo por conversa      < R$ 0,50
```

---

## FASE 5 — Escala (Semanas 10–13)

**Meta:** 5 clientes pagantes, MRR > R$ 2.000, operação autônoma.

### Semana 10 — Quarto e Quinto Clientes + Automação de Onboarding

| Dia | Foco | Ação |
|-----|------|------|
| Seg-Ter | Melhorar provision-tenant com automação end-to-end | Código |
| Qua-Qui | Prospecção: mais 10 contatos qualificados | Comercial |
| Sex | Onboarding automatizado: checkout → tenant → e-mail de boas-vindas | Stripe webhook |

---

### Semana 11–12 — Estabilização e Expansão de Base

| Foco | Ações |
|------|-------|
| Páginas de canal | Adicionar Instagram e Google Meu Negócio (OAuth) |
| Content dashboard | Métricas Meta + GMB para clientes com essas integrações |
| Upsell de tokens | Enviar notificação quando saldo < 20% |
| Upgrade de plano | Identificar clientes no Básico que estão no limite |

---

### Semana 13 — Retrospectiva e Roadmap P2

| Foco | Entregável |
|------|-----------|
| Métricas dos 90 dias | Relatório: MRR, churn, CAC, custo operacional, NPS |
| O que aprendemos | Top 5 ajustes que melhoraram produto |
| O que vem depois | Roadmap Command Assistant + Wave + Pyre |
| Próximos 90 dias | Novo plano com base nos dados reais |

---

## Pricing Definitivo

### Planos mensais

| Plano | Preço | Ideal para | Inclui |
|-------|-------|------------|--------|
| **Básico** | R$ 250/mês | Negócio local, 1 atendente virtual | Brann WhatsApp, 500 msgs/mês, FAQ básico, handoff Chatwoot, dashboard simples |
| **Avançado** | R$ 450/mês | PME com volume médio | Básico + 2.000 msgs/mês, RAG completo, lead score, relatório semanal automático |
| **Futurista** | R$ 890/mês | Operação maior ou multiproduto | Avançado + mensagens ilimitadas, skills extras, OpenClaw Telegram, suporte prioritário |

### Setup fee (única vez)

| Plano | Setup |
|-------|-------|
| Básico | R$ 250 |
| Avançado | R$ 450 |
| Futurista | sob consulta |

**Por que cobrar setup:**
- Cobre o trabalho de indexar a base do cliente
- Filtra leads não comprometidos
- Cobre o custo de onboarding (2–4h de trabalho real)

### Pacotes de tokens (upsell)

| Pacote | Tokens | Preço | Margem estimada |
|--------|--------|-------|-----------------|
| Starter | 500k | R$ 79 | ~82% |
| Growth | 2M | R$ 249 | ~83% |
| Scale | 10M | R$ 890 | ~85% |

### Projeção de MRR por semana

| Semana | Clientes | MRR estimado |
|--------|----------|--------------|
| 6 | 1 | R$ 450 |
| 8 | 3 | R$ 1.350 |
| 10 | 4 | R$ 1.800 |
| 13 | 5 | R$ 2.250–3.500 |

---

## Custo Operacional

### Stack no início (estimativa mensal)

| Serviço | Plano | Custo/mês |
|---------|-------|-----------|
| Hostinger VPS | KVM 4 (4GB RAM) | R$ 60 |
| Supabase | Pro | R$ 150 (~$25) |
| Vercel | Pro | R$ 120 (~$20) |
| OpenAI | pay-as-you-go | R$ 80–200 |
| Stripe | % das transações | ~3.4% |
| Cloudflare | Free | R$ 0 |
| Railway (se usar) | Starter | R$ 60 (~$10) |
| **Total fixo** | | **~R$ 470–590/mês** |

**Margem com 3 clientes Avançado:**
```
Receita:         3 × R$ 450 = R$ 1.350
Custo fixo:      R$ 550
Custo OpenAI:    R$ 150 (estimativa 3 clientes)
Margem bruta:    R$ 650 (48%)

Com 5 clientes mistos:
Receita:         R$ 2.500
Custo total:     R$ 750
Margem:          R$ 1.750 (70%)
```

---

## Segmentos Prioritários e Abordagem

### Segmento 1 — Imobiliárias

**Dor:** leads chegam via WhatsApp a qualquer hora, time de corretores não responde rápido, lead some.

**Proposta:** "Brann atende em segundos, qualifica o interesse e envia para o corretor certo com o histórico completo."

**Argumento de ROI:** 1 lead a mais convertido por semana já paga o plano.

---

### Segmento 2 — Clínicas e Consultórios

**Dor:** agenda é gerida no WhatsApp manual, recepcionista perde tempo respondendo as mesmas perguntas.

**Proposta:** "Brann responde perguntas frequentes, qualifica o tipo de consulta e já agenda direto no calendário."

**Argumento de ROI:** reduz 60% das mensagens manuais da recepcionista.

---

### Segmento 3 — E-commerce Local / Loja Física

**Dor:** cliente pergunta sobre produto, estoque, prazo no WhatsApp e não recebe resposta rápida.

**Proposta:** "Brann responde sobre produtos, preços e prazos 24h, captura o pedido e passa para o time fechar."

**Argumento de ROI:** atendimento fora do horário comercial vira receita.

---

### Segmento 4 — Prestadores de Serviço (reformas, TI, design)

**Dor:** orçamentos chegam por WhatsApp, são esquecidos ou respondidos tarde.

**Proposta:** "Brann qualifica o escopo, captura o contato e agenda a visita. Você só entra quando o lead já está quente."

---

## Pitch de 60 Segundos

```
"Você perde quantos leads por semana porque não respondeu rápido?

O Brann da Ginkgo fica no seu WhatsApp 24h, responde na hora, qualifica o 
interesse e só chama você quando o cliente está pronto para fechar.

Não é um bot genérico. Ele aprende com o seu negócio, conhece seu catálogo 
e fala no seu tom.

Configuramos em uma semana, você não precisa de equipe técnica, e começa por 
R$ 250/mês com setup incluído.

Posso te mostrar funcionando ao vivo em 15 minutos?"
```

---

## Material de Demonstração

### O que mostrar numa demo de 15 min

```
Minuto 0–3   → Contexto: "o problema que isso resolve"
Minuto 3–10  → Demo ao vivo:
               - Enviar mensagem de lead para o Tenant Zero
               - Mostrar Brann respondendo em tempo real
               - Mostrar score subindo
               - Mostrar handoff chegando no Chatwoot
               - Abrir dashboard com KPIs
Minuto 10–13 → "Para o seu negócio, funcionaria assim..."
               - Customizar o exemplo para o segmento do prospect
Minuto 13–15 → Próximo passo: proposta + link de checkout
```

### Case do Tenant Zero (seu próprio negócio como case)

```
"Usamos na própria Ginkgo há X semanas.
Processamos Y conversas, capturamos Z leads, taxa de handoff foi de X%.
Custo médio por conversa: R$ 0,XX."

Dados reais do dashboard > qualquer slide.
```

---

## Regras de Operação Durante os 90 Dias

```
Regra 1: Nenhum cliente entra antes do Tenant Zero rodar 48h estável.

Regra 2: Nenhum sprint novo começa antes do anterior ser validado.

Regra 3: Qualquer incidente severity='high' é investigado no mesmo dia.

Regra 4: Toda semana: 30 min de revisão de conversas reais dos clientes.

Regra 5: Prompt só muda via prompt_versions — nunca edição direta.

Regra 6: Custo por conversa deve ser monitorado semanalmente.
         Se > R$ 0,80: investigar e otimizar antes de novos clientes.

Regra 7: Não abrir escopo de produto (Wave, Pyre, marketplace)
         antes da semana 13 ou 5 clientes estáveis — o que vier primeiro.
```

---

## O Que NÃO Fazer nos Primeiros 90 Dias

```
❌ Construir Alfred, Nyra ou Command antes de ter clientes pagantes
❌ Subir Qdrant ou migrar de pgvector sem motivo comprovado
❌ Criar marketplace antes de ter Tool Registry maduro
❌ Tentar integrar Meta Ads ou Google Ads antes de ter operação estável
❌ Aceitar cliente com escopo fora do Leaf (customizações pesadas)
❌ Prometer SLA antes de ter observabilidade
❌ Cobrar por token em público sem ter metering validado
❌ Lançar para 10 clientes antes de validar onboarding com 2
```

---

## Semana a Semana — Resumo executivo

| Semana | Fase | Meta principal | Entregável chave |
|--------|------|----------------|-----------------|
| 1 | Fundação | Infra rodando | docker-compose + schema + webhook |
| 2 | Produto | Brann operacional | conversas reais logadas |
| 3 | Produto | RAG funcionando | FAQ respondendo com base real |
| 4 | Produto | Dashboard + testes | 7/7 testes passando |
| 5 | Venda | Frontend + billing | checkout Stripe funcionando |
| 6 | Venda | Primeiro cliente | provision-tenant + 48h estável |
| 7 | Tração | Dashboard completo | KPIs reais visíveis |
| 8 | Tração | Clientes 2 e 3 | 3 clientes em produção |
| 9 | Retenção | Otimização | prompts e RAG ajustados com dados reais |
| 10 | Escala | Clientes 4 e 5 | onboarding em < 3 dias |
| 11–12 | Escala | Integrações extras | Instagram + GMB para clientes que pedem |
| 13 | Consolidação | Retrospectiva | MRR > R$ 2.000 + roadmap P2 |

---

## Métricas de Sucesso ao Dia 90

```
Negócio:
  MRR                     ≥ R$ 2.000
  Clientes ativos         ≥ 5
  Churn                   = 0
  NPS informal            ≥ 8/10

Produto:
  Tempo de onboarding     ≤ 5 dias
  Uptime Brann            ≥ 99%
  Latência média          < 5s
  Taxa de handoff         < 20%
  RAG hit rate            > 80%

Financeiro:
  Margem bruta            > 70%
  Custo por conversa      < R$ 0,50
  CAC                     < R$ 200
  LTV estimado (12m)      > R$ 3.000/cliente
```

---

## Próximos 90 dias (preview)

Quando os primeiros 90 dias terminarem com 5 clientes e MRR > R$ 2.000:

```
Dias 91–120  → Command Assistant (Telegram/OpenClaw)
Dias 121–150 → Alfred + Wave (SQL Agent + relatórios)
Dias 151–180 → Pyre + Nyra (conteúdo + calendário)
Dias 181+    → Skill registry + marketplace framework
```

---

*Este documento é o plano operacional dos primeiros 90 dias da Ginkgo.*  
*Revise ao final de cada fase. Atualize com dados reais. Não é dogma — é bússola.*

---

**Ginkgo AI Systems — Plano de 90 Dias**  
`90-day-plan v1.0.0 — Março 2026`
