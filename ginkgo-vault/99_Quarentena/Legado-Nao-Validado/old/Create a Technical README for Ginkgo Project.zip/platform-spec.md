# Ginkgo Platform — Product Spec
## Frontend, Integrações, OAuth e Billing

> **Versão:** 1.0.0 | **Data:** Março 2026  
> **Classificação:** Documento interno — produto

---

## 1. Visão do Produto

### O que é

Ginkgo Platform é o **painel central de controle** para donos de negócio que operam com agentes de IA. Ela agrega dados de todos os canais em um único lugar, mostra o que está funcionando, cobra de forma automática e escala sem fricção.

### O que o cliente vê ao logar

```
Uma tela limpa com:
  - Resumo do dia (leads, conversas, custo, conversões)
  - Feed ao vivo de mensagens dos canais ativos
  - Status dos agentes (Brann, OpenClaw, etc.)
  - Alertas de leads quentes
  - Performance de conteúdo (Meta + Google)
  - Uso do plano e saldo de tokens
```

### Posicionamento visual

Estética: **dark dashboard de inteligência operacional** — não é SaaS genérico.  
Referência de tom: Vercel + Linear + Stripe Dashboard.  
Fonte: `Geist` (display) + `JetBrains Mono` (métricas/números).  
Cores: fundo `#0A0A0F`, accent `#6EE7B7` (verde-menta), alert `#F87171`.

---

## 2. Arquitetura do Frontend

```
apps/
  web/                          ← Next.js 14 App Router
    app/
      (auth)/                   ← login, register, oauth callback
      (dashboard)/              ← área logada
        page.tsx                ← overview
        channels/               ← canais conectados
        conversations/          ← inbox unificado
        leads/                  ← CRM e lead score
        content/                ← desempenho Meta + GMB
        agents/                 ← configuração Brann/OpenClaw
        knowledge/              ← base documental RAG
        settings/               ← tenant, plano, integrações
        billing/                ← uso, faturas, upgrade
      api/                      ← API routes Next.js (BFF)
    components/
      ui/                       ← design system base
      charts/                   ← Recharts customizado
      feeds/                    ← feed ao vivo websocket
    lib/
      supabase.ts
      stripe.ts
      integrations/
        evolution.ts
        meta.ts
        google-business.ts
```

---

## 3. Telas e Módulos

### 3.1 Auth — Login / OAuth

```
Opções de login:
  - Email + senha (Supabase Auth)
  - Google OAuth (para conectar GMB depois)
  - Meta OAuth (para conectar Facebook/Instagram depois)

Fluxo:
  login → Supabase Auth → session → redirect /dashboard
  oauth → callback → salvar token em integrations → redirect /dashboard
```

**Campos mínimos no cadastro:**
- Nome do negócio
- Telefone (WhatsApp)
- Plano inicial (Básico | Avançado | Futurista)
- Cartão (Stripe Checkout — cobrado após trial se houver)

---

### 3.2 Dashboard — Overview

**Seção 1 — KPI Cards (topo)**

| Card | Fonte | Atualização |
|------|-------|-------------|
| Conversas hoje | Supabase → messages | Real-time |
| Leads capturados | Supabase → contacts | Real-time |
| Leads quentes (score ≥70) | Supabase → lead_scores | Real-time |
| Handoffs hoje | Supabase → conversations | Real-time |
| Tokens usados (mês) | Supabase → billing_usage | A cada 5 min |
| Custo estimado (R$) | billing_usage × preço token | A cada 5 min |

**Seção 2 — Feed ao vivo**

Coluna esquerda: últimas mensagens WhatsApp (via Evolution API webhook → Supabase)  
Coluna direita: últimas mensagens Telegram/Web (via OpenClaw webhook → Supabase)

Cada item do feed mostra:
- Avatar / inicial do contato
- Preview da última mensagem
- Canal (ícone WhatsApp / Telegram / Web)
- Score do lead (badge colorido)
- Tempo relativo ("2 min atrás")

**Seção 3 — Gráfico de atividade**

Linha temporal (últimos 7 dias):  
Conversas abertas × Leads capturados × Handoffs  
Fonte: Supabase → messages agregados por dia

**Seção 4 — Alertas ativos**

Lista de leads quentes sem resposta > 1h  
Lista de handoffs pendentes no Chatwoot  
Lista de incidentes abertos

---

### 3.3 Channels — Canais Conectados

**Card por canal:**

```
WhatsApp (Evolution API)
  Status: ● Conectado | ○ Desconectado
  Instância: ginkgo-zero
  Mensagens hoje: 34
  [Reconectar QR] [Configurar webhook]

Telegram (OpenClaw)
  Status: ● Conectado
  Bot: @ginkgobot
  Mensagens hoje: 12
  [Configurar] [Ver skill ativa]

Instagram (Meta API)
  Status: ○ Não conectado
  [Conectar com Meta OAuth]

Facebook (Meta API)
  Status: ○ Não conectado
  [Conectar com Meta OAuth]

Google Meu Negócio
  Status: ○ Não conectado
  [Conectar com Google OAuth]
```

**Fluxo de conexão OAuth:**

```
Usuário clica [Conectar com Meta OAuth]
  → redirect Meta OAuth
  → callback /api/oauth/meta/callback
  → salvar access_token + page_id em integrations (Supabase)
  → status muda para ● Conectado
  → habilitar pull de métricas Meta
```

---

### 3.4 Conversations — Inbox Unificado

Visão unificada de todas as conversas de todos os canais.

**Filtros:**
- Canal (WhatsApp / Telegram / Web)
- Status (open / handoff / closed)
- Agente (Brann / OpenClaw / Humano)
- Score (Hot / Warm / Cold)
- Período

**Cada conversa mostra:**
- Nome e telefone do contato
- Canal de origem (ícone)
- Última mensagem (preview)
- Score badge
- Agente responsável
- Tempo desde última interação
- Botão: [Abrir no Chatwoot] | [Ver histórico]

**Detalhe da conversa:**
- Timeline completa de mensagens
- Dados do lead (nome, telefone, email, tags, score)
- Histórico de tools chamadas (search_knowledge, create_lead, etc.)
- Botão: [Forçar handoff] | [Reabrir] | [Fechar]

---

### 3.5 Leads — CRM Integrado

**Tabela de leads com:**

| Campo | Fonte |
|-------|-------|
| Nome | contacts.name |
| Telefone | contacts.phone |
| Canal | conversations.channel |
| Score | lead_scores.score |
| Tags | contacts.tags |
| Última atividade | messages.created_at |
| Status | lead_scores.reason_json |
| Agente | conversations.assigned_agent |

**Filtros:** score range, canal, data, tag, status  
**Ações:** exportar CSV, enviar para Chatwoot, criar tarefa

**Detalhe do lead:**
- Timeline de interações
- Score history (gráfico)
- Motivos do score (reason_json visual)
- Conversas associadas
- Notas manuais

---

### 3.6 Content — Performance Meta + Google

**Fonte:** Meta Graph API + Google My Business API (via OAuth conectado)

**Meta (Instagram + Facebook):**
- Alcance e impressões (7/30 dias)
- Engajamento por post (curtidas, comentários, salvamentos)
- Top posts do período
- Stories ativos
- Mensagens recebidas vs respondidas

**Google Meu Negócio:**
- Visualizações do perfil
- Cliques em ligar / site / rota
- Avaliações recentes (rating + texto)
- Perguntas sem resposta (alerta)
- Fotos adicionadas no período

**Layout:** dois blocos lado a lado, cada um com mini-charts Recharts.

---

### 3.7 Agents — Configuração dos Agentes

**Brann (WhatsApp)**
- Status: ativo/inativo
- Modelo atual (gpt-4o)
- Temperatura
- Prompt versão ativa
- Botão: [Editar prompt] [Ver histórico de versões] [Testar]
- Tools habilitadas (toggle por tool)
- Handoff threshold (slider)

**OpenClaw (Telegram / Web)**
- Status: ativo/inativo
- Instância conectada
- Skills ativas (lista de skills instaladas)
- Botão: [Adicionar skill] [Configurar]

**Skills disponíveis (marketplace interno):**

| Skill | Descrição | Plano mínimo |
|-------|-----------|--------------|
| Criadora de Conteúdo | Briefing → geração → calendário | Avançado |
| Gestão de Tráfego | Análise de campanha + sugestão | Avançado |
| Prospecção de Clientes | Scraping → enriquecimento → CRM | Futurista |
| Pesquisa de Mercado | Tendências + relatório | Futurista |
| Assistente de Reunião | Pauta + resumo pós-call | Avançado |

---

### 3.8 Knowledge — Base Documental

- Lista de documentos indexados (título, tipo, chunks, status, data)
- Upload de novo documento (drag & drop)
- Status da indexação (pending / indexing / indexed / error)
- Teste de busca: digitar query → ver chunks retornados + scores
- Reindexar documento
- Deletar documento (remove chunks do pgvector)

---

### 3.9 Billing — Plano e Uso

**Seção 1 — Plano atual**

```
┌─────────────────────────────────────────┐
│  Plano Avançado                         │
│  R$ 450/mês · próxima cobrança: 15/04   │
│  [Fazer upgrade] [Ver faturas]          │
└─────────────────────────────────────────┘
```

**Seção 2 — Uso do mês**

| Recurso | Usado | Limite | % |
|---------|-------|--------|---|
| Mensagens | 1.243 | 2.000 | 62% |
| Documentos indexados | 18 | 200 | 9% |
| Tokens LLM | 842k | — | — |
| Chamadas a tools | 234 | — | — |

Barra de progresso visual por recurso.

**Seção 3 — Tokens (consumo adicional)**

```
Saldo de tokens: 12.400
Custo por token: R$ 0,002
Uso este mês: R$ 1,68

[Comprar tokens]  [Ver histórico de consumo]
```

**Seção 4 — Faturas**

Tabela: período | valor | status | link PDF

---

### 3.10 Settings — Configurações do Tenant

- Nome do negócio
- Logo (upload)
- Timezone
- Idioma
- Integrações OAuth (status de cada uma)
- Membros da equipe (adicionar, roles)
- Webhook de saída (para sistemas externos)
- Danger zone: deletar conta

---

## 4. Modelo de Billing (Stripe)

### 4.1 Estrutura de cobrança

**Dois vetores de receita:**

```
1. Mensalidade base (Stripe Subscription)
   → recorrente, por plano

2. Consumo adicional de tokens (Stripe Metered Billing ou Credits)
   → cobrado sobre o que ultrapassar ou sobre créditos comprados
```

### 4.2 Tabela de planos

| Plano | Mensalidade | Incluso | Token adicional |
|-------|-------------|---------|-----------------|
| Básico | R$ 250/mês | 500 msgs, 50 docs, Brann | R$ 0,003/token |
| Avançado | R$ 450/mês | 2.000 msgs, 200 docs, Brann + OpenClaw + Skills básicas | R$ 0,0025/token |
| Futurista | R$ 890/mês | Ilimitado msgs, 500 docs, Stack completo + Skills premium | R$ 0,002/token |

### 4.3 Modelo de token

**O que consome token na plataforma:**

| Ação | Tokens consumidos |
|------|-------------------|
| Mensagem processada pelo Brann (gpt-4o) | ~800–1.500 |
| Busca RAG (embedding) | ~100 |
| Skill OpenClaw (por execução) | ~1.000–3.000 |
| Ingestão de documento (por chunk) | ~150 |
| Relatório Alfred | ~2.000–5.000 |
| Prospecção (por lead enriquecido) | ~3.000 |

**Margem operacional:**

```
Custo real OpenAI (gpt-4o):    ~$0.000015/token = R$ 0,000075
Preço cobrado ao cliente:       R$ 0,002/token
Margem bruta por token:         ~96%

Exemplo Básico (500 msgs × 1.200 tokens médios = 600k tokens):
  Custo OpenAI:    R$ 45,00
  Receita plano:   R$ 250,00
  Margem:          R$ 205,00 (82%)
```

### 4.4 Pacotes de crédito (upsell)

| Pacote | Tokens | Preço | Preço/token |
|--------|--------|-------|-------------|
| Starter | 500k | R$ 79 | R$ 0,000158 |
| Growth | 2M | R$ 249 | R$ 0,0001245 |
| Scale | 10M | R$ 890 | R$ 0,000089 |

### 4.5 Fluxo Stripe

```
Cadastro
  → Stripe Customer criado (sem cobrança)
  → Trial 7 dias (opcional)

Ativação do plano
  → Stripe Subscription criada (recorrente)
  → Webhook stripe → /api/webhooks/stripe
  → Supabase: subscriptions.status = 'active'
  → Entitlements habilitados por plano

Compra de tokens
  → Stripe Payment Intent (one-time)
  → Webhook confirmação
  → billing_usage.value += tokens_comprados

Uso de tokens
  → Cada execução de agente → decrementa billing_usage
  → Se saldo < 0: notificar cliente + opcional: bloquear ou cobrar overage

Renovação mensal
  → Stripe processa automaticamente
  → Webhook invoice.paid → atualizar período em billing_usage
```

### 4.6 Tabelas Stripe no Supabase

```sql
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id),
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  plan TEXT,
  status TEXT,  -- active | past_due | canceled | trialing
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE token_balances (
  tenant_id UUID PRIMARY KEY REFERENCES tenants(id),
  balance BIGINT DEFAULT 0,       -- tokens disponíveis
  used_this_period BIGINT DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE token_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id),
  type TEXT,  -- purchase | consumption | refill | bonus
  amount BIGINT,  -- positivo = crédito, negativo = débito
  source TEXT,  -- stripe_payment_id ou tool_execution_id
  created_at TIMESTAMPTZ DEFAULT now()
);
```

---

## 5. Integrações OAuth

### 5.1 Google OAuth (Google Meu Negócio)

```
Scopes necessários:
  - https://www.googleapis.com/auth/business.manage
  - https://www.googleapis.com/auth/userinfo.email

Fluxo:
  /api/oauth/google/connect
    → redirect Google consent
  /api/oauth/google/callback
    → trocar code por access_token + refresh_token
    → salvar em integrations: {provider:'google', tokens:{...}, location_id}
    → habilitar pull de métricas GMB no dashboard

Pull de dados:
  GET https://mybusiness.googleapis.com/v4/accounts/{accountId}/locations/{locationId}/localPosts
  GET https://businessprofileperformance.googleapis.com/v1/{name}:getDailyMetrics
  Frequência: a cada 6 horas (worker assíncrono)
  Salvar em: gmb_metrics (nova tabela)
```

### 5.2 Meta OAuth (Instagram + Facebook)

```
Scopes necessários:
  - pages_show_list
  - pages_read_engagement
  - instagram_basic
  - instagram_manage_insights
  - pages_messaging

Fluxo:
  /api/oauth/meta/connect
    → redirect Meta Login
  /api/oauth/meta/callback
    → trocar code por long-lived token (60 dias)
    → salvar em integrations: {provider:'meta', tokens:{...}, page_id, ig_account_id}

Pull de dados:
  GET /v18.0/{ig_account_id}/media?fields=id,caption,media_type,like_count,comments_count,reach,impressions
  GET /v18.0/{ig_account_id}/insights?metric=reach,impressions,profile_views
  Frequência: a cada 4 horas
  Salvar em: meta_metrics (nova tabela)
```

### 5.3 Tabela de integrações no Supabase

```sql
CREATE TABLE integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id),
  provider TEXT,  -- google | meta | evolution | openclaw
  status TEXT DEFAULT 'connected',
  access_token TEXT,       -- criptografado em repouso
  refresh_token TEXT,      -- criptografado em repouso
  token_expires_at TIMESTAMPTZ,
  metadata_json JSONB,     -- page_id, ig_account_id, location_id, etc.
  connected_at TIMESTAMPTZ DEFAULT now(),
  last_sync_at TIMESTAMPTZ
);
```

> **Segurança:** access_token e refresh_token devem ser criptografados com `pgcrypto` ou Supabase Vault antes de salvar. Nunca retornar tokens brutos para o frontend.

---

## 6. Estrutura de Dados por Fonte

### Supabase (próprio)
- contacts, conversations, messages, lead_scores
- tool_executions, audit_logs
- knowledge_chunks (pgvector)
- billing_usage, token_balances, subscriptions

### Evolution API (WhatsApp)
- Webhook → n8n → Supabase (já implementado)
- Pull adicional: status de instância, QR code, connection state

### OpenClaw (Telegram / Web)
- Webhook → Supabase (via API route Next.js ou n8n)
- Métricas: mensagens por skill, tokens por sessão, status do bot

### Meta Graph API
- Pull assíncrono a cada 4h via worker
- Salvo em `meta_metrics` com tenant_id

### Google My Business API
- Pull assíncrono a cada 6h via worker
- Salvo em `gmb_metrics` com tenant_id

---

## 7. Design System

### Paleta

```css
:root {
  --bg-base:      #0A0A0F;
  --bg-surface:   #111118;
  --bg-elevated:  #18181F;
  --border:       #2A2A35;
  --text-primary: #F0F0F5;
  --text-muted:   #6B6B80;
  --accent:       #6EE7B7;   /* verde-menta: sucesso, ativo, CTA */
  --accent-warm:  #FCD34D;   /* amarelo: alerta, warm lead */
  --accent-hot:   #F87171;   /* vermelho: erro, hot lead, crítico */
  --accent-blue:  #60A5FA;   /* azul: info, WhatsApp highlight */
}
```

### Tipografia

```
Display / Headings : Geist (sans-serif, moderno, técnico)
Números / Métricas : JetBrains Mono (monospace, leitura rápida)
Body / UI          : Geist (mesmo família, peso regular)
```

### Componentes base

- `KPICard` — métrica principal + variação + ícone
- `LiveFeed` — stream de mensagens com websocket
- `ScoreBadge` — badge colorido por threshold (hot/warm/cold)
- `ChannelStatus` — indicador de canal com ícone + estado
- `TokenMeter` — barra de progresso de tokens usados
- `UsageTable` — tabela de uso por período
- `OAuthButton` — botão de conexão por provider

---

## 8. Sequência de Build do Frontend

### Fase 1 — Auth + Shell (Semana 1)
- Setup Next.js 14 + Supabase Auth
- Layout base (sidebar + topbar + main)
- Páginas: login, register, OAuth callback
- Middleware de proteção de rotas

### Fase 2 — Dashboard + KPIs (Semana 2)
- KPI cards conectados ao Supabase real
- Feed ao vivo via Supabase Realtime
- Gráfico de atividade (Recharts)
- Alertas de leads e handoffs

### Fase 3 — Canais + Integrações OAuth (Semana 3)
- Página Channels com status por canal
- Fluxo OAuth Google + Meta
- Salvar e renovar tokens
- Webhook Evolution → status no painel

### Fase 4 — Leads + Conversations (Semana 4)
- CRM de leads com filtros
- Inbox unificado
- Detalhe de conversa com timeline

### Fase 5 — Billing + Stripe (Semana 5)
- Stripe Checkout para planos
- Stripe Customer Portal para faturas
- Token balance em tempo real
- Webhooks stripe → Supabase

### Fase 6 — Content + Agents + Knowledge (Semana 6)
- Dashboard Meta + GMB
- Configuração de agentes
- Upload e gestão de base RAG
- Skills marketplace

---

## 9. Endpoints API (Next.js BFF)

```
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/me

GET  /api/oauth/google/connect
GET  /api/oauth/google/callback
GET  /api/oauth/meta/connect
GET  /api/oauth/meta/callback

GET  /api/dashboard/kpis
GET  /api/dashboard/feed
GET  /api/dashboard/activity

GET  /api/channels
GET  /api/channels/:id/status

GET  /api/conversations
GET  /api/conversations/:id

GET  /api/leads
GET  /api/leads/:id

GET  /api/content/meta
GET  /api/content/gmb

GET  /api/agents
PUT  /api/agents/:id

GET  /api/knowledge
POST /api/knowledge/upload
DELETE /api/knowledge/:id

GET  /api/billing/plan
GET  /api/billing/usage
GET  /api/billing/invoices
POST /api/billing/checkout
POST /api/billing/portal
POST /api/webhooks/stripe
```

---

## 10. Próximos passos

Com esse spec, o próximo prompt para o Antigravity é:

**FE-01 — Setup Next.js + Auth + Shell**
```
Setup Next.js 14 App Router + Supabase Auth
Layout base com sidebar
Middleware de proteção de rotas
Páginas: login, register
Design system: tokens CSS, fontes Geist + JetBrains Mono
```

**FE-02 — Dashboard KPIs + Feed**
**FE-03 — Channels + OAuth**
**FE-04 — Billing + Stripe**
**FE-05 — Leads + Conversations**
**FE-06 — Content + Agents + Knowledge**

---

**Ginkgo AI Systems — Documento Interno**  
`platform-spec v1.0 — Março 2026`
