# Ginkgo Core Spec
## Product Requirements Document — v1.0

> **Classificação:** Documento interno — Ginkgo AI Systems  
> **Status:** Draft para revisão  
> **Versão:** 1.0.0  
> **Data:** Março 2026  

---

## Sumário

1. [Visão do Produto](#1-visão-do-produto)
2. [Arquitetura Técnica](#2-arquitetura-técnica)
3. [Stack Tecnológica](#3-stack-tecnológica)
4. [Modelo Multi-Tenant](#4-modelo-multi-tenant)
5. [Entidades do Banco](#5-entidades-do-banco)
6. [Agentes — Responsabilidades e Políticas](#6-agentes--responsabilidades-e-políticas)
7. [Catálogo de Tools](#7-catálogo-de-tools)
8. [Fluxos n8n](#8-fluxos-n8n)
9. [Pipeline RAG](#9-pipeline-rag)
10. [Observabilidade](#10-observabilidade)
11. [Segurança e Governança](#11-segurança-e-governança)
12. [Billing e Modelo Operacional](#12-billing-e-modelo-operacional)
13. [Política de Prompts](#13-política-de-prompts)
14. [Onboarding de Cliente](#14-onboarding-de-cliente)
15. [Roadmap por Fases e Backlog](#15-roadmap-por-fases-e-backlog)
16. [Critérios de Aceitação por Entregável](#16-critérios-de-aceitação-por-entregável)

---

## 1. Visão do Produto

### 1.1 Posicionamento

A Ginkgo AI Systems é uma plataforma de agentes de IA para PMEs brasileiras, operada como serviço gerenciado com arquitetura SaaS por baixo.

**Proposta de valor central:**  
Cada cliente não recebe um robô artesanal montado na unha. Ele recebe uma instância de uma arquitetura-mãe, com módulos ativados conforme o plano contratado.

**Modelo de negócio:** Por fora, alfaiate. Por dentro, fábrica.

### 1.2 Princípios de Design

| Princípio | Descrição |
|-----------|-----------|
| Replicabilidade | Cada novo cliente é uma instância, não um projeto do zero |
| Composabilidade | Agentes, tools e fluxos são módulos independentes e combináveis |
| Observabilidade | Nada roda sem log, custo e latência rastreados |
| Segurança por padrão | Isolamento por tenant, read-only por padrão, ações destrutivas exigem confirmação |
| Escalabilidade incremental | Começa simples. Complexidade só entra quando há demanda real |

### 1.3 Estrutura de 3 Níveis

```
Nível 1 — Core Operacional
  ├── Autenticação e multi-tenant
  ├── Roteamento de mensagens
  ├── Memória e contexto
  ├── Integrações base
  ├── Logs e observabilidade
  └── Billing e limites

Nível 2 — Agentes Especializados
  ├── Brann  (atendimento, vendas, qualificação)
  ├── Alfred (operações, dados, relatórios)
  ├── Nyra   (pesquisa, conteúdo, mídia)
  └── LAPLACE (orquestração e supervisão)

Nível 3 — Workflows e Tools
  ├── Canais: WhatsApp, Chatwoot, Email, Webchat
  ├── Dados: Postgres, Supabase, pgvector, Qdrant
  ├── Produtividade: Google Calendar, CRM, PDF
  └── Externo: APIs, scraping, webhooks
```

---

## 2. Arquitetura Técnica

### 2.1 Fluxo Macro

```
Canal de entrada
  → Gateway (auth, tenant, routing)
    → Agente (Brann / Alfred / Nyra)
      → Tool / Workflow
        → Dados (Postgres / Vector DB)
          → Resposta
            → Logs (latência, custo, evidência)
```

### 2.2 Diagrama de Componentes

```
┌──────────────────────────────────────────┐
│           FRONT / PORTAL                 │
│     site institucional, painel cliente   │
│           onboarding, billing            │
└─────────────────┬────────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│           GINKGO GATEWAY                 │
│   auth · tenant_id · routing · rate limit│
└──────────┬───────────┬───────────────────┘
           │           │           │
           ▼           ▼           ▼
    ┌──────────┐ ┌──────────┐ ┌──────────┐
    │  BRANN   │ │  ALFRED  │ │   NYRA   │
    │ vendas   │ │ ops / BI │ │conteúdo  │
    │ suporte  │ │ docs/SQL │ │ pesquisa │
    └────┬─────┘ └────┬─────┘ └────┬─────┘
         └────────────┴────────────┘
                      │
                      ▼
         ┌────────────────────────┐
         │        LAPLACE         │
         │ supervisor/orchestrator│
         └────────┬───────────────┘
                  │
     ┌────────────┼────────────┐
     ▼            ▼            ▼
┌─────────┐ ┌─────────┐ ┌──────────┐
│   n8n   │ │Tool APIs│ │RAG Engine│
│Workflows│ │WA/Email │ │pgvector/ │
│         │ │Calendar │ │  Qdrant  │
└────┬────┘ └────┬────┘ └────┬─────┘
     │           │           │
     ▼           ▼           ▼
┌─────────┐ ┌─────────┐ ┌──────────┐
│Postgres │ │External │ │Vector DB │
│Supabase │ │  Apps   │ │embeddings│
│CRM/Logs │ │         │ │chunks    │
└─────────┘ └─────────┘ └──────────┘
```

---

## 3. Stack Tecnológica

### 3.1 Backend e Dados

| Componente | Tecnologia | Justificativa |
|------------|------------|---------------|
| Banco principal | PostgreSQL / Supabase | Multi-tenant, auth, storage, edge functions |
| Vetor (fase 1) | pgvector no Supabase | Menos peças, lançamento rápido, custo menor |
| Vetor (fase 2+) | Qdrant | Volume documental alto, busca pesada, tuning fino |
| Orquestração de fluxos | n8n | Integrações, automações, glue layer |
| Lógica agentic | LangGraph | Agentes com estado e fluxo controlado |
| WhatsApp | Evolution API | Estável, comunidade, boa integração com n8n |
| Inbox humano | Chatwoot | Handoff, histórico, SLA |

**Regra de ouro:** Começa com pgvector. Só sobe Qdrant quando houver motivo real de performance. Não monta Death Star para atender padaria premium.

### 3.2 LLMs

```
Estratégia de provider:
  OpenAI      → confiabilidade geral, function calling
  Claude      → tarefas longas, documentais, raciocínio complexo
  Fallback    → modelos locais / alternativos (fase futura)

Regra: modelo é fornecedor, não fundação.
Nunca hardcode um único provider.
```

### 3.3 Front e Infra

| Camada | Tecnologia |
|--------|------------|
| Site institucional | Lovable / Next.js |
| Portal do cliente | Next.js + Supabase Auth |
| Infra | VPS/Cloud + Docker |
| Gerenciamento de containers | Easypanel ou Portainer |
| Proxy reverso | Traefik |
| Serviços | Isolados por container |

---

## 4. Modelo Multi-Tenant

### 4.1 Estratégia

**Tenant lógico com isolamento por dados.**  
Banco compartilhado + isolamento por `tenant_id` no início.  
Banco dedicado como opção de plano Enterprise futuro.

### 4.2 O que cada tenant possui

- `tenant_id` único e imutável
- Configs próprias (canais, integrações, limites)
- Prompts próprios por agente
- Base de conhecimento própria
- Logs e métricas isolados
- Limites de uso por plano

### 4.3 Regras de isolamento

- Toda query deve incluir `WHERE tenant_id = $tenant`
- RLS (Row Level Security) ativo no Supabase para camada extra
- Secrets de integrações nunca compartilhados entre tenants
- Embeddings e chunks vetoriais sempre com `tenant_id` no metadata

---

## 5. Entidades do Banco

### 5.1 Domínio Comercial

```sql
-- Tenants (clientes da Ginkgo)
tenants (
  id            UUID PRIMARY KEY,
  name          TEXT NOT NULL,
  plan          TEXT,  -- basico | avancado | futurista
  status        TEXT,  -- active | suspended | churned
  config_json   JSONB,
  created_at    TIMESTAMPTZ DEFAULT now()
)

-- Usuários do tenant
users (
  id            UUID PRIMARY KEY,
  tenant_id     UUID REFERENCES tenants,
  role          TEXT,  -- admin | operator | viewer
  name          TEXT,
  email         TEXT,
  created_at    TIMESTAMPTZ DEFAULT now()
)

-- Contatos atendidos
contacts (
  id            UUID PRIMARY KEY,
  tenant_id     UUID REFERENCES tenants,
  external_id   TEXT,  -- ID no WhatsApp, CRM, etc.
  name          TEXT,
  phone         TEXT,
  email         TEXT,
  tags          TEXT[],
  metadata_json JSONB,
  created_at    TIMESTAMPTZ DEFAULT now()
)

-- Conversas
conversations (
  id             UUID PRIMARY KEY,
  tenant_id      UUID REFERENCES tenants,
  contact_id     UUID REFERENCES contacts,
  channel_id     UUID REFERENCES channels,
  assigned_agent TEXT,  -- brann | alfred | nyra | human
  status         TEXT,  -- open | closed | handoff | waiting
  opened_at      TIMESTAMPTZ,
  closed_at      TIMESTAMPTZ
)

-- Mensagens
messages (
  id              UUID PRIMARY KEY,
  tenant_id       UUID REFERENCES tenants,
  conversation_id UUID REFERENCES conversations,
  sender_type     TEXT,  -- user | agent | human
  content         TEXT,
  metadata_json   JSONB,
  created_at      TIMESTAMPTZ DEFAULT now()
)

-- Lead scores
lead_scores (
  id          UUID PRIMARY KEY,
  tenant_id   UUID REFERENCES tenants,
  contact_id  UUID REFERENCES contacts,
  score       INTEGER,
  reason_json JSONB,
  updated_at  TIMESTAMPTZ DEFAULT now()
)

-- Agendamentos
appointments (
  id          UUID PRIMARY KEY,
  tenant_id   UUID REFERENCES tenants,
  contact_id  UUID REFERENCES contacts,
  datetime    TIMESTAMPTZ,
  status      TEXT,
  notes       TEXT,
  created_at  TIMESTAMPTZ DEFAULT now()
)
```

### 5.2 Domínio de Conhecimento

```sql
-- Documentos da base
knowledge_documents (
  id          UUID PRIMARY KEY,
  tenant_id   UUID REFERENCES tenants,
  source_type TEXT,  -- pdf | docx | url | faq | notion
  title       TEXT,
  file_url    TEXT,
  status      TEXT,  -- pending | indexing | indexed | error
  version     INTEGER DEFAULT 1,
  created_at  TIMESTAMPTZ DEFAULT now()
)

-- Chunks vetorizados
knowledge_chunks (
  id            UUID PRIMARY KEY,
  tenant_id     UUID REFERENCES tenants,
  document_id   UUID REFERENCES knowledge_documents,
  chunk_text    TEXT,
  embedding     VECTOR(1536),  -- pgvector
  metadata_json JSONB,  -- section, page, source, title
  created_at    TIMESTAMPTZ DEFAULT now()
)

-- Logs de retrieval
retrieval_logs (
  id            UUID PRIMARY KEY,
  tenant_id     UUID REFERENCES tenants,
  query_text    TEXT,
  top_chunks    JSONB,
  score_avg     FLOAT,
  used_in_msg   UUID REFERENCES messages,
  created_at    TIMESTAMPTZ DEFAULT now()
)
```

### 5.3 Domínio Operacional

```sql
-- Execuções de tools
tool_executions (
  id           UUID PRIMARY KEY,
  tenant_id    UUID REFERENCES tenants,
  agent_id     TEXT,
  tool_name    TEXT,
  input_json   JSONB,
  output_json  JSONB,
  success      BOOLEAN,
  latency_ms   INTEGER,
  created_at   TIMESTAMPTZ DEFAULT now()
)

-- Logs de auditoria
audit_logs (
  id           UUID PRIMARY KEY,
  tenant_id    UUID REFERENCES tenants,
  event_type   TEXT,
  actor        TEXT,
  payload_json JSONB,
  created_at   TIMESTAMPTZ DEFAULT now()
)

-- Incidentes
incidents (
  id           UUID PRIMARY KEY,
  tenant_id    UUID REFERENCES tenants,
  severity     TEXT,  -- low | medium | high | critical
  description  TEXT,
  resolved_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ DEFAULT now()
)
```

### 5.4 Domínio de Configuração

```sql
-- Configuração de agentes por tenant
agents (
  id             UUID PRIMARY KEY,
  tenant_id      UUID REFERENCES tenants,
  type           TEXT,  -- brann | alfred | nyra | laplace
  enabled        BOOLEAN DEFAULT false,
  config_json    JSONB,
  prompt_version TEXT,
  updated_at     TIMESTAMPTZ DEFAULT now()
)

-- Canais por tenant
channels (
  id          UUID PRIMARY KEY,
  tenant_id   UUID REFERENCES tenants,
  type        TEXT,  -- whatsapp | telegram | webchat | email
  config_json JSONB,
  status      TEXT,
  created_at  TIMESTAMPTZ DEFAULT now()
)

-- Versões de prompt
prompt_versions (
  id          UUID PRIMARY KEY,
  tenant_id   UUID REFERENCES tenants,
  agent_type  TEXT,
  version     TEXT,
  content     TEXT,
  active      BOOLEAN DEFAULT false,
  created_at  TIMESTAMPTZ DEFAULT now()
)

-- Limites por plano
plan_limits (
  plan              TEXT PRIMARY KEY,
  max_messages_mo   INTEGER,
  max_documents     INTEGER,
  max_agents        INTEGER,
  max_channels      INTEGER,
  rag_enabled       BOOLEAN,
  sql_agent_enabled BOOLEAN
)
```

### 5.5 Domínio Financeiro

```sql
-- Uso para billing
billing_usage (
  id           UUID PRIMARY KEY,
  tenant_id    UUID REFERENCES tenants,
  metric_type  TEXT,  -- messages | tokens | documents | tools
  value        NUMERIC,
  period       TEXT,  -- YYYY-MM
  created_at   TIMESTAMPTZ DEFAULT now()
)

-- Faturas
invoices (
  id           UUID PRIMARY KEY,
  tenant_id    UUID REFERENCES tenants,
  amount_brl   NUMERIC,
  period       TEXT,
  status       TEXT,  -- pending | paid | overdue
  issued_at    TIMESTAMPTZ,
  paid_at      TIMESTAMPTZ
)
```

---

## 6. Agentes — Responsabilidades e Políticas

### 6.1 Brann — Atendimento e Vendas

**Papel:** Agente de linha de frente. Primeiro contato, qualificação e conversão.

**Responsabilidades:**
- Responder atendimento em linguagem natural
- Qualificar leads via SPIN Selling e perguntas guiadas
- Consultar base RAG (FAQ, catálogo, políticas)
- Capturar e salvar dados do contato
- Disparar handoff para humano quando necessário
- Iniciar agendamentos
- Registrar no CRM após cada interação relevante

**Não deve fazer:**
- Automações críticas sem validação humana
- Consultas sensíveis sem regra explícita
- Responder fora do escopo configurado pelo tenant
- Inventar política, preço ou procedimento

**Tools autorizadas:** `search_knowledge`, `create_lead`, `update_contact`, `handoff_human`, `schedule_appointment`, `fetch_catalog`, `generate_simple_proposal`

### 6.2 Alfred — Operações e Dados

**Papel:** Operador interno e analista. Age sobre dados estruturados.

**Responsabilidades:**
- SQL Agent read-only sobre banco do cliente
- Geração de relatórios operacionais e executivos
- Leitura e parsing de documentos
- Extração estruturada de dados
- Monitoramento de métricas e fila

**Regras rígidas:**
- Read-only por padrão em toda operação SQL
- Qualquer escrita exige confirmação explícita + log
- Queries passam por validação de complexidade e limite de linhas
- Sem acesso a tabelas de autenticação ou segredos

**Tools autorizadas:** `query_sql_readonly`, `generate_report`, `parse_pdf`, `classify_document`, `extract_document_fields`, `monitor_queue`

### 6.3 Nyra — Pesquisa, Conteúdo e Mídia

**Papel:** Laboratório de pesquisa e produção de conteúdo.

**Responsabilidades:**
- Pesquisa de mercado e análise de tendência
- Apoio de pauta e estruturação de campanhas
- Resumo de notícias e relatórios externos
- Preparação de reuniões
- Pipeline de conteúdo editorial

**Regras:**
- Não publica automaticamente sem validação humana (até fase P3)
- Drafts sempre marcados como rascunho
- Fontes sempre citadas no output

**Tools autorizadas:** `web_research`, `scrape_controlled`, `summarize_content`, `draft_copy`, `manage_editorial_calendar`

### 6.4 LAPLACE — Supervisor e Orquestrador

**Papel:** Roteador inteligente e coordenador de agentes. Nasce como supervisor, não como executor universal.

**Responsabilidades:**
- Decidir qual agente acionar por contexto
- Dividir tarefas complexas em subtarefas
- Validar estado dos fluxos inter-agentes
- Lidar com fallback e escalonamento
- Controlar jobs que cruzam agentes

**Não deve:**
- Virar executor de tarefas operacionais diretas
- Substituir Brann, Alfred ou Nyra em suas responsabilidades
- Tomar decisões destrutivas sem policy explícita

**Exemplo de roteamento:**
```
Mensagem: "Quero saber se tem produto até R$500 e como parcelar."

LAPLACE:
  1. Brann   → coletar contexto e intenção do lead
  2. Brann   → buscar catálogo por faixa de preço
  3. Alfred  → consultar regras de parcelamento
  4. Brann   → consolidar e responder ao cliente
```

---

## 7. Catálogo de Tools

### 7.1 Padrão de Tool

Toda tool deve ter:

```json
{
  "tool_name": "nome_da_tool",
  "description": "O que faz e quando usar",
  "agent": ["brann", "alfred"],
  "input_schema": {
    "campo": "tipo"
  },
  "output_schema": {
    "campo": "tipo"
  },
  "timeout_ms": 5000,
  "retries": 3,
  "log": true,
  "read_only": true
}
```

### 7.2 Tools por Agente

#### Brann

| Tool | Descrição | Input | Output |
|------|-----------|-------|--------|
| `search_knowledge` | Busca na base RAG do tenant | `query, tenant_id, top_k` | `chunks[], sources[]` |
| `create_lead` | Cria ou atualiza lead no CRM | `name, phone, intent, source` | `lead_id, status` |
| `update_contact` | Atualiza dados do contato | `contact_id, fields{}` | `success` |
| `handoff_human` | Transfere para atendente humano | `conversation_id, reason, summary` | `ticket_id, operator` |
| `schedule_appointment` | Cria agendamento | `contact_id, datetime, notes` | `appointment_id` |
| `fetch_catalog` | Busca produtos/serviços do tenant | `query, filters{}` | `items[]` |
| `generate_simple_proposal` | Gera proposta básica | `contact_id, items[], context` | `proposal_text` |

#### Alfred

| Tool | Descrição | Input | Output |
|------|-----------|-------|--------|
| `query_sql_readonly` | Executa SQL read-only validado | `query, tenant_id` | `rows[], row_count` |
| `generate_report` | Gera relatório estruturado | `query_results, format, period` | `report_text, summary` |
| `parse_pdf` | Extrai texto de PDF | `file_url, tenant_id` | `text, pages, metadata` |
| `classify_document` | Classifica tipo de documento | `text` | `type, confidence` |
| `extract_document_fields` | Extrai campos estruturados | `text, schema{}` | `fields{}` |

#### Nyra

| Tool | Descrição | Input | Output |
|------|-----------|-------|--------|
| `web_research` | Pesquisa na web sobre tema | `query, depth` | `results[], summary` |
| `summarize_content` | Resume conteúdo longo | `text, max_length` | `summary, key_points[]` |
| `draft_copy` | Gera rascunho de texto | `brief, tone, format` | `draft, title` |

---

## 8. Fluxos n8n

### Fluxo 1 — Atendimento Base (Brann)

```
Webhook WhatsApp (Evolution API)
  → Extrair tenant_id + número
  → Buscar ou criar contato
  → Buscar ou criar conversa
  → Montar contexto (últimas N mensagens)
  → Enviar para Brann (LLM + tools)
  → Se tool call: executar e reinjetar resultado
  → Formatar resposta
  → Enviar via Evolution API
  → Logar: latência, tokens, custo, tool usada
```

### Fluxo 2 — Lead Score

```
Trigger: nova mensagem qualificada ou tag de intent
  → Extrair dados do contato
  → Calcular score (critérios configuráveis por tenant)
  → Atualizar lead_scores
  → Se score > threshold configurado:
      → Criar alerta no Chatwoot
      → Notificar operador via WhatsApp/email
      → Opcionalmente: criar task no CRM
```

### Fluxo 3 — Ingestão de Documentos

```
Trigger: novo upload (webhook ou cronjob)
  → Salvar arquivo em storage (Supabase)
  → Extrair texto (PDF parser / DOCX / URL)
  → Limpar e normalizar texto
  → Chunking (500-900 tokens, overlap 80-150)
  → Gerar embeddings (OpenAI / alternativo)
  → Salvar chunks no pgvector com metadata
  → Marcar documento como indexed
  → Logar: tempo, chunks gerados, erros
```

### Fluxo 4 — Relatório Alfred (Automático)

```
Trigger: agendamento diário/semanal por tenant
  → Executar SQL queries pré-configuradas
  → Consolidar resultados
  → Alfred gera resumo executivo
  → Formatar (texto + tabelas)
  → Enviar via WhatsApp ou email para responsável
  → Logar execução
```

### Fluxo 5 — Handoff Humano

```
Condição: risco alto | incerteza | request explícito | threshold de score
  → Marcar conversa como status = 'handoff'
  → Gerar resumo do contexto (últimas mensagens, intent, dados do lead)
  → Criar ticket no Chatwoot com resumo
  → Notificar operador responsável
  → Brann envia mensagem de transição ao usuário
  → Logar: motivo, agente, operador designado
```

### Fluxo 6 — Extraction with Retries

```
Trigger: novo documento para extração estruturada
  → Tentativa 1: extração via LLM com schema
  → Se falha parcial → retry com prompt corrigido
  → Se falha total → retry com chunking menor
  → Após 3 falhas: marcar como erro + alertar humano
  → Logar cada tentativa: input, output, sucesso, latência
```

---

## 9. Pipeline RAG

### 9.1 Fontes de Ingestão Suportadas

- PDFs (manuais, contratos, políticas, propostas)
- DOCX (documentos Word)
- Planilhas (via parser estruturado)
- Sites institucionais (scraping controlado)
- FAQs em texto
- Notion (via API)
- CRM notes exportadas

### 9.2 Regras de Chunking

| Parâmetro | Valor recomendado |
|-----------|-------------------|
| Tamanho do chunk | 500–900 tokens |
| Overlap | 80–150 tokens |
| Unidade de split | Parágrafo > frase > fixo |

**Chunk pequeno demais:** contexto quebrado, precisão ruim em perguntas abertas  
**Chunk grande demais:** imprecisão na busca, custo maior de contexto

### 9.3 Metadata Mínima por Chunk

```json
{
  "tenant_id": "uuid",
  "document_id": "uuid",
  "source": "pdf | url | faq",
  "title": "Nome do documento",
  "section": "Seção ou capítulo",
  "page": 3,
  "created_at": "2026-03-14",
  "version": 1
}
```

### 9.4 Estágios de Maturidade RAG

| Estágio | Quando usar | O que faz |
|---------|-------------|-----------|
| RAG Básico | P1 — todos os clientes | Top-k + resposta fundamentada com citação |
| Adaptive RAG | P2 — clientes com base maior | Decide quando buscar, quando responder direto |
| Corrective RAG | P3 — clientes com base ruidosa | Avalia chunks antes de gerar; refaz busca se fraco |
| Self-RAG | P3 — casos críticos | Auto-avalia se precisa mais contexto antes de responder |

**Regra operacional:** Vender RAG básico robusto. Operar Adaptive internamente. Introduzir CRAG/Self-RAG só quando o cliente genuinamente precisar.

---

## 10. Observabilidade

### 10.1 O que Logar em Toda Execução

| Campo | Descrição |
|-------|-----------|
| `tenant_id` | Tenant responsável |
| `conversation_id` | Conversa relacionada |
| `agent` | Agente executado |
| `prompt_version` | Versão do system prompt |
| `tools_used` | Tools chamadas e resultados |
| `latency_ms` | Tempo total de execução |
| `input_tokens` | Tokens de entrada |
| `output_tokens` | Tokens de saída |
| `cost_usd` | Custo estimado |
| `rag_evidence` | Chunks recuperados e scores |
| `final_response` | Resposta final enviada |
| `error` | Erro ou fallback se houve |
| `handoff` | Se transferiu para humano |

### 10.2 Métricas Críticas por Tenant

- Custo por conversa e custo por tenant/mês
- Latência média de resposta
- Taxa de handoff (conversas transferidas)
- Taxa de resposta útil (sem fallback vazio)
- Taxa de falha por tool
- Tokens por fluxo
- Score médio de recuperação RAG
- Conversão de lead (captura → qualificado → agendado)

### 10.3 Stack de Observabilidade

| Componente | Tecnologia |
|------------|------------|
| Logs estruturados | PostgreSQL (tabela `tool_executions`, `audit_logs`) |
| Dashboard operacional | Metabase ou Supabase Studio |
| Rastreamento de agentes | LangSmith (se usar LangGraph pesado) |
| Alertas | WhatsApp / Telegram via n8n |

---

## 11. Segurança e Governança

### 11.1 Regras Mínimas

- Segregação completa por `tenant_id` em toda operação
- Secrets fora do código (variáveis de ambiente, Vault)
- Tool permissions definidas por agente — nunca compartilhadas
- SQL com read-only por padrão para Alfred e LAPLACE
- Rate limiting por tenant no Gateway
- PII protegida: telefone e email nunca em logs brutos
- Versionamento de prompt obrigatório
- Rollback de configuração disponível por tenant

### 11.2 Política por Agente

| Agente | Pode | Não pode |
|--------|------|----------|
| Brann | Consultar, registrar, sugerir, agendar | Executar ações financeiras irreversíveis |
| Alfred | Consultar base, extrair, reportar | Escrita sem confirmação explícita |
| Nyra | Pesquisar, gerar drafts | Publicar automaticamente em P1/P2 |
| LAPLACE | Orquestrar, rotear, supervisionar | Virar executor universal sem policy |

---

## 12. Billing e Modelo Operacional

### 12.1 Métricas Medidas por Cliente

- Mensagens processadas por mês
- Documentos indexados e tamanho da base
- Chamadas a tools externas (API)
- Uso de modelos premium (GPT-4, Claude Opus)
- Execuções de workflows n8n
- Atendimentos com handoff humano

### 12.2 Planos

| Plano | Agentes | Recursos | Limite |
|-------|---------|----------|--------|
| **Básico** | Brann | Atendimento, FAQ, lead capture | Até 500 msgs/mês |
| **Avançado** | Brann + Alfred | Suporte + relatórios + SQL Agent + automações n8n | Até 2.000 msgs/mês |
| **Futurista** | Brann + Alfred + Nyra + LAPLACE | RAG avançado, automações multicanal, inteligência expandida | Customizado |

### 12.3 Regra Operacional

Medir uso desde o início, mesmo que no começo se cobre preço fixo. Isso garante dados para precificação correta nos próximos trimestres.

---

## 13. Política de Prompts

### 13.1 Estrutura de Camadas

```
1. Base persona do agente
   ↓
2. Regras do agente (o que pode e não pode)
   ↓
3. Contexto do tenant (nome, tom, segmento, políticas)
   ↓
4. Contexto da conversa (histórico, dados do contato)
   ↓
5. Tool instructions (tools disponíveis e quando usar)
   ↓
6. Safety e fallback rules
```

### 13.2 Cada Agente Precisa de

- System prompt base (imutável por versão)
- Prompt override por tenant (customizações)
- Variações por canal (WhatsApp tem tom diferente de email)
- Prompt por idioma se necessário
- Regras de compliance do segmento do cliente
- Versionamento com `prompt_version` no banco

### 13.3 Regras Universais

- Prompt sem versionamento vira areia movediça
- Nunca alterar prompt base em produção sem teste
- Rollback deve ser possível em menos de 5 minutos
- Mudanças em prompt vão para `prompt_versions` antes de ativar

---

## 14. Onboarding de Cliente

### 14.1 Checklist Técnico

```
[ ] Criar tenant no banco
[ ] Definir plano e limites
[ ] Configurar canal WhatsApp (Evolution API)
[ ] Configurar Chatwoot (inbox + agente)
[ ] Ativar Brann com prompt base
[ ] Carregar base de conhecimento inicial (FAQ mínimo)
[ ] Testar fluxo end-to-end (mensagem → resposta → log)
[ ] Configurar lead score threshold
[ ] Configurar handoff conditions
[ ] Ativar dashboard de métricas
[ ] Treinar responsável do cliente
```

### 14.2 Tempo Estimado por Fase

| Etapa | Tempo |
|-------|-------|
| Setup técnico básico | 1–2 dias |
| Customização de prompt | 1 dia |
| Ingestão de documentos | 1–3 dias |
| Testes e ajuste fino | 2–3 dias |
| Go-live | Dia 5–7 |

---

## 15. Roadmap por Fases e Backlog

### Fase 1 — Núcleo Vendável (Semanas 1–3)

**Objetivo:** Produto mínimo comercial. Algo na rua para vender.

| # | Tarefa | Entregável |
|---|--------|-----------|
| 1.1 | Setup Supabase + schema base | Banco rodando com tenant zero |
| 1.2 | Evolution API + webhook n8n | WhatsApp recebendo e respondendo |
| 1.3 | Brann Support Agent v1 | LLM respondendo em contexto |
| 1.4 | Tool: `create_lead` | Lead salvo no banco após qualificação |
| 1.5 | Tool: `handoff_human` | Transferência para Chatwoot funcionando |
| 1.6 | Logs básicos | Tabela `tool_executions` populada |
| 1.7 | Painel de status | Metabase ou Supabase Studio |

### Fase 2 — Qualificação e Automação (Semanas 4–6)

**Objetivo:** Mais conversão, menos trabalho manual.

| # | Tarefa | Entregável |
|---|--------|-----------|
| 2.1 | Lead Score Flow | Score calculado + alerta automático |
| 2.2 | Tags de intenção | Classificação por fase de compra |
| 2.3 | Respostas condicionais por score | Brann adapta tom e CTA |
| 2.4 | Tool: `schedule_appointment` | Agendamento via fluxo n8n |
| 2.5 | Métricas de atendimento | Dashboard com KPIs básicos |

### Fase 3 — Alfred Operacional (Semanas 7–10)

**Objetivo:** Camada interna forte e muito vendável para B2B.

| # | Tarefa | Entregável |
|---|--------|-----------|
| 3.1 | SQL Agent read-only | Alfred consultando banco do cliente |
| 3.2 | Extraction with Retries | Parser documental com retry automático |
| 3.3 | Tool: `parse_pdf` | PDF → campos estruturados |
| 3.4 | Relatório automático diário | Alfred gerando e enviando resumo |

### Fase 4 — Base Documental Robusta (Semanas 11–14)

**Objetivo:** Agente deixa de ser papagaio e vira operador contextual.

| # | Tarefa | Entregável |
|---|--------|-----------|
| 4.1 | Pipeline de ingestão | Upload → indexação automática |
| 4.2 | RAG básico funcionando | Brann respondendo com base do tenant |
| 4.3 | Citations / evidências | Resposta inclui fonte da informação |
| 4.4 | Adaptive RAG | Decisão automática: buscar vs responder direto |

### Fase 5 — Orquestração (Semanas 15–18)

**Objetivo:** Fluxos compostos entre agentes.

| # | Tarefa | Entregável |
|---|--------|-----------|
| 5.1 | LAPLACE roteador básico | Mensagem → agente correto |
| 5.2 | Agent Supervisor | LAPLACE coordenando Brann + Alfred |
| 5.3 | Fallback inteligente | Rota alternativa quando agente falha |
| 5.4 | Policy engine | Regras de roteamento configuráveis por tenant |

### Fase 6 — Nyra e Expansão (Semanas 19+)

**Objetivo:** Cross-sell e novos pacotes.

| # | Tarefa | Entregável |
|---|--------|-----------|
| 6.1 | Nyra Research Agent MVP | Pesquisa + sumarização |
| 6.2 | Meeting Assistant | Preparação de pauta e resumo pós-reunião |
| 6.3 | Content Pipeline | Rascunho de conteúdo + calendário editorial |
| 6.4 | CRAG / Self-RAG | Para clientes com base ruidosa ou crítica |

---

## 16. Critérios de Aceitação por Entregável

### CA-1: Brann Support Agent

- [ ] Responde mensagem no WhatsApp em menos de 5 segundos
- [ ] Mantém contexto das últimas 10 mensagens da conversa
- [ ] Executa ao menos 1 tool call por sessão quando necessário
- [ ] Log de cada execução salvo em `tool_executions`
- [ ] Handoff acionado corretamente quando trigger detectado
- [ ] Resposta nunca inventa dado não presente na base ou contexto

### CA-2: Lead Score Flow

- [ ] Score calculado em até 3 segundos após mensagem qualificada
- [ ] Score persistido em `lead_scores` com `reason_json`
- [ ] Alerta enviado ao operador quando `score > threshold`
- [ ] Threshold configurável por tenant sem código
- [ ] Log de cada score em `audit_logs`

### CA-3: SQL Agent (Alfred)

- [ ] Aceita query em linguagem natural e gera SQL válido
- [ ] SQL passa por validação antes de executar
- [ ] Modo read-only enforçado por connection string
- [ ] Resultado retornado em formato estruturado
- [ ] Erro de SQL não expõe schema sensível na resposta
- [ ] Limite de linhas retornadas configurável (default: 500)

### CA-4: RAG Básico

- [ ] Ingestão de PDF em menos de 2 minutos para docs até 50 páginas
- [ ] Resposta inclui evidência (chunk + fonte)
- [ ] Busca retorna top-5 chunks relevantes por query
- [ ] `tenant_id` presente em todo chunk indexado
- [ ] Chunk de tenant A nunca retornado para tenant B

### CA-5: Handoff Humano

- [ ] Ticket criado no Chatwoot em menos de 2 segundos
- [ ] Resumo da conversa incluído no ticket
- [ ] Operador notificado via WhatsApp/email
- [ ] Brann envia mensagem de transição ao cliente
- [ ] `conversations.status` atualizado para `handoff`

### CA-6: Pipeline de Ingestão

- [ ] Falha em 1 chunk não bloqueia o restante do documento
- [ ] 3 tentativas com retry antes de marcar como erro
- [ ] Documento com erro notifica responsável do tenant
- [ ] Metadata completa em 100% dos chunks
- [ ] Reindexação possível sem duplicar chunks

---

*Documento vivo. Versão e data devem ser atualizados a cada revisão significativa.*

---

**Ginkgo AI Systems — Documento Interno**  
`ginkgo-core-spec v1.0 — Março 2026`
