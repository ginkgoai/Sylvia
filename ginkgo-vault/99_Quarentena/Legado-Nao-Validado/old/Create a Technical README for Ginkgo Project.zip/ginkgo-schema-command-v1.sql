-- =============================================================================
-- GINKGO AI SYSTEMS — DATABASE SCHEMA v1.0
-- Parte 4: COMMAND ASSISTANT — OpenClaw (Fase 5)
-- Canal: Telegram
-- Motor: OpenClaw
--
-- Depende de:
--   ginkgo-schema-v1.sql              (Fases 1+2)
--   ginkgo-schema-rag-entities-v1.sql (Fase 3 + Entidades Canônicas)
--   ginkgo-schema-leaf-v1.sql         (Fase 4 — Leaf / Brann)
--
-- Engine: Supabase Postgres 15+
-- Schema principal: command
--
-- Responsabilidade deste schema:
--   O Command Assistant é o único ponto de entrada conversacional unificado
--   para os operadores e owners do tenant. Ele NÃO substitui o Brann —
--   ele ORQUESTRA todos os agentes e dados da plataforma via Tool Registry.
--   Toda ação executada passa por Policy Engine antes de acontecer.
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS command;


-- =============================================================================
-- TYPES / ENUMS
-- =============================================================================

CREATE TYPE command.session_status AS ENUM (
    'active',
    'idle',       -- inativo há mais de 10 min mas ainda válido
    'expired',
    'closed'
);

CREATE TYPE command.session_channel AS ENUM (
    'telegram',
    'dashboard',  -- chat embutido no dashboard web
    'api'         -- acesso via API key (developer / integração)
);

CREATE TYPE command.tool_category AS ENUM (
    'read',        -- apenas leitura — baixo risco
    'write',       -- cria ou modifica dados — risco médio
    'action',      -- executa ação externa (API call, webhook) — risco alto
    'delegation',  -- delega para outro agente — risco médio
    'admin'        -- ação administrativa no tenant — risco muito alto
);

CREATE TYPE command.tool_status AS ENUM (
    'active',
    'deprecated',
    'disabled'
);

CREATE TYPE command.call_status AS ENUM (
    'pending',        -- aguardando aprovação (se required)
    'approved',       -- aprovado por operador
    'rejected',       -- rejeitado por operador
    'executing',
    'completed',
    'failed',
    'cancelled'
);

CREATE TYPE command.policy_action AS ENUM (
    'allow',          -- executa diretamente
    'require_approval', -- pausa e pede confirmação ao usuário
    'deny',           -- bloqueia e explica
    'log_only'        -- executa mas registra com flag de auditoria
);

CREATE TYPE command.delegation_status AS ENUM (
    'queued',
    'running',
    'completed',
    'failed',
    'cancelled'
);


-- =============================================================================
-- C1. TOOL REGISTRY
-- Catálogo de todas as ferramentas disponíveis no Command Assistant.
-- Cada tool é uma função que o OpenClaw pode chamar.
-- Definido globalmente, filtrado por entitlement no runtime.
-- =============================================================================

CREATE TABLE command.tool_registry (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    -- Identificação
    name            TEXT UNIQUE NOT NULL,          -- ex: 'list_orders'
    display_name    TEXT NOT NULL,                 -- ex: 'Listar Pedidos'
    description     TEXT NOT NULL,                -- descrita para o LLM no system prompt
    category        command.tool_category NOT NULL,
    status          command.tool_status NOT NULL DEFAULT 'active',
    -- Skill requisitada para usar esta tool
    required_skill  ginkgo.skill_key,             -- NULL = disponível para todos
    -- Roles mínimas que podem invocar
    min_role        ginkgo.member_role NOT NULL DEFAULT 'operator',
    -- Schema de input/output (JSON Schema para validação)
    input_schema    JSONB NOT NULL DEFAULT '{}',
    output_schema   JSONB NOT NULL DEFAULT '{}',
    -- Exemplos para o LLM (few-shot)
    examples        JSONB NOT NULL DEFAULT '[]',
    -- Rate limiting
    rate_limit_per_min INTEGER,                   -- NULL = sem limite
    rate_limit_per_hour INTEGER,
    -- Custo em tokens de billing (para metering)
    billing_cost    INTEGER NOT NULL DEFAULT 0,   -- tokens por chamada
    -- Versão
    version         TEXT NOT NULL DEFAULT '1.0.0',
    -- Handler (como o backend executa)
    handler_type    TEXT NOT NULL DEFAULT 'internal', -- 'internal' | 'n8n' | 'webhook' | 'agent'
    handler_config  JSONB NOT NULL DEFAULT '{}',
    -- Flags
    is_destructive  BOOLEAN NOT NULL DEFAULT false, -- modifica estado irreversivelmente
    requires_confirmation BOOLEAN NOT NULL DEFAULT false,
    -- Documentação
    docs_url        TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_tools_category  ON command.tool_registry (category);
CREATE INDEX idx_tools_skill     ON command.tool_registry (required_skill);
CREATE INDEX idx_tools_status    ON command.tool_registry (status);

SELECT ginkgo.create_updated_at_trigger('command', 'tool_registry');

-- Tool registry: leitura para todos os membros autenticados
ALTER TABLE command.tool_registry ENABLE ROW LEVEL SECURITY;
CREATE POLICY tools_read ON command.tool_registry
    FOR SELECT USING (status = 'active');


-- =============================================================================
-- C2. SEED — TOOLS INICIAIS DO OPENCLAW
-- As 8 tools do MVP (5 leitura + 3 ação segura)
-- =============================================================================

INSERT INTO command.tool_registry
    (name, display_name, description, category, required_skill, min_role,
     billing_cost, input_schema, examples)
VALUES

-- ── READ TOOLS ──────────────────────────────────────────────────────────────

(
    'search_knowledge',
    'Buscar Conhecimento',
    'Busca no RAG empresarial do tenant. Use para responder perguntas sobre produtos, processos, documentos internos, histórico da empresa.',
    'read', NULL, 'viewer', 5,
    '{"type":"object","properties":{"query":{"type":"string","description":"Pergunta ou termo a buscar"},"asset_types":{"type":"array","items":{"type":"string"}},"limit":{"type":"integer","default":6}},"required":["query"]}',
    '[{"user":"Quais são os preços dos nossos serviços?","tool_call":{"query":"preços serviços tabela"}}]'
),

(
    'list_orders',
    'Listar Pedidos',
    'Lista pedidos recentes do tenant. Filtre por status, cliente, período ou valor.',
    'read', 'leaf', 'operator', 2,
    '{"type":"object","properties":{"status":{"type":"string","enum":["pending","confirmed","processing","shipped","delivered","cancelled","refunded"]},"customer_id":{"type":"string"},"limit":{"type":"integer","default":10,"maximum":50},"days_back":{"type":"integer","default":7}}}',
    '[{"user":"Quais pedidos estão pendentes hoje?","tool_call":{"status":"pending","days_back":1}}]'
),

(
    'get_customer',
    'Buscar Cliente',
    'Busca um cliente por nome, email, telefone ou ID. Retorna histórico de pedidos e dados de contato.',
    'read', NULL, 'operator', 2,
    '{"type":"object","properties":{"query":{"type":"string","description":"Nome, email ou telefone do cliente"},"include_orders":{"type":"boolean","default":true}},"required":["query"]}',
    '[{"user":"Me mostra os dados do cliente João Silva","tool_call":{"query":"João Silva","include_orders":true}}]'
),

(
    'get_integration_status',
    'Status das Integrações',
    'Verifica status de todas as integrações ativas do tenant: última sincronização, erros, volume de dados.',
    'read', NULL, 'operator', 1,
    '{"type":"object","properties":{"provider":{"type":"string","description":"Filtrar por provider específico (opcional)"}}}',
    '[{"user":"O Shopify está sincronizando corretamente?","tool_call":{"provider":"shopify"}}]'
),

(
    'get_usage_report',
    'Relatório de Uso',
    'Mostra consumo de tokens, storage e integrações do tenant no período. Inclui previsão de custo.',
    'read', NULL, 'admin', 1,
    '{"type":"object","properties":{"period_days":{"type":"integer","default":30},"breakdown":{"type":"string","enum":["daily","weekly","monthly"],"default":"daily"}}}',
    '[{"user":"Quanto estamos gastando em tokens este mês?","tool_call":{"period_days":30,"breakdown":"weekly"}}]'
),

-- ── WRITE / ACTION TOOLS ─────────────────────────────────────────────────────

(
    'create_task',
    'Criar Tarefa',
    'Cria uma nova tarefa no sistema. Pode ser sincronizada com ClickUp ou Trello se a integração estiver ativa.',
    'write', 'wave', 'operator', 3,
    '{"type":"object","properties":{"title":{"type":"string"},"description":{"type":"string"},"priority":{"type":"string","enum":["urgent","high","medium","low"],"default":"medium"},"due_date":{"type":"string","format":"date-time"},"assigned_to_email":{"type":"string"},"tags":{"type":"array","items":{"type":"string"}}},"required":["title"]}',
    '[{"user":"Cria uma tarefa urgente para ligar pro cliente Carlos amanhã","tool_call":{"title":"Ligar para Carlos","priority":"urgent","due_date":"2026-03-13T10:00:00Z"}}]'
),

(
    'trigger_sync',
    'Disparar Sincronização',
    'Força uma sincronização imediata de uma integração específica. Use quando os dados parecerem desatualizados.',
    'action', NULL, 'admin', 5,
    '{"type":"object","properties":{"provider":{"type":"string","description":"Provider a sincronizar"},"entity_type":{"type":"string","description":"Tipo de entidade (opcional): orders, contacts, products"}},"required":["provider"]}',
    '[{"user":"Força sync do Shopify agora","tool_call":{"provider":"shopify"}}]'
),

(
    'delegate_to_agent',
    'Delegar para Agente',
    'Delega uma tarefa específica para Brann, Nyra ou Alfred. Use quando a tarefa é especializada para um módulo.',
    'delegation', NULL, 'operator', 10,
    '{"type":"object","properties":{"agent":{"type":"string","enum":["brann","nyra","alfred"]},"task":{"type":"string","description":"Descrição completa da tarefa a ser executada pelo agente"},"context":{"type":"object","description":"Dados de contexto relevantes para o agente"}},"required":["agent","task"]}',
    '[{"user":"Pede pro Nyra criar um post para o Instagram sobre nossa promoção","tool_call":{"agent":"nyra","task":"Criar post Instagram sobre promoção de fim de ano"}}]'
);


-- =============================================================================
-- C3. RUNTIME POLICIES
-- Define o comportamento do Policy Engine para cada tool/role/contexto.
-- Avaliada antes de cada tool_call.
-- Ordem de avaliação: específica > por categoria > default
-- =============================================================================

CREATE TABLE command.runtime_policies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    -- NULL = política global (aplicada a todos os tenants sem política específica)
    -- Escopo da política
    scope           TEXT NOT NULL DEFAULT 'global',
    -- 'global' | 'category' | 'tool' | 'role'
    -- Seletores (pelo menos um deve ser preenchido)
    tool_name       TEXT REFERENCES command.tool_registry (name) ON DELETE CASCADE,
    category        command.tool_category,
    role            ginkgo.member_role,
    -- Ação
    policy_action   command.policy_action NOT NULL DEFAULT 'allow',
    -- Mensagem exibida ao usuário quando deny ou require_approval
    message         TEXT,
    -- Condições extras (avaliadas em runtime)
    -- Ex: {"max_amount": 10000} para bloquear ações acima de R$10k
    conditions      JSONB NOT NULL DEFAULT '{}',
    -- Prioridade (maior = avaliado primeiro)
    priority        INTEGER NOT NULL DEFAULT 0,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_policies_tenant   ON command.runtime_policies (tenant_id);
CREATE INDEX idx_policies_tool     ON command.runtime_policies (tool_name);
CREATE INDEX idx_policies_category ON command.runtime_policies (category);
CREATE INDEX idx_policies_role     ON command.runtime_policies (role);
CREATE INDEX idx_policies_active   ON command.runtime_policies (is_active, priority DESC);

SELECT ginkgo.create_updated_at_trigger('command', 'runtime_policies');

ALTER TABLE command.runtime_policies ENABLE ROW LEVEL SECURITY;

CREATE POLICY policies_tenant ON command.runtime_policies
    USING (
        tenant_id IS NULL OR
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C4. SEED — POLÍTICAS DEFAULT GLOBAIS
-- =============================================================================

INSERT INTO command.runtime_policies
    (scope, category, role, policy_action, priority, message)
VALUES
-- Admin tools bloqueados para operators e viewers
(
    'category', NULL, NULL, 'allow', 0, NULL  -- default: tudo permitido
),
(
    'category', 'admin', 'operator', 'deny', 100,
    'Esta ação requer permissão de administrador. Solicite ao owner ou admin do workspace.'
),
(
    'category', 'admin', 'viewer', 'deny', 100,
    'Você tem acesso somente leitura. Esta ação não está disponível para o seu perfil.'
),
-- Write tools: viewer não pode criar/modificar
(
    'category', 'write', 'viewer', 'deny', 90,
    'Seu perfil não permite criar ou modificar registros.'
),
-- Actions destrutivas: require approval para todos
(
    'tool', NULL, NULL, 'require_approval', 80, NULL
)
-- (a linha acima só se aplica quando tool.is_destructive = true, avaliado no runtime)
;

-- Política específica: trigger_sync sempre requer confirmação
INSERT INTO command.runtime_policies
    (scope, tool_name, policy_action, priority, message)
VALUES
(
    'tool', 'trigger_sync', 'require_approval', 200,
    'Confirme que deseja forçar a sincronização agora. Isso consumirá chamadas de API.'
);


-- =============================================================================
-- C5. COMMAND SESSIONS
-- Uma sessão = uma janela de conversa com o OpenClaw.
-- Um usuário pode ter múltiplas sessões em canais diferentes.
-- =============================================================================

CREATE TABLE command.sessions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    profile_id      UUID NOT NULL REFERENCES ginkgo.profiles (id) ON DELETE CASCADE,
    channel         command.session_channel NOT NULL DEFAULT 'telegram',
    status          command.session_status NOT NULL DEFAULT 'active',
    -- Identificação do canal externo
    external_user_id TEXT,                     -- Telegram user_id, etc.
    external_chat_id TEXT,                     -- Telegram chat_id
    -- Estado da sessão
    context_summary TEXT,                      -- resumo da conversa atual gerado pelo LLM
    active_agent    TEXT,                      -- se delegando para um agente: 'brann'|'nyra'|'alfred'
    pending_approval_id UUID,                  -- tool_call aguardando aprovação
    -- Configuração
    llm_model       TEXT NOT NULL DEFAULT 'gpt-4o',
    temperature     NUMERIC(3,2) NOT NULL DEFAULT 0.3,  -- menor que Brann: mais factual
    max_tokens      INTEGER NOT NULL DEFAULT 2000,
    -- Métricas
    message_count   INTEGER NOT NULL DEFAULT 0,
    tool_call_count INTEGER NOT NULL DEFAULT 0,
    tokens_used     INTEGER NOT NULL DEFAULT 0,
    -- TTL
    last_activity   TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at      TIMESTAMPTZ NOT NULL DEFAULT now() + INTERVAL '2 hours',
    -- Temporalidade
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at       TIMESTAMPTZ,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_sessions_tenant   ON command.sessions (tenant_id);
CREATE INDEX idx_sessions_profile  ON command.sessions (profile_id);
CREATE INDEX idx_sessions_status   ON command.sessions (status, expires_at);
CREATE INDEX idx_sessions_channel  ON command.sessions (channel, external_user_id);
CREATE INDEX idx_sessions_activity ON command.sessions (last_activity DESC);

SELECT ginkgo.create_updated_at_trigger('command', 'sessions');

ALTER TABLE command.sessions ENABLE ROW LEVEL SECURITY;

-- Usuário vê apenas suas próprias sessões
CREATE POLICY sessions_self ON command.sessions
    USING (
        profile_id = (
            SELECT id FROM ginkgo.profiles WHERE auth_user_id = auth.uid()
        )
    );

-- Admin vê todas as sessões do tenant
CREATE POLICY sessions_admin ON command.sessions
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m.role IN ('owner', 'admin')
        )
    );


-- =============================================================================
-- C6. SESSION MESSAGES
-- Histórico de mensagens da sessão do OpenClaw.
-- Inclui mensagens do usuário, do assistente e resultados de tools.
-- Particionado mensalmente.
-- =============================================================================

CREATE TABLE command.session_messages (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    session_id      UUID NOT NULL REFERENCES command.sessions (id) ON DELETE CASCADE,
    -- Papel na conversa
    role            TEXT NOT NULL,             -- 'user' | 'assistant' | 'tool'
    content         TEXT,                      -- texto da mensagem
    -- Se role = 'tool': resultado da tool call
    tool_call_id    UUID,                      -- referência a command.tool_calls
    tool_result     JSONB,                     -- resultado serializado
    -- Metadados da resposta do assistente
    model           TEXT,
    tokens_used     INTEGER,
    latency_ms      INTEGER,
    -- Flags
    is_hidden       BOOLEAN NOT NULL DEFAULT false, -- não exibe no chat (mensagens internas)
    sent_at         TIMESTAMPTZ NOT NULL DEFAULT now()
)
PARTITION BY RANGE (sent_at);

CREATE TABLE command.session_messages_2025_q1
    PARTITION OF command.session_messages
    FOR VALUES FROM ('2025-01-01') TO ('2025-04-01');
CREATE TABLE command.session_messages_2025_q2
    PARTITION OF command.session_messages
    FOR VALUES FROM ('2025-04-01') TO ('2025-07-01');
CREATE TABLE command.session_messages_2025_q3
    PARTITION OF command.session_messages
    FOR VALUES FROM ('2025-07-01') TO ('2025-10-01');
CREATE TABLE command.session_messages_2025_q4
    PARTITION OF command.session_messages
    FOR VALUES FROM ('2025-10-01') TO ('2026-01-01');
CREATE TABLE command.session_messages_2026_h1
    PARTITION OF command.session_messages
    FOR VALUES FROM ('2026-01-01') TO ('2026-07-01');
CREATE TABLE command.session_messages_2026_h2
    PARTITION OF command.session_messages
    FOR VALUES FROM ('2026-07-01') TO ('2027-01-01');

CREATE INDEX idx_smsgs_session ON command.session_messages (session_id, sent_at ASC);
CREATE INDEX idx_smsgs_tenant  ON command.session_messages (tenant_id, sent_at DESC);

ALTER TABLE command.session_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY smsgs_self ON command.session_messages
    USING (
        session_id IN (
            SELECT id FROM command.sessions
            WHERE profile_id = (
                SELECT id FROM ginkgo.profiles WHERE auth_user_id = auth.uid()
            )
        )
    );

-- Trigger: atualiza métricas da sessão
CREATE OR REPLACE FUNCTION command.sync_session_metrics()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    UPDATE command.sessions SET
        message_count  = message_count + 1,
        tokens_used    = tokens_used + COALESCE(NEW.tokens_used, 0),
        last_activity  = NEW.sent_at,
        expires_at     = NEW.sent_at + INTERVAL '2 hours',
        updated_at     = now()
    WHERE id = NEW.session_id;
    RETURN NULL;
END;
$$;

CREATE TRIGGER trg_sync_session_metrics
    AFTER INSERT ON command.session_messages
    FOR EACH ROW EXECUTE FUNCTION command.sync_session_metrics();


-- =============================================================================
-- C7. TOOL CALLS
-- Registro de cada invocação de tool pelo OpenClaw.
-- Inclui inputs, outputs, status, latência e resultado da policy evaluation.
-- Imutável após completion.
-- =============================================================================

CREATE TABLE command.tool_calls (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    session_id      UUID NOT NULL REFERENCES command.sessions (id) ON DELETE CASCADE,
    profile_id      UUID NOT NULL REFERENCES ginkgo.profiles (id) ON DELETE CASCADE,
    tool_name       TEXT NOT NULL REFERENCES command.tool_registry (name),
    -- Policy evaluation
    policy_id       UUID REFERENCES command.runtime_policies (id),
    policy_action   command.policy_action NOT NULL DEFAULT 'allow',
    policy_message  TEXT,
    -- Execução
    status          command.call_status NOT NULL DEFAULT 'executing',
    -- Input/Output
    input_params    JSONB NOT NULL DEFAULT '{}',
    output_result   JSONB,
    output_text     TEXT,                      -- versão legível do resultado para o LLM
    -- Aprovação (quando require_approval)
    approved_by     UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    approved_at     TIMESTAMPTZ,
    rejection_reason TEXT,
    -- Erros
    error_code      TEXT,
    error_message   TEXT,
    -- Métricas
    latency_ms      INTEGER,
    tokens_billed   INTEGER NOT NULL DEFAULT 0,
    -- Delegation (se delegou para agente)
    delegation_id   UUID,                      -- referência a command.agent_delegations
    -- Temporalidade
    requested_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at    TIMESTAMPTZ
)
PARTITION BY RANGE (requested_at);

CREATE TABLE command.tool_calls_2025_q1
    PARTITION OF command.tool_calls
    FOR VALUES FROM ('2025-01-01') TO ('2025-04-01');
CREATE TABLE command.tool_calls_2025_q2
    PARTITION OF command.tool_calls
    FOR VALUES FROM ('2025-04-01') TO ('2025-07-01');
CREATE TABLE command.tool_calls_2025_q3
    PARTITION OF command.tool_calls
    FOR VALUES FROM ('2025-07-01') TO ('2025-10-01');
CREATE TABLE command.tool_calls_2025_q4
    PARTITION OF command.tool_calls
    FOR VALUES FROM ('2025-10-01') TO ('2026-01-01');
CREATE TABLE command.tool_calls_2026_h1
    PARTITION OF command.tool_calls
    FOR VALUES FROM ('2026-01-01') TO ('2026-07-01');
CREATE TABLE command.tool_calls_2026_h2
    PARTITION OF command.tool_calls
    FOR VALUES FROM ('2026-07-01') TO ('2027-01-01');

CREATE INDEX idx_tcalls_session  ON command.tool_calls (session_id, requested_at DESC);
CREATE INDEX idx_tcalls_tenant   ON command.tool_calls (tenant_id, requested_at DESC);
CREATE INDEX idx_tcalls_tool     ON command.tool_calls (tool_name, requested_at DESC);
CREATE INDEX idx_tcalls_status   ON command.tool_calls (status);
CREATE INDEX idx_tcalls_pending  ON command.tool_calls (status, policy_action)
    WHERE status = 'pending';

-- Trigger: incrementa tool_call_count na sessão
CREATE OR REPLACE FUNCTION command.sync_session_tool_count()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    UPDATE command.sessions SET
        tool_call_count = tool_call_count + 1,
        updated_at      = now()
    WHERE id = NEW.session_id;

    -- Registra metering
    PERFORM billing.record_usage(
        NEW.tenant_id,
        'command',
        'ai_tokens',
        NEW.tokens_billed,
        jsonb_build_object('tool', NEW.tool_name, 'call_id', NEW.id)
    );

    RETURN NULL;
END;
$$;

CREATE TRIGGER trg_sync_session_tool_count
    AFTER INSERT ON command.tool_calls
    FOR EACH ROW EXECUTE FUNCTION command.sync_session_tool_count();

-- Sem RLS direta — acesso via session_id (controle já em sessions)
ALTER TABLE command.tool_calls ENABLE ROW LEVEL SECURITY;

CREATE POLICY tcalls_self ON command.tool_calls
    USING (
        profile_id = (
            SELECT id FROM ginkgo.profiles WHERE auth_user_id = auth.uid()
        )
    );

CREATE POLICY tcalls_admin ON command.tool_calls
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m.role IN ('owner', 'admin')
        )
    );


-- =============================================================================
-- C8. AGENT DELEGATIONS
-- Quando OpenClaw delega uma tarefa para Brann, Nyra ou Alfred.
-- Rastreia o ciclo de vida da delegação: do pedido ao resultado.
-- =============================================================================

CREATE TABLE command.agent_delegations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    session_id      UUID NOT NULL REFERENCES command.sessions (id) ON DELETE CASCADE,
    tool_call_id    UUID,                      -- tool_call que originou esta delegação
    -- Destino
    target_agent    ginkgo.skill_key NOT NULL, -- 'leaf' | 'pyre' | 'wave'
    agent_id        UUID REFERENCES agents.instances (id) ON DELETE SET NULL,
    -- Tarefa
    task_description TEXT NOT NULL,
    task_context    JSONB NOT NULL DEFAULT '{}',
    -- Resultado
    status          command.delegation_status NOT NULL DEFAULT 'queued',
    result_summary  TEXT,
    result_data     JSONB,
    -- Erros
    error_message   TEXT,
    -- Métricas
    tokens_used     INTEGER,
    latency_ms      INTEGER,
    -- Temporalidade
    queued_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at      TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_delegations_session ON command.agent_delegations (session_id);
CREATE INDEX idx_delegations_tenant  ON command.agent_delegations (tenant_id);
CREATE INDEX idx_delegations_agent   ON command.agent_delegations (target_agent);
CREATE INDEX idx_delegations_status  ON command.agent_delegations (status);

SELECT ginkgo.create_updated_at_trigger('command', 'agent_delegations');

ALTER TABLE command.agent_delegations ENABLE ROW LEVEL SECURITY;

CREATE POLICY delegations_tenant ON command.agent_delegations
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C9. PENDING APPROVALS
-- Tool calls que o Policy Engine pausou para aprovação do usuário.
-- Exibido no dashboard como "ações pendentes de confirmação".
-- =============================================================================

CREATE TABLE command.pending_approvals (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    tool_call_id    UUID NOT NULL,             -- referência ao tool_call pausado
    session_id      UUID NOT NULL REFERENCES command.sessions (id) ON DELETE CASCADE,
    requested_by    UUID NOT NULL REFERENCES ginkgo.profiles (id) ON DELETE CASCADE,
    -- O que está sendo pedido
    tool_name       TEXT NOT NULL,
    input_params    JSONB NOT NULL DEFAULT '{}',
    risk_summary    TEXT NOT NULL,             -- explicação humana do que será feito
    -- Aprovação
    approved_by     UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    decision        TEXT,                      -- 'approved' | 'rejected'
    decision_note   TEXT,
    decided_at      TIMESTAMPTZ,
    -- TTL — expira se não decidido em X tempo
    expires_at      TIMESTAMPTZ NOT NULL DEFAULT now() + INTERVAL '1 hour',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_approvals_tenant  ON command.pending_approvals (tenant_id);
CREATE INDEX idx_approvals_session ON command.pending_approvals (session_id);
CREATE INDEX idx_approvals_pending ON command.pending_approvals (decision, expires_at)
    WHERE decision IS NULL;

ALTER TABLE command.pending_approvals ENABLE ROW LEVEL SECURITY;

CREATE POLICY approvals_tenant ON command.pending_approvals
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- C10. OPENCLAW CONFIG
-- Configuração do Command Assistant por tenant.
-- Análogo ao brann_config no Leaf.
-- =============================================================================

CREATE TABLE command.openclaw_config (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL UNIQUE
                                REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    -- Canais habilitados
    telegram_enabled        BOOLEAN NOT NULL DEFAULT true,
    telegram_bot_token      BYTEA,             -- criptografado
    telegram_allowed_ids    BIGINT[],          -- Telegram user_ids permitidos (NULL = todos os membros)
    dashboard_enabled       BOOLEAN NOT NULL DEFAULT true,
    api_enabled             BOOLEAN NOT NULL DEFAULT false,
    -- LLM
    llm_model               TEXT NOT NULL DEFAULT 'gpt-4o',
    temperature             NUMERIC(3,2) NOT NULL DEFAULT 0.3,
    max_tokens              INTEGER NOT NULL DEFAULT 2000,
    -- Contexto
    max_history_messages    INTEGER NOT NULL DEFAULT 15,
    context_window_tokens   INTEGER NOT NULL DEFAULT 12000,
    -- Sistema
    system_prompt_extra     TEXT,              -- instruções adicionais ao system prompt base
    -- Aprovações
    auto_approve_reads      BOOLEAN NOT NULL DEFAULT true,
    approval_timeout_minutes INTEGER NOT NULL DEFAULT 60,
    -- Notificações
    notify_on_pending       BOOLEAN NOT NULL DEFAULT true,
    notify_on_error         BOOLEAN NOT NULL DEFAULT true,
    -- Limites
    max_tool_calls_per_turn INTEGER NOT NULL DEFAULT 5,
    max_delegations_per_session INTEGER NOT NULL DEFAULT 10,
    -- Configurações extras
    extra_config            JSONB NOT NULL DEFAULT '{}',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

SELECT ginkgo.create_updated_at_trigger('command', 'openclaw_config');

ALTER TABLE command.openclaw_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY openclaw_cfg_read ON command.openclaw_config
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );

CREATE POLICY openclaw_cfg_edit ON command.openclaw_config
    FOR UPDATE
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m.role IN ('owner', 'admin')
        )
    );


-- =============================================================================
-- C11. FUNCTIONS — Core do Policy Engine
-- =============================================================================

-- Avalia qual política se aplica a uma tool_call antes de executar
-- Retorna: policy_action, policy_id, message
CREATE OR REPLACE FUNCTION command.evaluate_policy(
    p_tenant_id  UUID,
    p_tool_name  TEXT,
    p_role       ginkgo.member_role
)
RETURNS TABLE (
    policy_action   command.policy_action,
    policy_id       UUID,
    message         TEXT
)
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    -- Avalia em ordem de prioridade decrescente
    -- 1. Política específica de tool + tenant
    -- 2. Política de tool global
    -- 3. Política de categoria + role
    -- 4. Default: allow
    RETURN QUERY
    SELECT
        rp.policy_action,
        rp.id,
        rp.message
    FROM command.runtime_policies rp
    WHERE rp.is_active = true
      AND (rp.tenant_id = p_tenant_id OR rp.tenant_id IS NULL)
      AND (
            (rp.scope = 'tool'     AND rp.tool_name = p_tool_name)
         OR (rp.scope = 'category' AND rp.category = (
                SELECT category FROM command.tool_registry WHERE name = p_tool_name
             )
             AND (rp.role IS NULL OR rp.role = p_role))
         OR (rp.scope = 'role'    AND rp.role = p_role)
         OR (rp.scope = 'global')
      )
    ORDER BY
        -- tenant-specific > global
        (rp.tenant_id IS NOT NULL) DESC,
        -- tool-specific > category > role > global
        CASE rp.scope
            WHEN 'tool'     THEN 4
            WHEN 'category' THEN 3
            WHEN 'role'     THEN 2
            ELSE 1
        END DESC,
        rp.priority DESC
    LIMIT 1;

    -- Se nenhuma policy encontrada: allow por default
    IF NOT FOUND THEN
        RETURN QUERY SELECT 'allow'::command.policy_action, NULL::UUID, NULL::TEXT;
    END IF;
END;
$$;

-- Cria ou recupera sessão ativa para um usuário/canal
CREATE OR REPLACE FUNCTION command.get_or_create_session(
    p_tenant_id      UUID,
    p_profile_id     UUID,
    p_channel        command.session_channel DEFAULT 'telegram',
    p_external_user  TEXT DEFAULT NULL,
    p_external_chat  TEXT DEFAULT NULL
)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_session_id UUID;
BEGIN
    -- Sessão ativa existente
    SELECT id INTO v_session_id
    FROM command.sessions
    WHERE tenant_id  = p_tenant_id
      AND profile_id = p_profile_id
      AND channel    = p_channel
      AND status     IN ('active', 'idle')
      AND expires_at > now()
    ORDER BY last_activity DESC
    LIMIT 1;

    IF v_session_id IS NULL THEN
        INSERT INTO command.sessions (
            tenant_id, profile_id, channel,
            external_user_id, external_chat_id
        ) VALUES (
            p_tenant_id, p_profile_id, p_channel,
            p_external_user, p_external_chat
        )
        RETURNING id INTO v_session_id;
    END IF;

    RETURN v_session_id;
END;
$$;

-- Registra tool_call com policy evaluation automática
CREATE OR REPLACE FUNCTION command.record_tool_call(
    p_session_id    UUID,
    p_profile_id    UUID,
    p_tenant_id     UUID,
    p_tool_name     TEXT,
    p_input_params  JSONB,
    p_role          ginkgo.member_role
)
RETURNS TABLE (
    tool_call_id    UUID,
    policy_action   command.policy_action,
    policy_message  TEXT
)
LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_policy        RECORD;
    v_call_id       UUID;
    v_initial_status command.call_status;
BEGIN
    -- Avalia policy
    SELECT * INTO v_policy
    FROM command.evaluate_policy(p_tenant_id, p_tool_name, p_role);

    -- Define status inicial baseado na policy
    v_initial_status := CASE v_policy.policy_action
        WHEN 'allow'            THEN 'executing'::command.call_status
        WHEN 'require_approval' THEN 'pending'::command.call_status
        WHEN 'deny'             THEN 'rejected'::command.call_status
        WHEN 'log_only'         THEN 'executing'::command.call_status
    END;

    -- Insere tool_call
    INSERT INTO command.tool_calls (
        tenant_id, session_id, profile_id,
        tool_name, policy_id, policy_action, policy_message,
        status, input_params
    ) VALUES (
        p_tenant_id, p_session_id, p_profile_id,
        p_tool_name, v_policy.policy_id, v_policy.policy_action,
        v_policy.message, v_initial_status, p_input_params
    )
    RETURNING id INTO v_call_id;

    -- Se require_approval: cria pending_approval
    IF v_policy.policy_action = 'require_approval' THEN
        INSERT INTO command.pending_approvals (
            tenant_id, tool_call_id, session_id, requested_by,
            tool_name, input_params, risk_summary
        ) VALUES (
            p_tenant_id, v_call_id, p_session_id, p_profile_id,
            p_tool_name, p_input_params,
            COALESCE(v_policy.message, 'Esta ação requer sua confirmação antes de ser executada.')
        );
    END IF;

    RETURN QUERY SELECT v_call_id, v_policy.policy_action, v_policy.message;
END;
$$;


-- =============================================================================
-- C12. VIEWS — Dashboard do Command Assistant
-- =============================================================================

-- Visão geral de uso do OpenClaw por tenant
CREATE VIEW command.usage_overview AS
SELECT
    s.tenant_id,
    COUNT(DISTINCT s.id)                AS total_sessions,
    COUNT(DISTINCT s.id) FILTER (WHERE s.status IN ('active','idle')) AS active_sessions,
    SUM(s.message_count)                AS total_messages,
    SUM(s.tool_call_count)              AS total_tool_calls,
    SUM(s.tokens_used)                  AS total_tokens,
    ROUND(AVG(s.tool_call_count)::NUMERIC, 1) AS avg_tools_per_session,
    COUNT(DISTINCT s.profile_id)        AS unique_users
FROM command.sessions s
WHERE s.started_at >= now() - INTERVAL '30 days'
GROUP BY s.tenant_id;

-- Tool calls mais frequentes por tenant
CREATE VIEW command.top_tools AS
SELECT
    tc.tenant_id,
    tc.tool_name,
    COUNT(*)                                            AS total_calls,
    COUNT(*) FILTER (WHERE tc.status = 'completed')    AS successful,
    COUNT(*) FILTER (WHERE tc.status = 'failed')       AS failed,
    COUNT(*) FILTER (WHERE tc.status = 'rejected')     AS rejected,
    ROUND(AVG(tc.latency_ms)::NUMERIC, 0)              AS avg_latency_ms,
    SUM(tc.tokens_billed)                              AS tokens_billed
FROM command.tool_calls tc
WHERE tc.requested_at >= now() - INTERVAL '30 days'
GROUP BY tc.tenant_id, tc.tool_name
ORDER BY total_calls DESC;

-- Aprovações pendentes (exibidas no dashboard como alerta)
CREATE VIEW command.approvals_pending AS
SELECT
    pa.id          AS approval_id,
    pa.tenant_id,
    pa.tool_name,
    pa.input_params,
    pa.risk_summary,
    pa.expires_at,
    pa.created_at  AS requested_at,
    pr.full_name   AS requested_by_name,
    pr.email       AS requested_by_email,
    s.channel
FROM command.pending_approvals pa
JOIN ginkgo.profiles pr ON pr.id = pa.requested_by
JOIN command.sessions s ON s.id = pa.session_id
WHERE pa.decision IS NULL
  AND pa.expires_at > now()
ORDER BY pa.created_at ASC;

-- Histórico de delegações por agente
CREATE VIEW command.delegation_summary AS
SELECT
    d.tenant_id,
    d.target_agent,
    COUNT(*)                                                    AS total,
    COUNT(*) FILTER (WHERE d.status = 'completed')             AS completed,
    COUNT(*) FILTER (WHERE d.status = 'failed')                AS failed,
    ROUND(AVG(d.latency_ms) FILTER (WHERE d.status = 'completed')::NUMERIC, 0) AS avg_latency_ms
FROM command.agent_delegations d
WHERE d.created_at >= now() - INTERVAL '30 days'
GROUP BY d.tenant_id, d.target_agent;


-- =============================================================================
-- C13. VIEW UNIFICADA — Tenant Command Center
-- Agrega tudo que o OpenClaw precisa ao iniciar uma sessão:
-- entitlements ativos, integrações, configuração, saldo de tokens
-- =============================================================================

CREATE VIEW command.tenant_command_center AS
SELECT
    t.id                    AS tenant_id,
    t.name                  AS tenant_name,
    t.locale,
    t.timezone,
    -- Assinatura
    p.code                  AS plan_code,
    s.status                AS subscription_status,
    -- Skills ativas
    array_agg(DISTINCT e.skill_key::TEXT)
        FILTER (WHERE e.status = 'active')  AS active_skills,
    -- Integrações conectadas
    array_agg(DISTINCT ia.provider::TEXT)
        FILTER (WHERE ia.status = 'active') AS connected_providers,
    -- Saldo de tokens
    (SELECT tb.current_balance FROM billing.token_balance tb
     WHERE tb.tenant_id = t.id)             AS token_balance,
    -- Configuração do OpenClaw
    oc.llm_model,
    oc.max_tool_calls_per_turn,
    oc.telegram_enabled,
    oc.dashboard_enabled
FROM ginkgo.tenants t
LEFT JOIN billing.subscriptions s       ON s.tenant_id = t.id
LEFT JOIN billing.plans p               ON p.id = s.plan_id
LEFT JOIN ginkgo.module_entitlements e  ON e.tenant_id = t.id
LEFT JOIN integrations.accounts ia      ON ia.tenant_id = t.id
LEFT JOIN command.openclaw_config oc    ON oc.tenant_id = t.id
GROUP BY t.id, t.name, t.locale, t.timezone,
         p.code, s.status,
         oc.llm_model, oc.max_tool_calls_per_turn,
         oc.telegram_enabled, oc.dashboard_enabled;


-- =============================================================================
-- FIM — ginkgo-schema-command-v1.sql
--
-- Tabelas:  tool_registry, runtime_policies, sessions, session_messages,
--           tool_calls, agent_delegations, pending_approvals, openclaw_config
-- Functions: evaluate_policy, get_or_create_session, record_tool_call
-- Views:    usage_overview, top_tools, approvals_pending,
--           delegation_summary, tenant_command_center
-- Seeds:    8 tools iniciais, políticas default globais
--
-- ─────────────────────────────────────────────────────────────────────────────
-- SCHEMA COMPLETO DA GINKGO AI SYSTEMS v1.0
-- ─────────────────────────────────────────────────────────────────────────────
-- Ordem de execução no Supabase:
--
--   1. ginkgo-schema-v1.sql              → Fundação + Billing + Agents templates
--   2. ginkgo-schema-rag-entities-v1.sql → RAG Core + Entidades Canônicas
--   3. ginkgo-schema-leaf-v1.sql         → Leaf / Brann
--   4. ginkgo-schema-command-v1.sql      → Command / OpenClaw  ← este arquivo
--
-- Próximos schemas (Fase 6):
--   ginkgo-schema-pyre-v1.sql  → Pyre / Nyra (conteúdo, campanhas, calendário)
--   ginkgo-schema-wave-v1.sql  → Wave / Alfred (relatórios, analytics, ClickUp sync)
-- =============================================================================
