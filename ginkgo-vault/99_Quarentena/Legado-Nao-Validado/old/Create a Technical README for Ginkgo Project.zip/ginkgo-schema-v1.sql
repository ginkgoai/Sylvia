-- =============================================================================
-- GINKGO AI SYSTEMS — DATABASE SCHEMA v1.0
-- Fases 1 + 2: Fundação Multi-Tenant + Núcleo de Plataforma
--
-- Engine: Supabase Postgres 15+
-- Extensions: pgcrypto, pgvector, pg_trgm, uuid-ossp
-- Padrão: snake_case, tenant_id em todas as tabelas de dados,
--         RLS habilitado em todas as tabelas sensíveis,
--         updated_at gerenciado por trigger automático.
-- =============================================================================


-- =============================================================================
-- 0. EXTENSIONS
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "vector";           -- pgvector


-- =============================================================================
-- 1. SCHEMAS
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS ginkgo;          -- domínio principal
CREATE SCHEMA IF NOT EXISTS billing;         -- billing & metering isolados
CREATE SCHEMA IF NOT EXISTS rag;             -- RAG / memória empresarial
CREATE SCHEMA IF NOT EXISTS integrations;    -- integrações externas
CREATE SCHEMA IF NOT EXISTS agents;          -- runtime de agentes


-- =============================================================================
-- 2. TYPES / ENUMS
-- =============================================================================

-- ─── Platform Core ───────────────────────────────────────────────────────────

CREATE TYPE ginkgo.tenant_status AS ENUM (
    'provisioning',   -- sendo criado
    'active',         -- operacional
    'suspended',      -- pagamento pendente / violação
    'cancelled'       -- encerrado
);

CREATE TYPE ginkgo.member_role AS ENUM (
    'owner',          -- criador do tenant, não removível
    'admin',          -- acesso total ao tenant
    'operator',       -- acesso operacional (agentes, conversas, tarefas)
    'viewer'          -- somente leitura
);

CREATE TYPE ginkgo.invite_status AS ENUM (
    'pending',
    'accepted',
    'expired',
    'revoked'
);

CREATE TYPE ginkgo.plan_interval AS ENUM (
    'monthly',
    'annual'
);

CREATE TYPE ginkgo.subscription_status AS ENUM (
    'trialing',
    'active',
    'past_due',
    'cancelled',
    'paused'
);

CREATE TYPE ginkgo.skill_key AS ENUM (
    'leaf',           -- Brann — atendimento
    'pyre',           -- Nyra — conteúdo e marketing
    'wave',           -- Alfred — operação e gestão
    'command',        -- OpenClaw — unified assistant
    'ecommerce',      -- inteligência de e-commerce
    'analytics',      -- analytics avançado
    'email_mkt'       -- email marketing
);

CREATE TYPE ginkgo.entitlement_status AS ENUM (
    'active',
    'suspended',
    'expired'
);

-- ─── Billing ─────────────────────────────────────────────────────────────────

CREATE TYPE billing.usage_metric AS ENUM (
    'ai_tokens',
    'storage_bytes',
    'integration_calls',
    'media_processing_seconds',
    'sync_jobs'
);

CREATE TYPE billing.invoice_status AS ENUM (
    'draft',
    'open',
    'paid',
    'void',
    'uncollectible'
);

CREATE TYPE billing.overage_action AS ENUM (
    'charge',         -- cobrar automaticamente
    'warn',           -- alertar, não bloquear
    'block'           -- bloquear consumo excedente
);

-- ─── Integrations ────────────────────────────────────────────────────────────

CREATE TYPE integrations.provider AS ENUM (
    -- atendimento
    'whatsapp', 'instagram', 'telegram', 'chatwoot', 'email',
    -- operação
    'clickup', 'trello', 'notion',
    -- documentos
    'google_drive', 'google_docs', 'google_sheets', 'google_photos', 'gmail',
    -- e-commerce
    'shopify', 'shopee', 'aliexpress', 'mercado_livre',
    -- marketing
    'meta_ads', 'google_ads', 'tiktok_ads',
    -- financeiro
    'stripe', 'asaas', 'mercado_pago',
    -- CRM
    'hubspot', 'pipedrive'
);

CREATE TYPE integrations.sync_status AS ENUM (
    'idle',
    'queued',
    'running',
    'completed',
    'failed',
    'cancelled'
);

CREATE TYPE integrations.sync_direction AS ENUM (
    'inbound',        -- API externa → Ginkgo
    'outbound',       -- Ginkgo → API externa
    'bidirectional'
);

-- ─── Agents ──────────────────────────────────────────────────────────────────

CREATE TYPE agents.agent_status AS ENUM (
    'inactive',
    'active',
    'paused',
    'error'
);

CREATE TYPE agents.session_status AS ENUM (
    'open',
    'handoff',        -- transferido para humano
    'closed',
    'expired'
);

-- ─── RAG ─────────────────────────────────────────────────────────────────────

CREATE TYPE rag.asset_type AS ENUM (
    'document',       -- PDF, DOCX, TXT
    'spreadsheet',    -- XLSX, CSV
    'presentation',   -- PPTX
    'image',
    'audio',
    'video',
    'webpage',
    'integration_dump'-- export de integração
);

CREATE TYPE rag.asset_status AS ENUM (
    'uploaded',
    'extracting',
    'chunking',
    'embedding',
    'indexed',
    'failed',
    'stale'           -- precisa reindexar
);


-- =============================================================================
-- 3. HELPER FUNCTIONS
-- =============================================================================

-- Atualiza updated_at automaticamente em qualquer tabela
CREATE OR REPLACE FUNCTION ginkgo.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

-- Registra usage_event genérico (chamado por workers via Postgres RPC)
CREATE OR REPLACE FUNCTION billing.record_usage(
    p_tenant_id   UUID,
    p_skill_key   TEXT,
    p_metric      billing.usage_metric,
    p_quantity    NUMERIC,
    p_metadata    JSONB DEFAULT '{}'
)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO billing.usage_events (
        id, tenant_id, skill_key, metric, quantity, metadata
    ) VALUES (
        v_id, p_tenant_id, p_skill_key, p_metric, p_quantity, p_metadata
    );
    RETURN v_id;
END;
$$;

-- Macro para criar trigger de updated_at numa tabela
CREATE OR REPLACE FUNCTION ginkgo.create_updated_at_trigger(
    p_schema TEXT,
    p_table  TEXT
)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
    EXECUTE format(
        'CREATE TRIGGER trg_set_updated_at
         BEFORE UPDATE ON %I.%I
         FOR EACH ROW EXECUTE FUNCTION ginkgo.set_updated_at()',
        p_schema, p_table
    );
END;
$$;


-- =============================================================================
-- FASE 1 — FUNDAÇÃO MULTI-TENANT
-- =============================================================================


-- =============================================================================
-- 4. PROFILES (espelho público dos auth.users do Supabase)
-- =============================================================================

CREATE TABLE ginkgo.profiles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auth_user_id    UUID UNIQUE NOT NULL,  -- referência a auth.users.id (Supabase)
    email           TEXT NOT NULL,
    full_name       TEXT,
    avatar_url      TEXT,
    locale          TEXT NOT NULL DEFAULT 'pt-BR',
    timezone        TEXT NOT NULL DEFAULT 'America/Sao_Paulo',
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_profiles_auth_user ON ginkgo.profiles (auth_user_id);
CREATE INDEX idx_profiles_email     ON ginkgo.profiles (email);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'profiles');

ALTER TABLE ginkgo.profiles ENABLE ROW LEVEL SECURITY;

-- Usuário vê e edita apenas o próprio perfil
CREATE POLICY profiles_self ON ginkgo.profiles
    USING (auth_user_id = auth.uid());


-- =============================================================================
-- 5. TENANTS
-- =============================================================================

CREATE TABLE ginkgo.tenants (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug            TEXT UNIQUE NOT NULL,          -- ex: "gtech-automatiza"
    name            TEXT NOT NULL,
    logo_url        TEXT,
    status          ginkgo.tenant_status NOT NULL DEFAULT 'provisioning',
    locale          TEXT NOT NULL DEFAULT 'pt-BR',
    timezone        TEXT NOT NULL DEFAULT 'America/Sao_Paulo',
    industry        TEXT,                          -- setor da empresa
    website         TEXT,
    settings        JSONB NOT NULL DEFAULT '{}',   -- configurações livres por tenant
    metadata        JSONB NOT NULL DEFAULT '{}',
    provisioned_at  TIMESTAMPTZ,                   -- quando ficou active pela 1ª vez
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_tenants_slug   ON ginkgo.tenants (slug);
CREATE INDEX idx_tenants_status ON ginkgo.tenants (status);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'tenants');

ALTER TABLE ginkgo.tenants ENABLE ROW LEVEL SECURITY;

-- Tenant visível apenas para membros
CREATE POLICY tenants_member ON ginkgo.tenants
    USING (
        id IN (
            SELECT tenant_id FROM ginkgo.memberships
            WHERE profile_id = (
                SELECT id FROM ginkgo.profiles WHERE auth_user_id = auth.uid()
            )
        )
    );


-- =============================================================================
-- 6. MEMBERSHIPS (usuário ↔ tenant)
-- =============================================================================

CREATE TABLE ginkgo.memberships (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    profile_id  UUID NOT NULL REFERENCES ginkgo.profiles (id) ON DELETE CASCADE,
    role        ginkgo.member_role NOT NULL DEFAULT 'operator',
    is_primary  BOOLEAN NOT NULL DEFAULT false, -- tenant padrão do usuário
    joined_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, profile_id)
);

CREATE INDEX idx_memberships_tenant  ON ginkgo.memberships (tenant_id);
CREATE INDEX idx_memberships_profile ON ginkgo.memberships (profile_id);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'memberships');

ALTER TABLE ginkgo.memberships ENABLE ROW LEVEL SECURITY;

-- Membro vê apenas suas próprias memberships
CREATE POLICY memberships_self ON ginkgo.memberships
    USING (
        profile_id = (
            SELECT id FROM ginkgo.profiles WHERE auth_user_id = auth.uid()
        )
    );

-- Admin/owner do tenant vê todas as memberships do seu tenant
CREATE POLICY memberships_admin ON ginkgo.memberships
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m2
            JOIN ginkgo.profiles p ON p.id = m2.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m2.role IN ('owner', 'admin')
        )
    );


-- =============================================================================
-- 7. INVITES
-- =============================================================================

CREATE TABLE ginkgo.invites (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    email       TEXT NOT NULL,
    role        ginkgo.member_role NOT NULL DEFAULT 'operator',
    token       TEXT UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(32), 'hex'),
    invited_by  UUID REFERENCES ginkgo.profiles (id),
    status      ginkgo.invite_status NOT NULL DEFAULT 'pending',
    expires_at  TIMESTAMPTZ NOT NULL DEFAULT now() + INTERVAL '7 days',
    accepted_at TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_invites_tenant  ON ginkgo.invites (tenant_id);
CREATE INDEX idx_invites_email   ON ginkgo.invites (email);
CREATE INDEX idx_invites_token   ON ginkgo.invites (token);
CREATE INDEX idx_invites_status  ON ginkgo.invites (status);

ALTER TABLE ginkgo.invites ENABLE ROW LEVEL SECURITY;

-- Admin/owner gerencia convites do seu tenant
CREATE POLICY invites_admin ON ginkgo.invites
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m.role IN ('owner', 'admin')
        )
    );


-- =============================================================================
-- 8. PLANS
-- =============================================================================

CREATE TABLE billing.plans (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code                TEXT UNIQUE NOT NULL,   -- ex: 'starter', 'growth', 'scale'
    name                TEXT NOT NULL,
    description         TEXT,
    interval            ginkgo.plan_interval NOT NULL DEFAULT 'monthly',
    price_cents         INTEGER NOT NULL DEFAULT 0,
    currency            TEXT NOT NULL DEFAULT 'BRL',
    max_users           INTEGER,               -- NULL = ilimitado
    max_storage_gb      INTEGER,
    max_integrations    INTEGER,
    included_ai_tokens  BIGINT NOT NULL DEFAULT 0,
    is_public           BOOLEAN NOT NULL DEFAULT true,
    is_active           BOOLEAN NOT NULL DEFAULT true,
    stripe_price_id     TEXT,
    metadata            JSONB NOT NULL DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_plans_code      ON billing.plans (code);
CREATE INDEX idx_plans_is_active ON billing.plans (is_active);

SELECT ginkgo.create_updated_at_trigger('billing', 'plans');

-- Plans são públicos (leitura), escrita só via service_role
ALTER TABLE billing.plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY plans_read ON billing.plans
    FOR SELECT USING (is_public = true AND is_active = true);


-- =============================================================================
-- 9. SUBSCRIPTIONS
-- =============================================================================

CREATE TABLE billing.subscriptions (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    plan_id             UUID NOT NULL REFERENCES billing.plans (id),
    status              ginkgo.subscription_status NOT NULL DEFAULT 'trialing',
    trial_ends_at       TIMESTAMPTZ,
    current_period_start TIMESTAMPTZ NOT NULL DEFAULT now(),
    current_period_end   TIMESTAMPTZ NOT NULL DEFAULT now() + INTERVAL '30 days',
    cancelled_at        TIMESTAMPTZ,
    cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
    stripe_subscription_id TEXT UNIQUE,
    stripe_customer_id     TEXT,
    metadata            JSONB NOT NULL DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- Apenas uma assinatura ativa por tenant
    UNIQUE (tenant_id)
);

CREATE INDEX idx_subscriptions_tenant ON billing.subscriptions (tenant_id);
CREATE INDEX idx_subscriptions_status ON billing.subscriptions (status);
CREATE INDEX idx_subscriptions_period ON billing.subscriptions (current_period_end);

SELECT ginkgo.create_updated_at_trigger('billing', 'subscriptions');

ALTER TABLE billing.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY subscriptions_tenant ON billing.subscriptions
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- FASE 2 — NÚCLEO DE PLATAFORMA
-- =============================================================================


-- =============================================================================
-- 10. MODULE ENTITLEMENTS (skills ativas por tenant)
-- =============================================================================

CREATE TABLE ginkgo.module_entitlements (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    skill_key   ginkgo.skill_key NOT NULL,
    status      ginkgo.entitlement_status NOT NULL DEFAULT 'active',
    config      JSONB NOT NULL DEFAULT '{}',   -- configuração específica da skill
    activated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at  TIMESTAMPTZ,                   -- NULL = não expira (enquanto pagar)
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, skill_key)
);

CREATE INDEX idx_entitlements_tenant ON ginkgo.module_entitlements (tenant_id);
CREATE INDEX idx_entitlements_skill  ON ginkgo.module_entitlements (skill_key);
CREATE INDEX idx_entitlements_status ON ginkgo.module_entitlements (status);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'module_entitlements');

ALTER TABLE ginkgo.module_entitlements ENABLE ROW LEVEL SECURITY;

CREATE POLICY entitlements_tenant ON ginkgo.module_entitlements
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- 11. INTEGRATIONS (contas de integração por tenant)
-- =============================================================================

CREATE TABLE integrations.accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    provider        integrations.provider NOT NULL,
    display_name    TEXT,
    external_id     TEXT,                      -- ID da conta na plataforma externa
    status          TEXT NOT NULL DEFAULT 'active',
    -- Credenciais sempre criptografadas, NUNCA em texto plano
    credentials     BYTEA,                     -- pgcrypto: encrypt(credentials::text, key)
    oauth_token     BYTEA,
    oauth_refresh   BYTEA,
    oauth_expires_at TIMESTAMPTZ,
    scopes          TEXT[],
    config          JSONB NOT NULL DEFAULT '{}',
    last_synced_at  TIMESTAMPTZ,
    error_message   TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, provider, external_id)
);

CREATE INDEX idx_int_accounts_tenant   ON integrations.accounts (tenant_id);
CREATE INDEX idx_int_accounts_provider ON integrations.accounts (provider);
CREATE INDEX idx_int_accounts_status   ON integrations.accounts (status);

SELECT ginkgo.create_updated_at_trigger('integrations', 'accounts');

ALTER TABLE integrations.accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY int_accounts_tenant ON integrations.accounts
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- 12. INTEGRATION SYNC JOBS
-- =============================================================================

CREATE TABLE integrations.sync_jobs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    account_id      UUID NOT NULL REFERENCES integrations.accounts (id) ON DELETE CASCADE,
    direction       integrations.sync_direction NOT NULL DEFAULT 'inbound',
    status          integrations.sync_status NOT NULL DEFAULT 'queued',
    entity_type     TEXT,                      -- ex: 'orders', 'contacts', 'tasks'
    records_total   INTEGER,
    records_done    INTEGER NOT NULL DEFAULT 0,
    records_failed  INTEGER NOT NULL DEFAULT 0,
    started_at      TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    error_message   TEXT,
    error_detail    JSONB,
    triggered_by    TEXT NOT NULL DEFAULT 'cron', -- 'cron' | 'webhook' | 'manual' | 'event'
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_sync_jobs_tenant    ON integrations.sync_jobs (tenant_id);
CREATE INDEX idx_sync_jobs_account   ON integrations.sync_jobs (account_id);
CREATE INDEX idx_sync_jobs_status    ON integrations.sync_jobs (status);
CREATE INDEX idx_sync_jobs_created   ON integrations.sync_jobs (created_at DESC);

SELECT ginkgo.create_updated_at_trigger('integrations', 'sync_jobs');

ALTER TABLE integrations.sync_jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY sync_jobs_tenant ON integrations.sync_jobs
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- 13. USAGE EVENTS
-- Escrito apenas por workers via service_role. Buffer em Redis → flush periódico.
-- NUNCA escrever em tempo real por request de usuário.
-- =============================================================================

CREATE TABLE billing.usage_events (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    skill_key   TEXT,                          -- skill que gerou o consumo
    metric      billing.usage_metric NOT NULL,
    quantity    NUMERIC NOT NULL,
    period_date DATE NOT NULL DEFAULT CURRENT_DATE,
    metadata    JSONB NOT NULL DEFAULT '{}',   -- ex: model, operation, file_size
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
)
PARTITION BY RANGE (period_date);

-- Partição inicial: 2025
CREATE TABLE billing.usage_events_2025
    PARTITION OF billing.usage_events
    FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');

-- Partição: 2026
CREATE TABLE billing.usage_events_2026
    PARTITION OF billing.usage_events
    FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');

CREATE INDEX idx_usage_events_tenant ON billing.usage_events (tenant_id, period_date DESC);
CREATE INDEX idx_usage_events_metric ON billing.usage_events (metric, period_date DESC);

-- Sem RLS — acesso exclusivo via service_role por workers
-- Leitura para usuários: via views materializadas abaixo


-- =============================================================================
-- 14. USAGE SUMMARY (view materializada — alimenta o dashboard)
-- Atualizada pelo metering worker a cada hora
-- =============================================================================

CREATE MATERIALIZED VIEW billing.usage_summary AS
SELECT
    tenant_id,
    skill_key,
    metric,
    period_date,
    SUM(quantity) AS total_quantity,
    COUNT(*)      AS event_count
FROM billing.usage_events
GROUP BY tenant_id, skill_key, metric, period_date
WITH NO DATA;

CREATE UNIQUE INDEX idx_usage_summary_pk
    ON billing.usage_summary (tenant_id, skill_key, metric, period_date);

CREATE INDEX idx_usage_summary_tenant
    ON billing.usage_summary (tenant_id, period_date DESC);

-- Refresh executado pelo metering worker:
-- REFRESH MATERIALIZED VIEW CONCURRENTLY billing.usage_summary;


-- =============================================================================
-- 15. TOKEN LEDGER
-- Saldo de tokens IA por tenant. Debitado pelos workers de agent/RAG.
-- Crédito vem do provisioning ao ativar/renovar assinatura.
-- =============================================================================

CREATE TABLE billing.token_ledger (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    delta       BIGINT NOT NULL,               -- positivo = crédito, negativo = débito
    balance     BIGINT NOT NULL,               -- saldo acumulado APÓS esta entrada
    description TEXT NOT NULL,
    reference   TEXT,                          -- ex: subscription_id, usage_event_id
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_token_ledger_tenant  ON billing.token_ledger (tenant_id, recorded_at DESC);

-- View do saldo atual por tenant
CREATE VIEW billing.token_balance AS
SELECT
    tenant_id,
    (SELECT balance FROM billing.token_ledger l2
     WHERE l2.tenant_id = l.tenant_id
     ORDER BY recorded_at DESC
     LIMIT 1) AS current_balance,
    now()                                 AS as_of
FROM billing.token_ledger l
GROUP BY tenant_id;

ALTER TABLE billing.token_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY token_ledger_tenant ON billing.token_ledger
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- 16. OVERAGE RULES
-- Define comportamento ao ultrapassar limite do plano
-- =============================================================================

CREATE TABLE billing.overage_rules (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id         UUID NOT NULL REFERENCES billing.plans (id) ON DELETE CASCADE,
    metric          billing.usage_metric NOT NULL,
    action          billing.overage_action NOT NULL DEFAULT 'warn',
    unit_price_cents INTEGER,                  -- centavos BRL por unidade excedente
    grace_percent   NUMERIC NOT NULL DEFAULT 0, -- % de tolerância antes de agir
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (plan_id, metric)
);

SELECT ginkgo.create_updated_at_trigger('billing', 'overage_rules');


-- =============================================================================
-- 17. INVOICES SHADOW
-- Snapshot local de invoices do Stripe para exibição no dashboard sem depender
-- da API do Stripe em tempo real.
-- =============================================================================

CREATE TABLE billing.invoices_shadow (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    subscription_id     UUID REFERENCES billing.subscriptions (id),
    stripe_invoice_id   TEXT UNIQUE NOT NULL,
    status              billing.invoice_status NOT NULL DEFAULT 'draft',
    amount_cents        INTEGER NOT NULL DEFAULT 0,
    currency            TEXT NOT NULL DEFAULT 'BRL',
    period_start        TIMESTAMPTZ,
    period_end          TIMESTAMPTZ,
    paid_at             TIMESTAMPTZ,
    pdf_url             TEXT,
    line_items          JSONB NOT NULL DEFAULT '[]',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_invoices_tenant ON billing.invoices_shadow (tenant_id, created_at DESC);
CREATE INDEX idx_invoices_status ON billing.invoices_shadow (status);

SELECT ginkgo.create_updated_at_trigger('billing', 'invoices_shadow');

ALTER TABLE billing.invoices_shadow ENABLE ROW LEVEL SECURITY;

CREATE POLICY invoices_tenant ON billing.invoices_shadow
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- 18. PROVISIONING JOBS
-- Criados por evento subscription.activated, executados pelo provisioning worker
-- =============================================================================

CREATE TABLE ginkgo.provisioning_jobs (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    type        TEXT NOT NULL,                 -- 'tenant_create' | 'skill_enable' | 'skill_disable'
    status      TEXT NOT NULL DEFAULT 'queued', -- 'queued' | 'running' | 'done' | 'failed'
    payload     JSONB NOT NULL DEFAULT '{}',
    attempts    INTEGER NOT NULL DEFAULT 0,
    last_error  TEXT,
    started_at  TIMESTAMPTZ,
    done_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_prov_jobs_tenant ON ginkgo.provisioning_jobs (tenant_id);
CREATE INDEX idx_prov_jobs_status ON ginkgo.provisioning_jobs (status, created_at ASC);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'provisioning_jobs');


-- =============================================================================
-- 19. AUDIT LOG
-- Imutável. Nenhuma row é UPDATE/DELETE. Escrita via service_role.
-- =============================================================================

CREATE TABLE ginkgo.audit_log (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID REFERENCES ginkgo.tenants (id) ON DELETE SET NULL,
    actor_id    UUID REFERENCES ginkgo.profiles (id) ON DELETE SET NULL,
    actor_type  TEXT NOT NULL DEFAULT 'user',  -- 'user' | 'agent' | 'worker' | 'system'
    action      TEXT NOT NULL,                 -- ex: 'skill.enabled', 'integration.connected'
    resource    TEXT,                          -- ex: 'module_entitlements:uuid'
    ip_address  INET,
    user_agent  TEXT,
    payload     JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
)
PARTITION BY RANGE (created_at);

CREATE TABLE ginkgo.audit_log_2025
    PARTITION OF ginkgo.audit_log
    FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');

CREATE TABLE ginkgo.audit_log_2026
    PARTITION OF ginkgo.audit_log
    FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');

CREATE INDEX idx_audit_tenant  ON ginkgo.audit_log (tenant_id, created_at DESC);
CREATE INDEX idx_audit_actor   ON ginkgo.audit_log (actor_id, created_at DESC);
CREATE INDEX idx_audit_action  ON ginkgo.audit_log (action, created_at DESC);

ALTER TABLE ginkgo.audit_log ENABLE ROW LEVEL SECURITY;

-- Admins e owners veem o audit do seu tenant
CREATE POLICY audit_admin ON ginkgo.audit_log
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m.role IN ('owner', 'admin')
        )
    );


-- =============================================================================
-- 20. AGENT TEMPLATES
-- Templates base de agentes (Brann, Nyra, Alfred, OpenClaw).
-- Definidos globalmente, instanciados por tenant via agent_instances.
-- =============================================================================

CREATE TABLE agents.templates (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    skill_key       ginkgo.skill_key NOT NULL UNIQUE,
    name            TEXT NOT NULL,             -- ex: 'Brann'
    description     TEXT,
    system_prompt   TEXT NOT NULL,             -- prompt base do agente
    tools           JSONB NOT NULL DEFAULT '[]', -- lista de tools disponíveis
    default_config  JSONB NOT NULL DEFAULT '{}',
    version         TEXT NOT NULL DEFAULT '1.0.0',
    is_active       BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

SELECT ginkgo.create_updated_at_trigger('agents', 'templates');

-- Templates: leitura pública, escrita apenas service_role
ALTER TABLE agents.templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY templates_read ON agents.templates FOR SELECT USING (is_active = true);


-- =============================================================================
-- 21. AGENT INSTANCES
-- Instância de um template para um tenant específico
-- =============================================================================

CREATE TABLE agents.instances (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    template_id     UUID NOT NULL REFERENCES agents.templates (id),
    skill_key       ginkgo.skill_key NOT NULL,
    name            TEXT NOT NULL,
    status          agents.agent_status NOT NULL DEFAULT 'inactive',
    system_prompt   TEXT,                      -- override do template (se personalizado)
    config          JSONB NOT NULL DEFAULT '{}', -- config específica do tenant
    tools_override  JSONB,                     -- NULL = usa tools do template
    memory_config   JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, skill_key)
);

CREATE INDEX idx_agent_instances_tenant ON agents.instances (tenant_id);
CREATE INDEX idx_agent_instances_status ON agents.instances (status);

SELECT ginkgo.create_updated_at_trigger('agents', 'instances');

ALTER TABLE agents.instances ENABLE ROW LEVEL SECURITY;

CREATE POLICY agent_instances_tenant ON agents.instances
    USING (
        tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        )
    );


-- =============================================================================
-- 22. TENANT SETTINGS
-- Par chave-valor para configurações livres por tenant.
-- Evita engordar a coluna settings da tabela tenants.
-- =============================================================================

CREATE TABLE ginkgo.tenant_settings (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    key         TEXT NOT NULL,
    value       JSONB NOT NULL,
    is_secret   BOOLEAN NOT NULL DEFAULT false, -- se true, não retorna no frontend
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

    UNIQUE (tenant_id, key)
);

CREATE INDEX idx_tenant_settings_tenant ON ginkgo.tenant_settings (tenant_id);

SELECT ginkgo.create_updated_at_trigger('ginkgo', 'tenant_settings');

ALTER TABLE ginkgo.tenant_settings ENABLE ROW LEVEL SECURITY;

-- Secrets visíveis apenas para owner/admin
CREATE POLICY settings_admin ON ginkgo.tenant_settings
    USING (
        -- non-secrets: qualquer membro
        (NOT is_secret AND tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        ))
        OR
        -- secrets: apenas owner/admin
        (is_secret AND tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
              AND m.role IN ('owner', 'admin')
        ))
    );


-- =============================================================================
-- 23. NOTIFICATIONS
-- Notificações internas da plataforma para membros do tenant
-- =============================================================================

CREATE TABLE ginkgo.notifications (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES ginkgo.tenants (id) ON DELETE CASCADE,
    profile_id  UUID REFERENCES ginkgo.profiles (id) ON DELETE CASCADE, -- NULL = todos do tenant
    type        TEXT NOT NULL,                 -- ex: 'handoff', 'overage_warn', 'sync_failed'
    title       TEXT NOT NULL,
    body        TEXT,
    action_url  TEXT,
    is_read     BOOLEAN NOT NULL DEFAULT false,
    metadata    JSONB NOT NULL DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_notif_tenant   ON ginkgo.notifications (tenant_id, created_at DESC);
CREATE INDEX idx_notif_profile  ON ginkgo.notifications (profile_id, is_read);

ALTER TABLE ginkgo.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY notifications_self ON ginkgo.notifications
    USING (
        (profile_id = (SELECT id FROM ginkgo.profiles WHERE auth_user_id = auth.uid()))
        OR
        (profile_id IS NULL AND tenant_id IN (
            SELECT tenant_id FROM ginkgo.memberships m
            JOIN ginkgo.profiles p ON p.id = m.profile_id
            WHERE p.auth_user_id = auth.uid()
        ))
    );


-- =============================================================================
-- 24. SEED DATA — PLANS INICIAIS
-- =============================================================================

INSERT INTO billing.plans (
    code, name, description, interval, price_cents, currency,
    max_users, max_storage_gb, max_integrations, included_ai_tokens
) VALUES
(
    'starter', 'Starter', 'Ideal para começar: workspace, 3 usuários, RAG básico.',
    'monthly', 25000, 'BRL',
    3, 5, 3, 500000
),
(
    'growth', 'Growth', 'Para times em crescimento: mais usuários, storage e tokens.',
    'monthly', 45000, 'BRL',
    10, 20, 10, 2000000
),
(
    'scale', 'Scale', 'Para operações exigentes: usuários ilimitados, storage amplo.',
    'monthly', 89000, 'BRL',
    NULL, 100, NULL, 10000000
);


-- =============================================================================
-- 25. SEED DATA — AGENT TEMPLATES
-- =============================================================================

INSERT INTO agents.templates (skill_key, name, description, system_prompt, tools, version)
VALUES
(
    'leaf', 'Brann',
    'Agente de atendimento inteligente. Responde clientes, consulta histórico, executa handoff.',
    '-- SYSTEM PROMPT BASE: será personalizado por tenant via agent_instances.system_prompt',
    '["rag_search", "contact_lookup", "conversation_history", "handoff_create", "send_message"]',
    '1.0.0'
),
(
    'pyre', 'Nyra',
    'Agente de conteúdo e marketing. Gera conteúdo, analisa tendências, gerencia campanhas.',
    '-- SYSTEM PROMPT BASE: personalizável',
    '["rag_search", "content_generate", "trend_analysis", "calendar_create", "publish_content"]',
    '1.0.0'
),
(
    'wave', 'Alfred',
    'Agente de operação. Gerencia tarefas, gera relatórios, integra ferramentas de gestão.',
    '-- SYSTEM PROMPT BASE: personalizável',
    '["rag_search", "task_create", "task_list", "report_generate", "clickup_sync"]',
    '1.0.0'
),
(
    'command', 'OpenClaw',
    'Assistente conversacional unificado via Telegram. Conecta todos os agentes e dados.',
    '-- SYSTEM PROMPT BASE: personalizável',
    '["rag_search", "order_list", "task_create", "integration_status", "billing_query", "agent_delegate"]',
    '1.0.0'
);


-- =============================================================================
-- 26. VIEWS ÚTEIS
-- =============================================================================

-- Tenant com status da assinatura (usado no dashboard e no provisioning worker)
CREATE VIEW ginkgo.tenant_overview AS
SELECT
    t.id           AS tenant_id,
    t.slug,
    t.name,
    t.status       AS tenant_status,
    t.locale,
    t.timezone,
    s.status       AS subscription_status,
    p.code         AS plan_code,
    p.name         AS plan_name,
    s.current_period_end,
    s.trial_ends_at,
    (SELECT COUNT(*) FROM ginkgo.memberships m WHERE m.tenant_id = t.id) AS member_count,
    (SELECT COUNT(*) FROM ginkgo.module_entitlements e
     WHERE e.tenant_id = t.id AND e.status = 'active') AS active_skills_count,
    (SELECT COUNT(*) FROM integrations.accounts a
     WHERE a.tenant_id = t.id AND a.status = 'active') AS connected_integrations_count
FROM ginkgo.tenants t
LEFT JOIN billing.subscriptions s ON s.tenant_id = t.id
LEFT JOIN billing.plans p ON p.id = s.plan_id;

-- Membros de um tenant com dados do perfil
CREATE VIEW ginkgo.tenant_members AS
SELECT
    m.tenant_id,
    m.role,
    m.is_primary,
    m.joined_at,
    p.id       AS profile_id,
    p.email,
    p.full_name,
    p.avatar_url
FROM ginkgo.memberships m
JOIN ginkgo.profiles p ON p.id = m.profile_id;

-- Skills ativas de um tenant com configuração
CREATE VIEW ginkgo.active_skills AS
SELECT
    e.tenant_id,
    e.skill_key,
    e.status,
    e.config,
    e.activated_at,
    t.name     AS agent_name,
    t.version  AS template_version
FROM ginkgo.module_entitlements e
JOIN agents.templates t ON t.skill_key = e.skill_key
WHERE e.status = 'active';


-- =============================================================================
-- FIM DO SCHEMA v1.0
-- Próximos schemas:
--   ginkgo-schema-rag-v1.sql     — RAG Core (Fase 3)
--   ginkgo-schema-leaf-v1.sql    — Leaf / Brann (Fase 4)
--   ginkgo-schema-command-v1.sql — Command Assistant (Fase 5)
-- =============================================================================
